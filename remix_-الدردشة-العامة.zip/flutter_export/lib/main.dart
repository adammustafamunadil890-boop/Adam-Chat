import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'screens/chat_screen.dart';
import 'screens/login_screen.dart';

// 1. المستمع الحقيقي لإشعارات الخلفية (يجب أن يكون في المستوى الجذري)
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print("تم استقبال رسالة في الخلفية أو التطبيق مغلق: ${message.messageId}");
  // FCM يتكفل بإظهار الإشعار إذا كان يحتوي على payload من نوع notification
}

late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;
late AndroidNotificationChannel channel;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // تسجيل مستمع الخلفية
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // 2. إعداد قنوات الإشعارات المحلية (Native Notification Channels) لضمان الصوت والهزاز
  channel = const AndroidNotificationChannel(
    'chat_messages', // نفس الـ ID المستخدم في server.ts
    'Chat Messages', 
    description: 'قناة الإشعارات الخاصة برسائل الدردشة.',
    importance: Importance.max,
    playSound: true,
  );

  flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  // إجبار ظهور الإشعارات حتى لو كان التطبيق في الواجهة
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );

  runApp(const AdamChatApp());
}

class AdamChatApp extends StatelessWidget {
  const AdamChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Adam Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF09090B),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo, 
          brightness: Brightness.dark,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// 3. شاشة التحميل الأولية لفحص حالة الدخول بسلاسة دون عرض شاشة تسجيل الدخول مؤقتاً
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkAuth();
  }

  Future<void> _checkAuth() async {
    // مهلة بسيطة لضمان انتقال سلس ولإعطاء Firebase Auth وقتاً للتهيئة
    await Future.delayed(const Duration(milliseconds: 1500));
    
    final user = FirebaseAuth.instance.currentUser;
    if (!mounted) return;

    if (user != null) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const ChatScreen()),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF09090B),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(
                  colors: [Colors.indigo, Colors.purple],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
              ),
              child: const Icon(Icons.message_rounded, size: 48, color: Colors.white),
            ),
            const SizedBox(height: 24),
            const Text(
              "Adam Chat", 
              style: TextStyle(
                fontSize: 28, 
                fontWeight: FontWeight.bold, 
                color: Colors.white
              )
            ),
            const SizedBox(height: 8),
            const Text(
              "جاري الاتصال والتحقق...", 
              style: TextStyle(color: Colors.grey, fontSize: 14)
            ),
          ],
        ),
      ),
    );
  }
}
