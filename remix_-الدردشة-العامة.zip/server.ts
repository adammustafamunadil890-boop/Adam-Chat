import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getMessaging } from "firebase-admin/messaging";
import { initializeApp as initClientApp } from "firebase/app";
import {
  initializeFirestore,
  collection,
  onSnapshot,
  getDocs,
  doc,
  getDoc,
} from "firebase/firestore";
import firebaseConfig from "./firebase-applet-config.json";

dotenv.config();

let adminInitialized = false;

function initAdmin() {
  if (!adminInitialized) {
    try {
      if (getApps().length === 0) {
        const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
        if (serviceAccountJson) {
          try {
            const credential = cert(JSON.parse(serviceAccountJson));
            initializeApp({
              credential,
              projectId: process.env.FIREBASE_PROJECT_ID || firebaseConfig.projectId,
            });
          } catch (err) {
            console.warn("Could not parse FIREBASE_SERVICE_ACCOUNT_KEY:", err);
            initializeApp({
              projectId: process.env.FIREBASE_PROJECT_ID || firebaseConfig.projectId,
            });
          }
        } else {
          initializeApp({
            projectId: process.env.FIREBASE_PROJECT_ID || firebaseConfig.projectId,
          });
        }
      }
      adminInitialized = true;
    } catch (e) {
      console.warn("Firebase admin initialization warning:", e);
    }
  }
}

// تهيئة عميل Firestore الداخلي للاستماع المباشر للتغييرات في قاعدة البيانات
let clientDbInstance: any = null;
function getClientDb() {
  if (!clientDbInstance) {
    const clientApp = initClientApp(
      {
        apiKey: firebaseConfig.apiKey,
        projectId: firebaseConfig.projectId,
        appId: firebaseConfig.appId,
      },
      "server-internal-listener"
    );
    clientDbInstance = initializeFirestore(
      clientApp,
      {},
      firebaseConfig.firestoreDatabaseId
    );
  }
  return clientDbInstance;
}

interface SendNotificationOptions {
  title: string;
  body: string;
  senderUid?: string;
  chatId?: string;
  icon?: string;
  tokens?: string[];
}

/**
 * دالة إرسال الإشعارات المركزية بأعلى أولوية لنظام أندرويد
 */
export async function dispatchFCMNotification(options: SendNotificationOptions) {
  const { title, body, senderUid, chatId, icon, tokens: clientTokens } = options;

  if (!title || !body) {
    return { success: false, error: "title and body are required" };
  }

  try {
    initAdmin();
    if (!getApps().length) {
      return {
        success: false,
        error: "Firebase Admin is not configured",
      };
    }

    let tokens: string[] = Array.isArray(clientTokens) ? clientTokens : [];

    // إذا لم يتم تمرير الرموز، نجلبها مباشرة من Firestore للمشاركين في المحادثة
    if (tokens.length === 0 && chatId) {
      try {
        const db = getClientDb();
        const chatDoc = await getDoc(doc(db, "chats", chatId));
        
        if (chatDoc.exists()) {
          const participants: string[] = chatDoc.data().participants || [];
          
          for (const uid of participants) {
            if (uid !== senderUid) {
              const userDoc = await getDoc(doc(db, "users", uid));
              if (userDoc.exists()) {
                const data = userDoc.data();
                if (data.fcmToken && typeof data.fcmToken === "string") {
                  tokens.push(data.fcmToken);
                }
                if (Array.isArray(data.fcmTokens)) {
                  data.fcmTokens.forEach((tk: any) => {
                    if (typeof tk === "string") tokens.push(tk);
                  });
                }
              }
            }
          }
        }
      } catch (dbErr: any) {
        console.warn("Server Firestore token lookup failed:", dbErr?.message);
      }
    }

    const validTokens = Array.from(
      new Set(
        tokens.filter(
          (t) => typeof t === "string" && t.trim().length > 10
        )
      )
    );

    console.log(
      `[FCM MultiCast] فحص المستلمين: تم العثور على ${validTokens.length} رمز جهاز مسجل (مرسل الرسالة: ${senderUid || "عام"})`
    );

    if (validTokens.length === 0) {
      console.log(
        `[FCM MultiCast] تنبيه: لا توجد أجهزة مسجلة في Firestore لإرسال الإشعار إليها (validTokens = 0)`
      );
      return {
        success: true,
        message: "لا توجد أجهزة مسجلة لإرسال الإشعار إليها بعد في قاعدة البيانات",
        sentCount: 0,
      };
    }

    const response = await getMessaging().sendEachForMulticast({
      tokens: validTokens,
      // 1. كائن notification الرسمي ليقوم نظام أندرويد بعرضه فوراً في شريط الإشعارات حتى والتطبيق مغلق تماماً
      notification: {
        title: String(title),
        body: String(body),
      },
      // 2. كائن data لنقل البيانات الإضافية للتطبيق والـ WebView
      data: {
        title: String(title),
        body: String(body),
        chatId: String(chatId || ""),
        senderUid: String(senderUid || ""),
        url: "/",
        icon: String(icon || "/logo.jpg"),
        click_action: "FLUTTER_NOTIFICATION_CLICK",
      },
      // 3. إعدادات نظام Android بأعلى أولوية ممكنة (High/Max) لتتكفل خدمات Google Play وعمود الإشعارات بعرض الإشعار والتطبيق مغلق تماماً
      android: {
        priority: "high",
        ttl: 86400 * 1000,
        directBootOk: true,
        notification: {
          title: String(title),
          body: String(body),
          sound: "default",
          channelId: "chat_messages",
          priority: "max",
          defaultSound: true,
          defaultVibrateTimings: true,
          defaultLightSettings: true,
          visibility: "public",
          notificationCount: 1,
          tag: `chat_${chatId || "general"}`,
          clickAction: "FLUTTER_NOTIFICATION_CLICK",
        },
      },
      // 4. إعدادات متصفحات الويب والـ Service Worker
      webpush: {
        headers: {
          Urgency: "high",
        },
        notification: {
          title: String(title),
          body: String(body),
          icon: icon || "/logo.jpg",
          badge: "/logo.jpg",
          vibrate: [200, 100, 200],
          requireInteraction: true,
        },
        fcmOptions: {
          link: "/",
        },
      },
      // 5. إعدادات أجهزة iOS إذا وجدت
      apns: {
        headers: {
          "apns-priority": "10",
        },
        payload: {
          aps: {
            alert: {
              title: String(title),
              body: String(body),
            },
            sound: "default",
            badge: 1,
            contentAvailable: true,
          },
        },
      },
    });

    console.log(
      `[FCM MultiCast] تم إرسال ${response.successCount} بنجاح، وفشل ${response.failureCount}`
    );

    return {
      success: true,
      sentCount: response.successCount,
      failureCount: response.failureCount,
    };
  } catch (error: any) {
    console.warn("FCM notification dispatch notice:", error?.message || error);
    return {
      success: false,
      error: error.message || "Failed to send notification",
    };
  }
}

// تخزين الرسائل المعالجة لتفادي التكرار
const processedMessageIds = new Set<string>();
const activeChatListeners = new Map<string, () => void>();

/**
 * Trigger مباشر يراقب Firestore فور إضافة أي رسالة جديدة في أي محادثة
 * ويرسل إشعار أندرويد الفوري تلقائياً دون الحاجة لـ Cloud Functions منفصلة
 */
function setupFirestoreMessageTrigger() {
  try {
    const db = getClientDb();
    console.log("[Firestore Trigger] بدء تتبع رسائل المحادثات في Firestore تلقائياً...");

    onSnapshot(
      collection(db, "chats"),
      (chatsSnapshot) => {
        chatsSnapshot.docs.forEach((chatDoc) => {
          const chatId = chatDoc.id;

          if (!activeChatListeners.has(chatId)) {
            let isInitial = true;

            const unsub = onSnapshot(
              collection(db, "chats", chatId, "messages"),
              (messagesSnapshot) => {
                if (isInitial) {
                  // حفظ معرفات الرسائل السابقة لعدم إرسال إشعارات عنها
                  messagesSnapshot.docs.forEach((d) => processedMessageIds.add(d.id));
                  isInitial = false;
                  return;
                }

                messagesSnapshot.docChanges().forEach(async (change) => {
                  if (change.type === "added") {
                    const msgId = change.doc.id;
                    if (processedMessageIds.has(msgId)) return;
                    processedMessageIds.add(msgId);

                    if (processedMessageIds.size > 5000) {
                      processedMessageIds.clear();
                    }

                    const data = change.doc.data();
                    const senderUid = data.uid;
                    const senderName = data.displayName || "مستخدم";
                    const bodyText =
                      data.text ||
                      (data.audioData
                        ? "🎤 رسالة صوتية"
                        : data.mediaURL
                        ? "📷 وسائط"
                        : "رسالة جديدة");
                    const photo = data.photoURL || "/logo.jpg";

                    console.log(
                      `[Firestore Trigger] رسالة جديدة في المحادثة (${chatId}) من (${senderName}) - جاري إرسال إشعار فوري...`
                    );

                    await dispatchFCMNotification({
                      title: senderName,
                      body: bodyText,
                      senderUid: senderUid,
                      chatId: chatId,
                      icon: photo,
                    });
                  }
                });
              },
              (err) => {
                console.warn(`[Firestore Trigger] خطأ استماع رسائل المحادثة ${chatId}:`, err?.message);
              }
            );

            activeChatListeners.set(chatId, unsub);
          }
        });
      },
      (err) => {
        console.warn("[Firestore Trigger] خطأ استماع المحادثات:", err?.message);
      }
    );
  } catch (err) {
    console.warn("[Firestore Trigger] تعذر تهيئة تتبع Firestore التلقائي:", err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // تشغيل تتبع Firestore التلقائي في السيرفر فور الإقلاع
  setupFirestoreMessageTrigger();

  // Health route
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // فحص حالة خدمة FCM والأجهزة المسجلة
  app.get("/api/fcm-status", async (req, res) => {
    try {
      initAdmin();
      const adminReady = getApps().length > 0;
      let tokensCount = 0;
      let usersWithTokensCount = 0;
      const db = getClientDb();

      try {
        const tokensSnap = await getDocs(collection(db, "fcm_tokens"));
        tokensCount = tokensSnap.size;
      } catch (e) {}

      try {
        const usersSnap = await getDocs(collection(db, "users"));
        usersSnap.forEach((u) => {
          const d = u.data();
          if (d.fcmToken || (Array.isArray(d.fcmTokens) && d.fcmTokens.length > 0)) {
            usersWithTokensCount++;
          }
        });
      } catch (e) {}

      return res.json({
        adminReady,
        tokensCount,
        usersWithTokensCount,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID || "gen-lang-client-0905183084",
      });
    } catch (e: any) {
      return res.status(500).json({ error: e?.message });
    }
  });

  // إرسال إشعار فحص تجريبي للتأكد من وصول الإشعارات
  app.post("/api/send-test-notification", async (req, res) => {
    try {
      const { userUid, token } = req.body || {};
      const targetTokens: string[] = [];
      if (token) targetTokens.push(token);

      const result = await dispatchFCMNotification({
        title: "🔔 إشعار فحص تجريبي",
        body: "إذا ظهر لك هذا الإشعار، فهذا يعني أن نظام FCM يعمل بنجاح مع هاتفك!",
        senderUid: "system_test",
        chatId: "test",
        tokens: targetTokens.length > 0 ? targetTokens : undefined,
      });
      return res.json(result);
    } catch (e: any) {
      return res.status(500).json({ error: e?.message });
    }
  });

  // إرسال إشعارات FCM لجميع المستخدمين عند إضافة رسالة جديدة
  app.post("/api/send-notification", async (req, res) => {
    const result = await dispatchFCMNotification(req.body || {});
    return res.json(result);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
