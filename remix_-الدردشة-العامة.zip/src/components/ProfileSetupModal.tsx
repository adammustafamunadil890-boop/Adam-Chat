import React, { useState, useRef, useMemo } from "react";
import { User, updateProfile } from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";
import {
  Camera,
  Upload,
  Check,
  User as UserIcon,
  Phone,
  Image as ImageIcon,
  Sparkles,
  AlertCircle,
} from "lucide-react";
import { getTranslations } from "../data/translations";

interface ProfileSetupModalProps {
  user: User;
  onComplete: (updatedDisplayName: string, updatedPhotoURL: string) => void;
  initialLanguageCode?: string;
  initialPhoneNumber?: string;
}

export function ProfileSetupModal({
  user,
  onComplete,
  initialLanguageCode,
  initialPhoneNumber = "",
}: ProfileSetupModalProps) {
  const langCode = initialLanguageCode || localStorage.getItem("adam_chat_language") || "ar";
  const t = useMemo(() => getTranslations(langCode), [langCode]);
  const isRtl = useMemo(
    () =>
      langCode === "ar" ||
      langCode === "fa" ||
      langCode === "ur" ||
      langCode === "he" ||
      langCode === "ku" ||
      langCode === "ps",
    [langCode]
  );

  const [displayName, setDisplayName] = useState<string>(
    user.displayName || ""
  );
  const [phoneNumber, setPhoneNumber] = useState<string>(initialPhoneNumber);

  const initialAvatar =
    user.photoURL ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(
      user.displayName || "User"
    )}&background=6366f1&color=fff`;

  const [photoURL, setPhotoURL] = useState<string>(initialAvatar);
  const [isCustomPhoto, setIsCustomPhoto] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Pick photo from gallery and compress via canvas
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrorMessage(t.invalid_image);
      return;
    }

    setErrorMessage(null);
    const reader = new FileReader();

    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_DIMENSION = 256;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_DIMENSION) {
            height = Math.round((height * MAX_DIMENSION) / width);
            width = MAX_DIMENSION;
          }
        } else {
          if (height > MAX_DIMENSION) {
            width = Math.round((width * MAX_DIMENSION) / height);
            height = MAX_DIMENSION;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL("image/jpeg", 0.8);
          setPhotoURL(compressedDataUrl);
          setIsCustomPhoto(true);
        }
      };
      img.src = reader.result as string;
    };

    reader.readAsDataURL(file);
  };

  const handleTriggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = displayName.trim();

    if (!cleanName) {
      setErrorMessage(t.name_required);
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      // 1. Update Firebase Auth user profile
      const authUpdates: { displayName: string; photoURL?: string } = {
        displayName: cleanName,
      };

      // Only pass photoURL to Auth if it's not an oversized data URL
      if (photoURL && !photoURL.startsWith("data:")) {
        authUpdates.photoURL = photoURL;
      }

      try {
        await updateProfile(user, authUpdates);
      } catch (authErr) {
        console.warn("Auth updateProfile warning:", authErr);
      }

      // 2. Save complete profile in Firestore users collection
      const finalPhoto = photoURL || user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(cleanName)}&background=6366f1&color=fff`;

      await setDoc(
        doc(db, "users", user.uid),
        {
          uid: user.uid,
          displayName: cleanName,
          email: user.email || "",
          phoneNumber: phoneNumber.trim(),
          photoURL: finalPhoto,
          profileCompleted: true,
          language: langCode,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      // Save local completion flag
      localStorage.setItem(`adam_chat_profile_completed_${user.uid}`, "true");

      onComplete(cleanName, finalPhoto);
    } catch (err: any) {
      console.error("Error saving user profile:", err);
      setErrorMessage(err.message || "An error occurred while saving profile");
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[150] flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200 select-none"
      dir={isRtl ? "rtl" : "ltr"}
    >
      {/* Hidden file input for gallery picker */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handlePhotoSelect}
      />

      <div className="w-full max-w-md rounded-3xl bg-[#121216] border border-white/10 shadow-2xl overflow-hidden relative">
        {/* Background glow accents */}
        <div className="absolute -top-10 -right-10 w-36 h-36 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-36 h-36 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="p-6 bg-[#16161c] border-b border-white/5 text-center relative">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Adam Chat</span>
          </div>
          <h2 className="text-xl font-bold text-white mb-1">
            {t.profile_title}
          </h2>
          <p className="text-xs text-slate-400">
            {t.profile_desc}
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-6">
          {/* Avatar / Photo selection section */}
          <div className="flex flex-col items-center gap-3">
            <div className="relative group cursor-pointer" onClick={handleTriggerFileInput}>
              <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-indigo-500/50 shadow-xl shadow-indigo-500/15 bg-[#1a1a22] flex items-center justify-center relative">
                {photoURL ? (
                  <img
                    src={photoURL}
                    alt={t.avatar_label}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <UserIcon className="w-12 h-12 text-slate-500" />
                )}

                {/* Hover overlay with camera icon */}
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-colors flex items-center justify-center opacity-90 group-hover:opacity-100">
                  <Camera className="w-6 h-6 text-white drop-shadow" />
                </div>
              </div>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleTriggerFileInput();
                }}
                className={`absolute bottom-0 ${isRtl ? "right-0" : "left-0"} p-2 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg border-2 border-[#121216] transition-transform active:scale-95 cursor-pointer`}
                title={t.avatar_gallery_btn}
              >
                <ImageIcon className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex flex-col items-center gap-1">
              <button
                type="button"
                onClick={handleTriggerFileInput}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 py-1 px-3 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{isCustomPhoto ? t.avatar_change_btn : t.avatar_gallery_btn}</span>
              </button>
              <span className="text-[10.5px] text-slate-400">
                {t.gallery_hint}
              </span>
            </div>
          </div>

          {/* Name input */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>{t.name_label}:</span>
            </label>

            <div className="relative flex items-center">
              <input
                type="text"
                value={displayName}
                onChange={(e) => {
                  setDisplayName(e.target.value);
                  if (errorMessage) setErrorMessage(null);
                }}
                placeholder={t.name_placeholder}
                maxLength={40}
                className={`w-full bg-[#181822] border border-white/10 rounded-2xl py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all ${
                  isRtl ? "pr-4 pl-10 text-right" : "pl-4 pr-10 text-left"
                }`}
              />
              <UserIcon className={`w-4 h-4 text-slate-400 absolute ${isRtl ? "left-3.5" : "right-3.5"} pointer-events-none`} />
            </div>
          </div>

          {/* Phone Number input */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>{isRtl ? "رقم الهاتف الخاص بك" : "Phone Number"}:</span>
            </label>

            <div className="relative flex items-center">
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, "").slice(0, 10);
                  setPhoneNumber(val);
                  if (errorMessage) setErrorMessage(null);
                }}
                placeholder={isRtl ? "اكتب 10 أرقام (مثال: 0501234567)" : "e.g. 0501234567"}
                maxLength={10}
                className={`w-full bg-[#181822] border border-white/10 rounded-2xl py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all ${
                  isRtl ? "pr-4 pl-10 text-right" : "pl-4 pr-10 text-left"
                }`}
              />
              <Phone className={`w-4 h-4 text-indigo-400 absolute ${isRtl ? "left-3.5" : "right-3.5"} pointer-events-none`} />
            </div>
          </div>

          {/* Error Message display */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting || !displayName.trim()}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>{t.save_continue}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
