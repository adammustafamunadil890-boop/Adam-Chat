import React, { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import L from "leaflet";
import {
  MapPin,
  Navigation,
  ExternalLink,
  Maximize2,
  X,
  Radio,
  Clock,
  Square,
  Compass,
  Check,
  RefreshCw,
  Search,
  LocateFixed,
  Info,
  Copy,
} from "lucide-react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy?: number;
  placeName?: string;
  isLive?: boolean;
  liveActive?: boolean;
  durationMinutes?: number;
  expiresAt?: number;
  startedAt?: number;
  updatedAt?: number;
}

// Format coordinates neatly for display
export function formatCoords(lat: number, lng: number) {
  const latDir = lat >= 0 ? "شمالاً" : "جنوباً";
  const lngDir = lng >= 0 ? "شرقاً" : "غرباً";
  return `${Math.abs(lat).toFixed(4)}° ${latDir}, ${Math.abs(lng).toFixed(4)}° ${lngDir}`;
}

// Open Google Maps URL cross-platform (handling iframe restrictions)
export function openGoogleMaps(lat: number, lng: number) {
  const mapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
  
  // 1. Try opening via a synthesized anchor element
  try {
    const a = document.createElement("a");
    a.href = mapsUrl;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 300);
    return;
  } catch {
    // Continue to next method
  }

  // 2. Try window.open
  try {
    const w = window.open(mapsUrl, "_blank", "noopener,noreferrer");
    if (w) return;
  } catch {
    // Continue to fallback
  }

  // 3. Fallback direct navigation
  try {
    window.location.href = mapsUrl;
  } catch {
    // ignored
  }
}

// Copy location Google Maps link to clipboard
export async function copyLocationLink(lat: number, lng: number): Promise<boolean> {
  const mapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(mapsUrl);
      return true;
    }
  } catch {
    // fallback below
  }

  try {
    const textarea = document.createElement("textarea");
    textarea.value = mapsUrl;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    const successful = document.execCommand("copy");
    document.body.removeChild(textarea);
    return successful;
  } catch {
    return false;
  }
}

// Map Card shown in Message Feed
export function LocationMessageCard({
  location,
  isMe,
  messageId,
  chatId,
  senderName,
  senderPhoto,
}: {
  location: LocationData;
  isMe: boolean;
  messageId: string;
  chatId: string;
  senderName: string;
  senderPhoto?: string;
}) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const circleRef = useRef<L.Circle | null>(null);

  const [showFullMap, setShowFullMap] = useState(false);
  const [isStopping, setIsStopping] = useState(false);
  const [remainingTimeText, setRemainingTimeText] = useState<string>("");
  const [copied, setCopied] = useState(false);

  const isLive = !!location.isLive;
  const isExpired = isLive && (!location.liveActive || (location.expiresAt && Date.now() > location.expiresAt));
  const isActive = isLive && !isExpired;

  // Calculate remaining time countdown
  useEffect(() => {
    if (!isActive || !location.expiresAt) return;

    const updateTimer = () => {
      const remainingMs = location.expiresAt! - Date.now();
      if (remainingMs <= 0) {
        setRemainingTimeText("انتهت المدة");
      } else {
        const remainingMinutes = Math.ceil(remainingMs / (60 * 1000));
        if (remainingMinutes < 60) {
          setRemainingTimeText(`متبقي ${remainingMinutes} دقيقة`);
        } else {
          const hours = Math.floor(remainingMinutes / 60);
          const mins = remainingMinutes % 60;
          setRemainingTimeText(`متبقي ${hours} س و ${mins} د`);
        }
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 30000);
    return () => clearInterval(interval);
  }, [isActive, location.expiresAt]);

  // Initialize or update Leaflet mini-map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    const lat = location.latitude;
    const lng = location.longitude;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [lat, lng],
        zoom: 15,
        zoomControl: false,
        attributionControl: false,
        dragging: false,
        touchZoom: false,
        scrollWheelZoom: false,
        doubleClickZoom: false,
      });

      L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        maxZoom: 19,
        subdomains: "abcd",
      }).addTo(map);

      mapInstanceRef.current = map;
    } else {
      mapInstanceRef.current.setView([lat, lng], 15);
    }

    const map = mapInstanceRef.current;

    // Custom marker icon
    const iconHtml = isActive
      ? `<div class="relative flex items-center justify-center">
           <span class="absolute w-10 h-10 bg-emerald-500/25 rounded-full animate-ping"></span>
           <span class="absolute w-7 h-7 bg-emerald-500/40 rounded-full"></span>
           <div class="relative w-7 h-7 rounded-full overflow-hidden border-2 border-emerald-400 shadow-md bg-[#121215]">
             <img src="${senderPhoto || "https://ui-avatars.com/api/?name=" + encodeURIComponent(senderName)}" class="w-full h-full object-cover" />
           </div>
         </div>`
      : `<div class="relative flex items-center justify-center">
           <div class="w-8 h-8 rounded-full bg-indigo-600 border-2 border-white shadow-lg flex items-center justify-center text-white">
             <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>
           </div>
         </div>`;

    const customIcon = L.divIcon({
      className: "custom-location-marker",
      html: iconHtml,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
    });

    if (!markerRef.current) {
      markerRef.current = L.marker([lat, lng], { icon: customIcon }).addTo(map);
    } else {
      markerRef.current.setLatLng([lat, lng]);
      markerRef.current.setIcon(customIcon);
    }

    if (location.accuracy && location.accuracy < 200) {
      if (!circleRef.current) {
        circleRef.current = L.circle([lat, lng], {
          radius: location.accuracy,
          color: isActive ? "#10b981" : "#6366f1",
          fillColor: isActive ? "#10b981" : "#6366f1",
          fillOpacity: 0.15,
          weight: 1,
        }).addTo(map);
      } else {
        circleRef.current.setLatLng([lat, lng]);
        circleRef.current.setRadius(location.accuracy);
      }
    }

    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 200);

    return () => clearTimeout(timer);
  }, [location.latitude, location.longitude, location.accuracy, isActive, senderPhoto, senderName]);

  // Clean up Leaflet map on unmount
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  const handleStopLiveSharing = async () => {
    if (!isMe || isStopping) return;
    setIsStopping(true);
    try {
      await updateDoc(doc(db, "chats", chatId, "messages", messageId), {
        "location.liveActive": false,
        "location.stoppedAt": Date.now(),
      });
    } catch (err) {
      console.warn("Stopping live location:", err);
    } finally {
      setIsStopping(false);
    }
  };

  const handleCopyLink = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const ok = await copyLocationLink(location.latitude, location.longitude);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <>
      <div 
        className="flex flex-col w-full max-w-[280px] sm:max-w-[320px] rounded-2xl overflow-hidden border border-white/10 bg-[#15151a] shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Status Header */}
        <div className="px-3.5 py-2.5 flex items-center justify-between bg-[#1b1b22] border-b border-white/5">
          <div className="flex items-center gap-2">
            {isLive ? (
              isActive ? (
                <>
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                  </span>
                  <div className="flex flex-col text-right">
                    <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                      <Radio className="w-3 h-3 animate-pulse" />
                      موقع مباشر
                    </span>
                    <span className="text-[10px] text-slate-400">{remainingTimeText}</span>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Clock className="w-3.5 h-3.5" />
                  <span className="text-xs font-medium">انتهت مشاركة الموقع</span>
                </div>
              )
            ) : (
              <div className="flex items-center gap-1.5 text-indigo-400">
                <MapPin className="w-3.5 h-3.5" />
                <span className="text-xs font-semibold text-slate-200">
                  {location.placeName || "الموقع الجغرافي"}
                </span>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowFullMap(true);
            }}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            title="تكبير الخريطة"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Map View */}
        <div
          onClick={(e) => {
            e.stopPropagation();
            setShowFullMap(true);
          }}
          className="relative w-full h-36 cursor-pointer group bg-[#1c1c21]"
        >
          <div ref={mapContainerRef} className="w-full h-full z-0 pointer-events-none" />
          <div className="absolute inset-0 bg-black/5 group-hover:bg-black/10 transition-colors pointer-events-none" />
          <div className="absolute bottom-2 left-2 z-10 bg-[#121215]/85 backdrop-blur-md px-2 py-0.5 rounded-md text-[9px] text-slate-300 font-mono">
            {formatCoords(location.latitude, location.longitude)}
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="p-2.5 flex flex-col gap-1.5 bg-[#17171e]" onClick={(e) => e.stopPropagation()}>
          {isLive && isActive && isMe && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleStopLiveSharing();
              }}
              disabled={isStopping}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-400 rounded-xl text-xs font-medium transition-all active:scale-98 cursor-pointer"
            >
              <Square className="w-3 h-3 fill-red-400" />
              <span>إيقاف مشاركة الموقع</span>
            </button>
          )}

          <div className="flex items-center gap-1.5 w-full">
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                openGoogleMaps(location.latitude, location.longitude);
              }}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-medium transition-all active:scale-98 cursor-pointer shadow-sm"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>خرائط Google</span>
            </button>

            <button
              type="button"
              onClick={handleCopyLink}
              className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition-colors cursor-pointer"
              title="نسخ رابط خرائط Google"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Fullscreen Interactive Map Dialog */}
      {showFullMap && (
        <FullscreenMapModal
          location={location}
          isActive={isActive}
          senderName={senderName}
          senderPhoto={senderPhoto}
          onClose={() => setShowFullMap(false)}
        />
      )}
    </>
  );
}

// Fullscreen Interactive Map Dialog
function FullscreenMapModal({
  location,
  isActive,
  senderName,
  senderPhoto,
  onClose,
}: {
  location: LocationData;
  isActive: boolean;
  senderName: string;
  senderPhoto?: string;
  onClose: () => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    const lat = location.latitude;
    const lng = location.longitude;

    const map = L.map(containerRef.current, {
      center: [lat, lng],
      zoom: 16,
      zoomControl: true,
      attributionControl: true,
    });

    L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
      subdomains: "abcd",
      attribution: '&copy; <a href="https://carto.com/">CARTO</a>, &copy; OpenStreetMap contributors',
    }).addTo(map);

    const iconHtml = isActive
      ? `<div class="relative flex items-center justify-center">
           <span class="absolute w-12 h-12 bg-emerald-500/25 rounded-full animate-ping"></span>
           <span class="absolute w-9 h-9 bg-emerald-500/40 rounded-full"></span>
           <div class="relative w-9 h-9 rounded-full overflow-hidden border-2 border-emerald-400 shadow-xl bg-[#121215]">
             <img src="${senderPhoto || "https://ui-avatars.com/api/?name=" + encodeURIComponent(senderName)}" class="w-full h-full object-cover" />
           </div>
         </div>`
      : `<div class="relative flex items-center justify-center">
           <div class="w-9 h-9 rounded-full bg-indigo-600 border-2 border-white shadow-xl flex items-center justify-center text-white">
             <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>
           </div>
         </div>`;

    const customIcon = L.divIcon({
      className: "custom-fullscreen-marker",
      html: iconHtml,
      iconSize: [48, 48],
      iconAnchor: [24, 24],
    });

    L.marker([lat, lng], { icon: customIcon }).addTo(map);

    if (location.accuracy && location.accuracy < 200) {
      L.circle([lat, lng], {
        radius: location.accuracy,
        color: isActive ? "#10b981" : "#6366f1",
        fillColor: isActive ? "#10b981" : "#6366f1",
        fillOpacity: 0.15,
        weight: 1.5,
      }).addTo(map);
    }

    mapRef.current = map;

    setTimeout(() => {
      map.invalidateSize();
    }, 200);

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, [location.latitude, location.longitude, location.accuracy, isActive, senderPhoto, senderName]);

  const recenter = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (mapRef.current) {
      mapRef.current.setView([location.latitude, location.longitude], 16, {
        animate: true,
      });
    }
  };

  const handleCopyLink = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const ok = await copyLocationLink(location.latitude, location.longitude);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const modalContent = (
    <div 
      className="fixed inset-0 z-[120] flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-6 animate-in fade-in duration-200"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div 
        className="relative w-full max-w-3xl h-[85vh] bg-[#121215] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#17171d] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">
                {isActive ? `موقع ${senderName} المباشر` : `موقع ${senderName}`}
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                {formatCoords(location.latitude, location.longitude)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={recenter}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors text-xs flex items-center gap-1.5 cursor-pointer"
              title="إعادة التمركز"
            >
              <Navigation className="w-4 h-4 text-indigo-400" />
              <span className="hidden sm:inline">إعادة التمركز</span>
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onClose();
              }}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="إغلاق الخريطة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Map Container */}
        <div className="flex-1 relative w-full h-full bg-[#1c1c24]">
          <div ref={containerRef} className="w-full h-full" />
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#17171d] border-t border-white/10 flex items-center justify-between flex-wrap gap-2">
          <span className="text-xs text-slate-400 font-mono">
            {location.accuracy ? `دقة القياس: ±${Math.round(location.accuracy)} م` : ""}
            {location.placeName ? ` • ${location.placeName}` : ""}
          </span>
          
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 rounded-xl text-xs font-medium transition-all cursor-pointer"
              title="نسخ الرابط المباشر"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? "تم النسخ!" : "نسخ الرابط"}</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                openGoogleMaps(location.latitude, location.longitude);
              }}
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition-all active:scale-95 cursor-pointer shadow-lg shadow-indigo-600/30"
            >
              <ExternalLink className="w-4 h-4" />
              <span>عرض في خرائط Google</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return typeof document !== "undefined" ? createPortal(modalContent, document.body) : modalContent;
}

// Fallback IP Geolocation fetcher (Never throws, returns fallback coordinates)
async function fetchIpLocation(): Promise<{ latitude: number; longitude: number; placeName?: string }> {
  try {
    const res = await fetch("https://freeipapi.com/api/json");
    if (res.ok) {
      const data = await res.json();
      if (typeof data.latitude === "number" && typeof data.longitude === "number") {
        return {
          latitude: data.latitude,
          longitude: data.longitude,
          placeName: data.cityName ? `${data.cityName}، ${data.countryName || ""}` : undefined,
        };
      }
    }
  } catch {
    // try secondary IP endpoint silently
    try {
      const res2 = await fetch("https://ipapi.co/json/");
      if (res2.ok) {
        const data2 = await res2.json();
        if (data2.latitude && data2.longitude) {
          return {
            latitude: Number(data2.latitude),
            longitude: Number(data2.longitude),
            placeName: data2.city ? `${data2.city}، ${data2.country_name || ""}` : undefined,
          };
        }
      }
    } catch {
      // ignore
    }
  }

  // Default regional center if everything is offline/blocked (e.g. Baghdad)
  return {
    latitude: 33.3152,
    longitude: 44.3661,
    placeName: "بغداد",
  };
}

// Location Picker Modal for choosing Current Location or Live Location
export function LocationPickerModal({
  isOpen,
  onClose,
  onSendLocation,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSendLocation: (data: LocationData) => void;
}) {
  const [activeTab, setActiveTab] = useState<"current" | "live">("current");
  const [isLoading, setIsLoading] = useState(true);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  const [currentCoords, setCurrentCoords] = useState<{
    latitude: number;
    longitude: number;
    accuracy?: number;
    placeName?: string;
    isManual?: boolean;
  } | null>(null);

  // Live location duration selection (minutes)
  const [selectedDuration, setSelectedDuration] = useState<number>(15);

  const previewMapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);

  // Multi-tier location fetcher: GPS High -> GPS Standard -> IP Fallback -> Default
  const requestLocation = () => {
    setIsLoading(true);
    setStatusMessage(null);

    const useFallback = async (reason?: string) => {
      setStatusMessage(reason || "جاري تحديد الموقع التقريبي...");
      const ipLoc = await fetchIpLocation();
      setCurrentCoords({
        latitude: ipLoc.latitude,
        longitude: ipLoc.longitude,
        accuracy: 2500,
        placeName: ipLoc.placeName,
        isManual: true,
      });
      setStatusMessage("تم تحديد الموقع التقريبي. يمكنك النقر على الخريطة لتحديده بدقة.");
      setIsLoading(false);
    };

    if (!navigator.geolocation) {
      useFallback("خاصية GPS غير مدعومة في هذا المتصفح.");
      return;
    }

    // Tier 1: Try High Accuracy GPS
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCurrentCoords({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          isManual: false,
        });
        setStatusMessage("تم تحديد موقعك بدقة عبر GPS.");
        setIsLoading(false);
      },
      () => {
        // Tier 2: Try standard accuracy with wider cache
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            setCurrentCoords({
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
              accuracy: pos.coords.accuracy,
              isManual: false,
            });
            setStatusMessage("تم تحديد موقعك بنجاح.");
            setIsLoading(false);
          },
          () => {
            // Tier 3: Fallback gracefully to network/IP coordinates
            useFallback("تعذر الوصول لـ GPS. تم تحديد الموقع التقريبي عبر الشبكة.");
          },
          {
            enableHighAccuracy: false,
            timeout: 6000,
            maximumAge: 60000,
          }
        );
      },
      {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 15000,
      }
    );
  };

  useEffect(() => {
    if (isOpen) {
      requestLocation();
    } else {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    }
  }, [isOpen]);

  // Search place by name via OpenStreetMap Nominatim
  const handleSearchPlace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || isSearching) return;

    setIsSearching(true);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          searchQuery.trim()
        )}&limit=1`
      );
      if (res.ok) {
        const results = await res.json();
        if (results && results.length > 0) {
          const lat = parseFloat(results[0].lat);
          const lon = parseFloat(results[0].lon);
          setCurrentCoords({
            latitude: lat,
            longitude: lon,
            placeName: results[0].display_name?.split(",")[0] || searchQuery.trim(),
            accuracy: 50,
            isManual: true,
          });
          if (mapInstanceRef.current) {
            mapInstanceRef.current.setView([lat, lon], 16);
          }
          setStatusMessage(`تم الانتقال إلى: ${results[0].display_name?.split(",")[0]}`);
        } else {
          setStatusMessage("لم يتم العثور على نتائج للبحث، جرب اسماً آخر.");
        }
      }
    } catch {
      setStatusMessage("تعذر البحث في الوقت الحالي.");
    } finally {
      setIsSearching(false);
    }
  };

  // Setup interactive preview map inside modal
  useEffect(() => {
    if (!previewMapRef.current || !currentCoords) return;

    const lat = currentCoords.latitude;
    const lng = currentCoords.longitude;

    if (!mapInstanceRef.current) {
      const map = L.map(previewMapRef.current, {
        center: [lat, lng],
        zoom: 15,
        zoomControl: false,
        attributionControl: false,
        dragging: true,
        touchZoom: true,
        scrollWheelZoom: true,
        doubleClickZoom: true,
      });

      L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        maxZoom: 19,
        subdomains: "abcd",
      }).addTo(map);

      // Allow clicking on map to reposition marker
      map.on("click", (e: L.LeafletMouseEvent) => {
        setCurrentCoords((prev) => ({
          latitude: e.latlng.lat,
          longitude: e.latlng.lng,
          accuracy: 10,
          placeName: prev?.placeName,
          isManual: true,
        }));
        setStatusMessage("تم تحديد النقطة على الخريطة بنجاح.");
      });

      mapInstanceRef.current = map;
    } else {
      mapInstanceRef.current.setView([lat, lng]);
    }

    const map = mapInstanceRef.current;

    const iconHtml = `<div class="relative flex items-center justify-center cursor-grab active:cursor-grabbing">
        <span class="absolute w-8 h-8 bg-indigo-500/30 rounded-full animate-ping"></span>
        <div class="w-7 h-7 rounded-full bg-indigo-600 border-2 border-white shadow-lg flex items-center justify-center text-white">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>
        </div>
      </div>`;

    const customIcon = L.divIcon({
      className: "custom-picker-marker",
      html: iconHtml,
      iconSize: [36, 36],
      iconAnchor: [18, 18],
    });

    if (!markerRef.current) {
      const marker = L.marker([lat, lng], { icon: customIcon, draggable: true }).addTo(map);
      marker.on("dragend", (e: any) => {
        const newLatLng = e.target.getLatLng();
        setCurrentCoords((prev) => ({
          latitude: newLatLng.lat,
          longitude: newLatLng.lng,
          accuracy: 10,
          placeName: prev?.placeName,
          isManual: true,
        }));
        setStatusMessage("تم تعديل موقع الدبوس يدوياً.");
      });
      markerRef.current = marker;
    } else {
      markerRef.current.setLatLng([lat, lng]);
      markerRef.current.setIcon(customIcon);
    }

    setTimeout(() => {
      map.invalidateSize();
    }, 200);
  }, [currentCoords?.latitude, currentCoords?.longitude]);

  if (!isOpen) return null;

  const handleSend = () => {
    if (!currentCoords) return;

    if (activeTab === "current") {
      onSendLocation({
        latitude: currentCoords.latitude,
        longitude: currentCoords.longitude,
        accuracy: currentCoords.accuracy ? Math.round(currentCoords.accuracy) : undefined,
        placeName: currentCoords.placeName,
        isLive: false,
      });
    } else {
      // Live location
      const now = Date.now();
      const expiresAt = now + selectedDuration * 60 * 1000;
      onSendLocation({
        latitude: currentCoords.latitude,
        longitude: currentCoords.longitude,
        accuracy: currentCoords.accuracy ? Math.round(currentCoords.accuracy) : undefined,
        placeName: currentCoords.placeName,
        isLive: true,
        liveActive: true,
        durationMinutes: selectedDuration,
        startedAt: now,
        expiresAt: expiresAt,
        updatedAt: now,
      });
    }
    onClose();
  };

  const modalContent = (
    <div 
      className="fixed inset-0 z-[120] flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in duration-200"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div 
        className="relative w-full max-w-md bg-[#16161c] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-3.5 sm:p-4 bg-[#1b1b22] border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">مشاركة الموقع</h3>
              <p className="text-[11px] text-slate-400">موقعك الحالي أو تتبع مباشر</p>
            </div>
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex p-2 bg-[#121216] border-b border-white/5 gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab("current")}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === "current"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>الموقع الحالي</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("live")}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === "live"
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>موقع مباشر (Live)</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="px-3.5 pt-3 bg-[#16161c]">
          <form onSubmit={handleSearchPlace} className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن مدينة، حي، أو معلم..."
              className="w-full bg-[#1e1e26] border border-white/10 rounded-xl py-1.5 pr-9 pl-8 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-right"
              dir="rtl"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-2.5 pointer-events-none" />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="absolute left-2.5 p-0.5 text-slate-400 hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </form>
        </div>

        {/* Body content */}
        <div className="p-3.5 sm:p-4 flex flex-col gap-3 overflow-y-auto">
          {/* Map Preview */}
          <div className="relative h-44 rounded-2xl overflow-hidden border border-white/10 bg-[#121216]">
            {isLoading ? (
              <div className="w-full h-full flex flex-col items-center justify-center gap-2.5 bg-[#141418]">
                <div className="w-7 h-7 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                <span className="text-[11px] text-slate-400">جاري البحث عن الموقع الجغرافي...</span>
              </div>
            ) : (
              <>
                <div ref={previewMapRef} className="w-full h-full" />
                
                {/* Floating GPS Recenter button */}
                <button
                  type="button"
                  onClick={requestLocation}
                  className="absolute top-2.5 left-2.5 z-10 p-2 rounded-xl bg-[#121215]/90 hover:bg-[#1a1a20] border border-white/10 text-indigo-400 shadow-md backdrop-blur-md transition-all active:scale-95 cursor-pointer"
                  title="تحديد موقعي الحالي"
                >
                  <LocateFixed className="w-4 h-4" />
                </button>

                {/* Instruction badge */}
                <div className="absolute bottom-2 right-2 z-10 bg-[#121215]/85 backdrop-blur-md px-2 py-1 rounded-lg text-[10px] text-slate-300 flex items-center gap-1 font-mono">
                  <span>{currentCoords && formatCoords(currentCoords.latitude, currentCoords.longitude)}</span>
                </div>
              </>
            )}
          </div>

          {/* Hint / Status Notice */}
          <div className="px-3 py-2 rounded-xl bg-[#1c1c24] border border-white/5 flex items-center gap-2 text-right">
            <Info className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="text-[11px] text-slate-300 leading-tight">
              {statusMessage || "يمكنك النقر على أي مكان في الخريطة أو سحب الدبوس لتعديل مكانك بدقة."}
            </span>
          </div>

          {/* Current tab details */}
          {activeTab === "current" ? (
            <div className="p-3 rounded-2xl bg-[#1a1a22] border border-white/5 flex items-center justify-between">
              <div className="flex flex-col text-right">
                <span className="text-xs font-semibold text-slate-200">
                  {currentCoords?.placeName ? currentCoords.placeName : "موقع ثابت"}
                </span>
                <span className="text-[10px] text-slate-400">
                  {currentCoords?.isManual ? "موقع محدد يدوياً" : "تم تحديده تلقائياً"}
                </span>
              </div>
              <button
                type="button"
                onClick={requestLocation}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 transition-colors cursor-pointer"
                title="تحديث GPS"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            /* Live location duration options */
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span className="font-semibold">مدة مشاركة الموقع المباشر:</span>
                <span className="text-emerald-400 font-medium">مباشر لحظي</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {[
                  { minutes: 15, label: "15 دقيقة" },
                  { minutes: 60, label: "ساعة واحدة" },
                  { minutes: 480, label: "8 ساعات" },
                ].map((dur) => (
                  <button
                    key={dur.minutes}
                    type="button"
                    onClick={() => setSelectedDuration(dur.minutes)}
                    className={`py-2 px-3 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                      selectedDuration === dur.minutes
                        ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-md shadow-emerald-500/10"
                        : "bg-[#181820] border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/5"
                    }`}
                  >
                    {dur.label}
                  </button>
                ))}
              </div>

              <p className="text-[10.5px] text-slate-400 leading-relaxed text-right mt-0.5">
                سيتمكن الطرف الآخر من تتبع تحركاتك على الخريطة طوال المدة، ويمكنك إيقاف المشاركة في أي لحظة.
              </p>
            </div>
          )}
        </div>

        {/* Footer buttons */}
        <div className="p-3.5 sm:p-4 bg-[#1a1a22] border-t border-white/5 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onClose();
            }}
            className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-white/5 hover:text-white transition-colors cursor-pointer"
          >
            إلغاء
          </button>

          <button
            type="button"
            disabled={isLoading || !currentCoords}
            onClick={handleSend}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-white transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg cursor-pointer ${
              activeTab === "live"
                ? "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20"
                : "bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/20"
            }`}
          >
            {activeTab === "live" ? (
              <>
                <Radio className="w-3.5 h-3.5" />
                <span>بدء مشاركة الموقع المباشر</span>
              </>
            ) : (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>إرسال هذا الموقع</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );

  return typeof document !== "undefined" ? createPortal(modalContent, document.body) : modalContent;
}
