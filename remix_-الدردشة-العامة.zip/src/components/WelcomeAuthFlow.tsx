import React, { useState, useMemo, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import confetti from "canvas-confetti";
import {
  User as UserIcon,
  Users,
  Phone,
  Camera,
  Upload,
  Check,
  ArrowRight,
  ArrowLeft,
  Globe,
  Sparkles,
  ChevronDown,
  AlertCircle,
  RefreshCw,
  Image as ImageIcon,
} from "lucide-react";
import { WORLD_LANGUAGES, LanguageItem } from "../data/languages";
import { getTranslations } from "../data/translations";

interface WelcomeAuthFlowProps {
  onComplete: (data: {
    firstName: string;
    lastName: string;
    phoneNumber: string;
    photoURL: string;
  }) => Promise<void>;
  onLanguageSelected?: (lang: LanguageItem) => void;
}

export function WelcomeAuthFlow({
  onComplete,
  onLanguageSelected,
}: WelcomeAuthFlowProps) {
  // Step 1: Request First Name, Family Name & Phone Number
  // Step 2: "أهلاً يا [الاسم]" & Choose Profile Photo & Finish
  const [step, setStep] = useState<1 | 2>(1);

  // Form Fields
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");

  // Photo / Avatar Selection
  const [photoURL, setPhotoURL] = useState<string>("");
  const [selectedPresetIndex, setSelectedPresetIndex] = useState<number>(0);
  const [isCustomPhoto, setIsCustomPhoto] = useState(false);

  // States
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [showLangDropdown, setShowLangDropdown] = useState(false);

  // Language management
  const [selectedLanguageCode, setSelectedLanguageCode] = useState<string>(() => {
    return localStorage.getItem("adam_chat_language") || "ar";
  });

  const selectedLanguage = useMemo(() => {
    return (
      WORLD_LANGUAGES.find((l) => l.code === selectedLanguageCode) ||
      WORLD_LANGUAGES[0]
    );
  }, [selectedLanguageCode]);

  const t = useMemo(() => {
    return getTranslations(selectedLanguageCode);
  }, [selectedLanguageCode]);

  const isRtl = useMemo(() => {
    return (
      selectedLanguage.dir === "rtl" ||
      selectedLanguageCode === "ar" ||
      selectedLanguageCode === "fa" ||
      selectedLanguageCode === "ur" ||
      selectedLanguageCode === "he" ||
      selectedLanguageCode === "ku" ||
      selectedLanguageCode === "ps"
    );
  }, [selectedLanguage, selectedLanguageCode]);

  useEffect(() => {
    document.documentElement.lang = selectedLanguageCode;
    document.documentElement.dir = isRtl ? "rtl" : "ltr";
  }, [selectedLanguageCode, isRtl]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Generate dynamic color avatar presets based on the user's name
  const avatarPresets = useMemo(() => {
    const cleanName = `${firstName.trim()} ${lastName.trim()}`.trim() || "Adam";
    const enc = encodeURIComponent(cleanName);
    return [
      {
        id: "indigo",
        name: "Indigo",
        color: "#6366f1",
        url: `https://ui-avatars.com/api/?name=${enc}&background=6366f1&color=fff&size=256&bold=true`,
      },
      {
        id: "emerald",
        name: "Emerald",
        color: "#10b981",
        url: `https://ui-avatars.com/api/?name=${enc}&background=10b981&color=fff&size=256&bold=true`,
      },
      {
        id: "purple",
        name: "Violet",
        color: "#8b5cf6",
        url: `https://ui-avatars.com/api/?name=${enc}&background=8b5cf6&color=fff&size=256&bold=true`,
      },
      {
        id: "amber",
        name: "Amber",
        color: "#f59e0b",
        url: `https://ui-avatars.com/api/?name=${enc}&background=f59e0b&color=fff&size=256&bold=true`,
      },
      {
        id: "rose",
        name: "Rose",
        color: "#f43f5e",
        url: `https://ui-avatars.com/api/?name=${enc}&background=f43f5e&color=fff&size=256&bold=true`,
      },
      {
        id: "cyan",
        name: "Cyan",
        color: "#06b6d4",
        url: `https://ui-avatars.com/api/?name=${enc}&background=06b6d4&color=fff&size=256&bold=true`,
      },
    ];
  }, [firstName, lastName]);

  // If not custom photo, keep photoURL synced with selected preset
  useEffect(() => {
    if (!isCustomPhoto && avatarPresets.length > 0) {
      setPhotoURL(avatarPresets[selectedPresetIndex]?.url || avatarPresets[0].url);
    }
  }, [avatarPresets, selectedPresetIndex, isCustomPhoto]);

  // Language selector
  const handleSelectLanguage = (lang: LanguageItem) => {
    setSelectedLanguageCode(lang.code);
    localStorage.setItem("adam_chat_language", lang.code);
    setShowLangDropdown(false);
    if (onLanguageSelected) {
      onLanguageSelected(lang);
    }
  };

  // Step 1 -> Step 2 validation & transition
  const handleProceedToStep2 = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanFirst = firstName.trim();
    const cleanPhone = phoneNumber.trim();

    if (!cleanFirst) {
      setValidationError(
        isRtl ? "يرجى كتابة الاسم للمتابعة" : "Please enter your first name to continue"
      );
      return;
    }
    if (!cleanPhone) {
      setValidationError(
        isRtl ? "يرجى كتابة رقم الهاتف للبدء والتواصل" : "Please enter your phone number to continue"
      );
      return;
    }

    setValidationError(null);
    setStep(2);
  };

  // Handle image file upload & compression
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setValidationError(
        isRtl ? "يرجى اختيار ملف صورة صالح" : "Please select a valid image file"
      );
      return;
    }

    setValidationError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_DIM = 256;
        let w = img.width;
        let h = img.height;

        if (w > h) {
          if (w > MAX_DIM) {
            h = Math.round((h * MAX_DIM) / w);
            w = MAX_DIM;
          }
        } else {
          if (h > MAX_DIM) {
            w = Math.round((w * MAX_DIM) / h);
            h = MAX_DIM;
          }
        }

        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
          const compressed = canvas.toDataURL("image/jpeg", 0.85);
          setPhotoURL(compressed);
          setIsCustomPhoto(true);
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Final submit (إنهاء)
  const handleFinish = async () => {
    setIsSubmitting(true);
    setValidationError(null);
    try {
      const finalPhoto =
        photoURL ||
        avatarPresets[selectedPresetIndex]?.url ||
        avatarPresets[0].url;

      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {
        // silent confetti fail
      }

      await onComplete({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        phoneNumber: phoneNumber.trim(),
        photoURL: finalPhoto,
      });
    } catch (err: any) {
      console.error("Error completing registration:", err);
      setValidationError(
        err.message ||
          (isRtl
            ? "حدث خطأ أثناء حفظ البيانات، يرجى المحاولة مرة أخرى"
            : "An error occurred while saving your profile. Please try again.")
      );
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="min-h-screen h-[100dvh] w-full bg-[#09090b] flex flex-col justify-between text-slate-100 font-sans p-4 sm:p-8 relative overflow-x-hidden overflow-y-auto select-none"
      dir={isRtl ? "rtl" : "ltr"}
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 -right-24 w-96 h-96 bg-indigo-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 -left-24 w-96 h-96 bg-purple-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Hidden file picker */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* TOP HEADER */}
      <header className="w-full max-w-4xl mx-auto flex items-center justify-between py-2 z-20">
        {/* App Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl overflow-hidden border border-white/10 shadow-lg bg-indigo-500/10 p-0.5 shrink-0">
            <img
              src="/logo.jpg"
              alt="Adam Chat Logo"
              className="w-full h-full object-cover rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base sm:text-lg font-bold text-white tracking-wide">
                Adam Chat
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-medium border border-indigo-500/30">
                {selectedLanguage.name}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {isRtl ? "تطبيق المحادثات الفورية المشفرة" : "Instant Encrypted Messenger"}
            </p>
          </div>
        </div>

        {/* Top Right: Language Dropdown & Step Indicator */}
        <div className="flex items-center gap-3">
          {/* Step Pill */}
          <div className="hidden sm:flex items-center gap-1.5 bg-[#15151b] px-3.5 py-1.5 rounded-2xl border border-white/10 text-xs text-slate-300 shadow-sm">
            <span
              className={`w-2 h-2 rounded-full ${
                step === 1 ? "bg-indigo-500 animate-pulse" : "bg-emerald-400"
              }`}
            />
            <span className="font-semibold text-white">
              {isRtl ? `الخطوة ${step} من 2` : `Step ${step} of 2`}
            </span>
          </div>

          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowLangDropdown(!showLangDropdown)}
              className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-[#15151b] hover:bg-white/10 border border-white/10 text-xs text-slate-200 transition-colors shadow-sm"
              title={isRtl ? "تغيير لغة التطبيق" : "Change Language"}
            >
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-base leading-none">{selectedLanguage.flag}</span>
              <span className="hidden sm:inline font-medium">{selectedLanguage.name}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showLangDropdown && (
              <div
                className={`absolute top-full mt-2 ${
                  isRtl ? "left-0" : "right-0"
                } w-56 max-h-72 overflow-y-auto bg-[#181820] border border-white/10 rounded-2xl shadow-2xl p-1.5 z-50 divide-y divide-white/5 animate-in fade-in zoom-in-95 duration-150`}
              >
                {WORLD_LANGUAGES.map((l) => (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => handleSelectLanguage(l)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors ${
                      l.code === selectedLanguageCode
                        ? "bg-indigo-600/20 text-indigo-300 font-semibold"
                        : "text-slate-300 hover:bg-white/5"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-base">{l.flag}</span>
                      <span>{l.name}</span>
                    </div>
                    {l.code === selectedLanguageCode && (
                      <Check className="w-3.5 h-3.5 text-indigo-400" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* MAIN VIEW AREA (واجهة وليس نافذة) */}
      <main className="flex-1 w-full max-w-xl mx-auto flex items-center justify-center py-6 sm:py-10 z-10">
        <AnimatePresence mode="wait">
          {step === 1 ? (
            /* STEP 1: Full-Screen View for First Name & Last Name */
            <motion.div
              key="welcome-step-1"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="w-full bg-[#131317]/95 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl shadow-indigo-950/20 flex flex-col gap-6"
            >
              {/* Title & Introduction */}
              <div className="text-center space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-400 font-medium">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isRtl ? "مرحباً بك في آدم شات" : "Welcome to Adam Chat"}</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                  {isRtl ? "أنشئ حسابك للبدء" : "Create Your Profile"}
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
                  {isRtl
                    ? "يرجى كتابة اسمك واسم العائلة للمتابعة والتواصل مع أصدقائك"
                    : "Please enter your first name and family name to get started"}
                </p>
              </div>

              {/* Form inputs for First Name & Family Name */}
              <form onSubmit={handleProceedToStep2} className="space-y-4">
                {/* First Name Input */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-300">
                    {isRtl ? "الاسم الأول" : "First Name"}
                    <span className="text-indigo-400 mr-1 ml-1">*</span>
                  </label>
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      value={firstName}
                      onChange={(e) => {
                        setFirstName(e.target.value);
                        if (validationError) setValidationError(null);
                      }}
                      placeholder={isRtl ? "اكتب اسمك هنا (مثال: أحمد)" : "e.g. Adam"}
                      autoFocus
                      maxLength={30}
                      className={`w-full bg-[#0b0b0e] border border-white/10 rounded-2xl py-3.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all ${
                        isRtl ? "pr-11 pl-4 text-right" : "pl-11 pr-4 text-left"
                      }`}
                    />
                    <UserIcon
                      className={`w-4 h-4 text-slate-400 absolute ${
                        isRtl ? "right-3.5" : "left-3.5"
                      } pointer-events-none`}
                    />
                  </div>
                </div>

                {/* Last Name / Family Name Input */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-300">
                    {isRtl ? "اسم العائلة" : "Family Name / Last Name"}
                  </label>
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      value={lastName}
                      onChange={(e) => {
                        setLastName(e.target.value);
                        if (validationError) setValidationError(null);
                      }}
                      placeholder={isRtl ? "اكتب اسم العائلة (مثال: مصطفى)" : "e.g. Smith"}
                      maxLength={30}
                      className={`w-full bg-[#0b0b0e] border border-white/10 rounded-2xl py-3.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all ${
                        isRtl ? "pr-11 pl-4 text-right" : "pl-11 pr-4 text-left"
                      }`}
                    />
                    <Users
                      className={`w-4 h-4 text-slate-400 absolute ${
                        isRtl ? "right-3.5" : "left-3.5"
                      } pointer-events-none`}
                    />
                  </div>
                </div>

                {/* Phone Number Input (رقم الهاتف الخص بك) */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-300">
                    {isRtl ? "رقم الهاتف الخاص بك" : "Phone Number"}
                    <span className="text-indigo-400 mr-1 ml-1">*</span>
                  </label>
                  <div className="relative flex items-center">
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, "").slice(0, 10);
                        setPhoneNumber(val);
                        if (validationError) setValidationError(null);
                      }}
                      placeholder={isRtl ? "اكتب 10 أرقام (مثال: 0501234567)" : "e.g. 0501234567"}
                      maxLength={10}
                      className={`w-full bg-[#0b0b0e] border border-white/10 rounded-2xl py-3.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all ${
                        isRtl ? "pr-11 pl-4 text-right" : "pl-11 pr-4 text-left"
                      }`}
                    />
                    <Phone
                      className={`w-4 h-4 text-indigo-400 absolute ${
                        isRtl ? "right-3.5" : "left-3.5"
                      } pointer-events-none`}
                    />
                  </div>
                  <p className="text-[10px] text-slate-400">
                    {isRtl ? "يجب أن يتكون رقم الهاتف من 10 أرقام تماماً — سيستخدم أصدقاؤك هذا الرقم للبحث عنك" : "Phone number must be exactly 10 digits — friends will use this to find you"}
                  </p>
                </div>

                {/* Validation Error Message if any */}
                {validationError && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-center gap-2"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{validationError}</span>
                  </motion.div>
                )}

                {/* Next Button (التالي) */}
                <div className="pt-3">
                  <button
                    type="submit"
                    disabled={!firstName.trim()}
                    className="w-full flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm sm:text-base shadow-xl shadow-indigo-600/30 transition-all active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <span>{isRtl ? "التالي" : "Next"}</span>
                    {isRtl ? (
                      <ArrowLeft className="w-5 h-5" />
                    ) : (
                      <ArrowRight className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </form>

              {/* Secure Info Note */}
              <div className="text-center pt-2 border-t border-white/5">
                <p className="text-[11px] text-slate-500">
                  {isRtl
                    ? "لن تتم مشاركة بياناتك الشخصية مع أي طرف خارجي"
                    : "Your personal details are private and securely stored"}
                </p>
              </div>
            </motion.div>
          ) : (
            /* STEP 2: "أهلاً يا [الاسم]" & Photo Selection & Finish (إنهاء) */
            <motion.div
              key="welcome-step-2"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="w-full bg-[#131317]/95 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl shadow-indigo-950/20 flex flex-col gap-6"
            >
              {/* Back button to Step 1 */}
              <div>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 py-1.5 px-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                >
                  {isRtl ? (
                    <ArrowRight className="w-3.5 h-3.5" />
                  ) : (
                    <ArrowLeft className="w-3.5 h-3.5" />
                  )}
                  <span>{isRtl ? "الرجوع لتعديل الاسم" : "Back to edit name"}</span>
                </button>
              </div>

              {/* Personalized Greeting: "أهلاً يا [الاسم]" */}
              <div className="text-center space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 font-medium">
                  <Check className="w-3.5 h-3.5" />
                  <span>{isRtl ? "تم تسجيل الاسم بنجاح" : "Name confirmed"}</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {isRtl ? `أهلاً يا ${firstName.trim()}!` : `Welcome, ${firstName.trim()}!`} 👋
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto leading-relaxed">
                  {isRtl
                    ? "اختر صورة شخصية تعبر عنك أو ارفع صورة من جهازك، ثم اضغط على إنهاء"
                    : "Select a photo for your profile or upload an image, then click Finish"}
                </p>
              </div>

              {/* PHOTO SELECTION SECTION */}
              <div className="space-y-6">
                {/* Central Avatar Preview */}
                <div className="flex flex-col items-center gap-3">
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="relative group cursor-pointer"
                    title={isRtl ? "انقر لتغيير الصورة" : "Click to change photo"}
                  >
                    <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden border-2 border-indigo-500/50 shadow-2xl shadow-indigo-500/20 bg-[#1a1a22] flex items-center justify-center relative transition-transform group-hover:scale-105">
                      <img
                        src={photoURL || avatarPresets[selectedPresetIndex]?.url}
                        alt="Avatar Preview"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />

                      {/* Camera Overlay on Hover */}
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-colors flex flex-col items-center justify-center opacity-85 group-hover:opacity-100">
                        <Camera className="w-7 h-7 text-white drop-shadow mb-1" />
                        <span className="text-[10px] text-white font-medium">
                          {isRtl ? "تغيير" : "Change"}
                        </span>
                      </div>
                    </div>

                    {/* Floating Upload Badge */}
                    <div
                      className={`absolute -bottom-2 ${
                        isRtl ? "-left-2" : "-right-2"
                      } p-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg border-2 border-[#131317] transition-transform active:scale-95`}
                    >
                      <Upload className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Device upload button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 py-1.5 px-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                  >
                    <ImageIcon className="w-4 h-4" />
                    <span>
                      {isCustomPhoto
                        ? isRtl
                          ? "استبدال الصورة المختارة"
                          : "Change uploaded photo"
                        : isRtl
                        ? "رفع صورة من جهازك"
                        : "Upload photo from device"}
                    </span>
                  </button>
                </div>

                {/* Preset Avatar Color Themes */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>{isRtl ? "أو اختر لون صورتك الرمزية:" : "Or pick an avatar style:"}</span>
                    {isCustomPhoto && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsCustomPhoto(false);
                          setPhotoURL(avatarPresets[selectedPresetIndex].url);
                        }}
                        className="text-[11px] text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>{isRtl ? "استعادة الرمزية" : "Reset to preset"}</span>
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-6 gap-2 sm:gap-3">
                    {avatarPresets.map((preset, idx) => {
                      const isSelected = !isCustomPhoto && selectedPresetIndex === idx;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => {
                            setSelectedPresetIndex(idx);
                            setIsCustomPhoto(false);
                            setPhotoURL(preset.url);
                          }}
                          className={`flex flex-col items-center p-1.5 rounded-2xl border transition-all cursor-pointer ${
                            isSelected
                              ? "border-indigo-500 bg-indigo-500/20 scale-105 shadow-md shadow-indigo-500/20"
                              : "border-white/10 bg-[#0b0b0e] hover:border-white/20 hover:scale-102"
                          }`}
                        >
                          <div
                            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-inner"
                            style={{ backgroundColor: preset.color }}
                          >
                            {firstName.charAt(0).toUpperCase() || "A"}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Validation error if any */}
                {validationError && (
                  <div className="p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{validationError}</span>
                  </div>
                )}

                {/* Finish Button (إنهاء) */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleFinish}
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center gap-2.5 py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm sm:text-base shadow-xl shadow-emerald-600/30 transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center gap-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>{isRtl ? "جاري الإعداد والدخول..." : "Setting up..."}</span>
                      </div>
                    ) : (
                      <>
                        <Check className="w-5 h-5 stroke-[2.5]" />
                        <span>{isRtl ? "إنهاء والبدء في الدردشة" : "Finish & Start Chatting"}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="w-full max-w-4xl mx-auto py-3 text-center z-10 border-t border-white/5">
        <p className="text-[11px] text-slate-500">
          Adam Chat • {isRtl ? "جميع المحادثات مشفرة وآمنة" : "End-to-End Encrypted Messenger"}
        </p>
      </footer>
    </div>
  );
}
