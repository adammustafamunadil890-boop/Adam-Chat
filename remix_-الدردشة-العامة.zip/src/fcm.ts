import { getMessaging, getToken, onMessage, isSupported } from "firebase/messaging";
import { doc, setDoc, arrayUnion, serverTimestamp } from "firebase/firestore";
import { app, db } from "./firebase";

let messagingInstance: any = null;
type ForegroundMessageCallback = (payload: any) => void;
const foregroundListeners: Set<ForegroundMessageCallback> = new Set();

export function onForegroundFCMMessage(callback: ForegroundMessageCallback) {
  foregroundListeners.add(callback);
  return () => {
    foregroundListeners.delete(callback);
  };
}

/**
 * تهيئة Firebase Cloud Messaging والتأكد من دعم المتصفح أو الـ WebView لها
 */
export async function initFCM() {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    console.warn("Service Workers غير مدعومة في هذا الجهاز/المتصفح");
    return null;
  }

  try {
    const supported = await isSupported();
    if (!supported) {
      console.warn("FCM غير مدعوم في بيئة العرض الحالية");
      return null;
    }

    if (!messagingInstance) {
      messagingInstance = getMessaging(app);

      // الاستماع للرسائل الواردة أثناء فتح التطبيق (Foreground)
      onMessage(messagingInstance, (payload) => {
        console.log("تم استقبال إشعار أثناء فتح التطبيق (Foreground):", payload);

        // إخطار جميع مستمعي الواجهة الداخلية (In-App)
        foregroundListeners.forEach((cb) => {
          try {
            cb(payload);
          } catch (e) {
            console.warn("Foreground callback error:", e);
          }
        });

        const title = payload.notification?.title || payload.data?.title || "رسالة جديدة";
        const body = payload.notification?.body || payload.data?.body || "وصلتك رسالة في الدردشة";

        // إظهار إشعار في المتصفح إذا سمح المستخدم
        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
          try {
            new Notification(title, {
              body,
              icon: payload.notification?.icon || payload.data?.icon || "/logo.jpg",
              badge: "/logo.jpg",
            });
          } catch (e) {
            console.log("Notification display in foreground handled:", e);
          }
        }
      });
    }

    return messagingInstance;
  } catch (error) {
    console.warn("خطأ أثناء تهيئة FCM:", error);
    return null;
  }
}

/**
 * حفظ وتحديث الـ Token في Firestore للمستخدم وفي جدول fcm_tokens العام
 */
export async function saveFCMTokenToFirestore(userUid: string, token: string) {
  if (!token || !userUid) return false;
  try {
    localStorage.setItem("adam_chat_fcm_token", token);

    await setDoc(
      doc(db, "users", userUid),
      {
        fcmToken: token,
        fcmTokens: arrayUnion(token),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    await setDoc(
      doc(db, "fcm_tokens", token),
      {
        token: token,
        uid: userUid,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    console.log("تم حفظ FCM Token في Firestore بنجاح:", token.substring(0, 15) + "...");
    return true;
  } catch (err) {
    console.warn("تعذر حفظ FCM Token في Firestore:", err);
    return false;
  }
}

export function getStoredFCMToken(): string | null {
  if (typeof window === "undefined") return null;
  return (
    (window as any).Android?.getFCMToken?.() ||
    (window as any).Android?.getToken?.() ||
    (window as any).Android?.token ||
    (window as any).AppCreator24?.getToken?.() ||
    (window as any).appcreator24?.token ||
    (window as any).fcmToken ||
    new URLSearchParams(window.location.search).get("fcm_token") ||
    localStorage.getItem("adam_chat_fcm_token") ||
    null
  );
}

export interface TokenDiagnosticResult {
  success: boolean;
  token: string | null;
  error?: string;
  isServiceWorkerSupported: boolean;
  isFCMSupported: boolean;
  permission: string;
}

/**
 * 1. استخراج وحفظ FCM Token مباشرة مع فحص تشخيصي كامل
 */
export async function requestNotificationPermissionAndGetToken(
  userUid: string,
  vapidKey?: string
): Promise<TokenDiagnosticResult> {
  const result: TokenDiagnosticResult = {
    success: false,
    token: null,
    isServiceWorkerSupported: typeof navigator !== "undefined" && "serviceWorker" in navigator,
    isFCMSupported: false,
    permission: typeof Notification !== "undefined" ? Notification.permission : "unsupported",
  };

  if (typeof window === "undefined") {
    result.error = "Window is not defined";
    return result;
  }

  // فحص ما إذا كان التطبيق الأصلي (Native Android / AppCreator24) يمرر التوكن
  const existingToken = getStoredFCMToken();

  // تعريف دالة عامة لتمكين تطبيق الأندرويد من حقن الـ Token
  (window as any).setFCMToken = (nativeToken: string) => {
    if (nativeToken) {
      saveFCMTokenToFirestore(userUid, nativeToken);
    }
  };

  if (existingToken) {
    result.token = existingToken;
    const saved = await saveFCMTokenToFirestore(userUid, existingToken);
    if (saved) {
      result.success = true;
    }
  }

  // محاولة طلب الإذن برمجياً
  if (typeof Notification !== "undefined" && typeof Notification.requestPermission === "function") {
    try {
      if (Notification.permission === "default") {
        await Notification.requestPermission().catch(() => {});
      }
      result.permission = Notification.permission;
    } catch (e) {}
  } else {
    // بيئة WebView أو المتصفح لا تدعم Notification API
    // نتخطى الرفض المباشر ونحاول استخراج الـ Token إذا كان متاحاً في التطبيق الأصلي
    result.permission = "unsupported_but_bypassed";
  }

  try {
    let registration: ServiceWorkerRegistration | undefined;
    if ("serviceWorker" in navigator) {
      try {
        registration = await navigator.serviceWorker.register("/firebase-messaging-sw.js", {
          scope: "/",
        });
        await navigator.serviceWorker.ready;
      } catch (swErr: any) {
        console.warn("ServiceWorker registration notice:", swErr?.message || swErr);
      }
    }

    const messaging = await initFCM();
    if (messaging) {
      result.isFCMSupported = true;
    }

    let currentToken: string | null = null;

    if (messaging) {
      try {
        currentToken = await getToken(messaging, {
          ...(registration ? { serviceWorkerRegistration: registration } : {}),
          vapidKey: vapidKey || "YOUR_VAPID_KEY",
        });
      } catch (tokenErr: any) {
        console.warn("FCM getToken attempt info:", tokenErr?.message || tokenErr);
        if (!result.error) {
          result.error = tokenErr?.message || "تعذر استخراج رمز الويب";
        }
      }
    }

    if (!currentToken && existingToken) {
      currentToken = existingToken;
    }

    if (currentToken) {
      console.log("تم جلب FCM Token بنجاح:", currentToken.substring(0, 15) + "...");
      const saved = await saveFCMTokenToFirestore(userUid, currentToken);
      result.success = saved;
      result.token = currentToken;
      return result;
    }

    if (result.token) {
      result.success = true;
      return result;
    }

    if (!result.error) {
      result.error = "لم يرجع المتصفح أو WebView رمز FCM (قد يحتاج VAPID key أو بيئة APK أصلية)";
    }
    return result;
  } catch (error: any) {
    console.warn("ملاحظة أثناء استخراج FCM Token:", error);
    result.error = error?.message || "خطأ غير متوقع أثناء استخراج الرمز";
    return result;
  }
}

/**
 * 2. إرسال إشعار فوري لجميع الأجهزة عبر السيرفر
 */
export async function sendFCMNotification(params: {
  title: string;
  body: string;
  senderUid: string;
  chatId: string;
  icon?: string;
}) {
  try {
    const { collection, getDocs } = await import("firebase/firestore");

    // جلب الرموز المسجلة من قاعدة بيانات Firestore عبر العميل المصرح له
    const tokens: string[] = [];
    try {
      const tokensSnap = await getDocs(collection(db, "fcm_tokens"));
      tokensSnap.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.token && data.uid !== params.senderUid) {
          tokens.push(data.token);
        }
      });
    } catch (dbErr) {
      console.warn("تعذر جلب رموز الأجهزة محلياً:", dbErr);
    }

    const res = await fetch("/api/send-notification", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...params,
        tokens,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.warn("استجابة خادم الإشعارات:", errText);
      return { success: false, error: errText };
    } else {
      const result = await res.json();
      console.log("نتيجة إرسال الإشعار من السيرفر:", result);
      return result;
    }
  } catch (err: any) {
    console.warn("تعذر إرسال الإشعار عبر الخادم:", err);
    return { success: false, error: err?.message };
  }
}
