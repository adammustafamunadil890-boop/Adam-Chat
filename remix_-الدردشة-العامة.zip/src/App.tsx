import React, { useEffect, useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import confetti from "canvas-confetti";
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from "./firebase";
import {
  signOut,
  onAuthStateChanged,
  User,
  updateProfile,
  setPersistence,
  browserLocalPersistence
} from "firebase/auth";
import {
  collection,
  doc,
  setDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  addDoc,
  deleteDoc,
  serverTimestamp,
  updateDoc,
  getDoc,
  getDocs,
  arrayUnion,
  arrayRemove,
  writeBatch,
} from "firebase/firestore";
import {
  LogOut,
  Send,
  MessageCircle,
  Search,
  Trash2,
  Mic,
  Square,
  X,
  ChevronLeft,
  Check,
  Smile,
  CheckCheck,
  Phone,
  Video,
  Play,
  Pause,
  UserPlus,
  PhoneOff,
  MicOff,
  VideoOff,
  Camera,
  Maximize2,
  Minimize2,
  RefreshCw,
  Settings,
  Palette,
  Upload,
  Image,
  Paperclip,
  Wifi,
  WifiOff,
  Plus,
  Users,
  MoreVertical,
  MapPin,
  Globe,
  ShieldCheck,
  ShieldAlert,
  KeyRound,
  Eye,
  EyeOff,
  Lock,
  UserX,
  AlertCircle,
  Volume2,
  VolumeX,
  Bell,
  BellRing,
} from "lucide-react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import {
  LocationMessageCard,
  LocationPickerModal,
  type LocationData,
} from "./components/LocationComponents";
import { WelcomeAuthFlow } from "./components/WelcomeAuthFlow";
import { WORLD_LANGUAGES } from "./data/languages";
import { getTranslations } from "./data/translations";
import {
  initFCM,
  requestNotificationPermissionAndGetToken,
  sendFCMNotification,
  onForegroundFCMMessage,
  getStoredFCMToken,
  type TokenDiagnosticResult,
} from "./fcm";
import { playNotificationChime, triggerNotificationVibration } from "./sound";

// WebView Cookie-based Persistence Fix
export const setCookie = (name: string, value: string, days = 365) => {
  const d = new Date();
  d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
  const expires = "expires=" + d.toUTCString();
  document.cookie = name + "=" + encodeURIComponent(value) + ";" + expires + ";path=/";
};

export const getCookie = (name: string) => {
  const nameEQ = name + "=";
  const ca = document.cookie.split(';');
  for(let i=0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) return decodeURIComponent(c.substring(nameEQ.length, c.length));
  }
  return null;
};

export const removeCookie = (name: string) => {
  document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
};

const StorageManager = {
  getItem: (key: string) => {
    return getCookie(key) || window.localStorage.getItem(key);
  },
  setItem: (key: string, value: string) => {
    setCookie(key, value);
    window.localStorage.setItem(key, value);
  },
  removeItem: (key: string) => {
    removeCookie(key);
    window.localStorage.removeItem(key);
  }
};

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  phoneNumber?: string;
}

export interface AppUser {
  uid: string;
  displayName: string | null;
  photoURL: string | null;
  email: string | null;
  phoneNumber?: string | null;
}

interface ChatSession {
  id: string;
  participants: string[];
  lastMessage?: string;
  lastMessageAt?: any;
  lastMessageSender?: string;
  background?: string;
  participantDetails?: {
    [uid: string]: {
      displayName: string;
      photoURL: string;
    };
  };
  isGroup?: boolean;
  groupName?: string;
  groupImage?: string;
  groupAdmin?: string; // uid of the creator
  allowMembersToRename?: boolean;
  typingUsers?: string[];
}

interface Message {
  id: string;
  text?: string;
  audioData?: string;
  audioDuration?: number;
  uid: string;
  displayName: string;
  photoURL: string;
  createdAt: any;
  isCallLog?: boolean;
  deletedFor?: string[];
  readBy?: string[];
  mediaData?: string;
  mediaType?: "image" | "video";
  location?: LocationData;
}

const POPULAR_EMOJIS = [
  "❤️",
  "😂",
  "👍",
  "😍",
  "🙏",
  "🔥",
  "😮",
  "😢",
  "🎉",
  "✨",
  "👌",
  "👏",
];

function useLongPress(callback: () => void, ms: number = 500) {
  const [startLongPress, setStartLongPress] = useState(false);
  const timeoutRef = useRef<any>(null);

  useEffect(() => {
    if (startLongPress) {
      timeoutRef.current = setTimeout(callback, ms);
    } else {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    }
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [callback, ms, startLongPress]);

  return {
    onMouseDown: () => setStartLongPress(true),
    onMouseUp: () => setStartLongPress(false),
    onMouseLeave: () => setStartLongPress(false),
    onTouchStart: () => setStartLongPress(true),
    onTouchEnd: () => setStartLongPress(false),
  };
}

export default function App() {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedLanguageCode, setSelectedLanguageCode] = useState<string>(() => {
    return StorageManager.getItem("adam_chat_language") || "ar";
  });
  const hasSyncedProfile = useRef(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // طلب إذن الإشعارات واستخراج رمز الجهاز FCM Token عند تسجيل دخول المستخدم
  useEffect(() => {
    if (!user?.uid) return;

    const timer = setTimeout(() => {
      initFCM();
      requestNotificationPermissionAndGetToken(user.uid);
    }, 2000);

    // الاستماع للإشعارات في وضع الـ Foreground (أثناء فتح التطبيق)
    const unsubscribeForeground = onForegroundFCMMessage((payload) => {
      console.log("Foreground message received in App UI:", payload);
      const senderUid = payload?.data?.senderUid;
      // لا تشغل الصوت إذا كان المرسل هو نفس المستخدم الحالي
      if (senderUid && senderUid === user.uid) return;
      playNotificationChime();
      triggerNotificationVibration();
    });

    return () => {
      clearTimeout(timer);
      unsubscribeForeground();
    };
  }, [user?.uid]);

  useEffect(() => {
    let isInitialAuthResolved = false;

    // 1. Synchronously check local storage/cookies first to prevent flash
    const savedLocalUser = StorageManager.getItem("adam_chat_user");
    if (savedLocalUser) {
      try {
        const parsed = JSON.parse(savedLocalUser);
        if (parsed && parsed.uid && parsed.displayName) {
          // Immediately set user to bypass login screen
          setUser(parsed);
          setLoading(false); 
          isInitialAuthResolved = true;

          // Background check if user still exists in Firestore
          const checkDb = async () => {
            try {
              const userRef = doc(db, "users", parsed.uid);
              const userSnap = await getDoc(userRef);
              if (!userSnap.exists()) {
                console.log("Local user was deleted from database, resetting session");
                StorageManager.removeItem("adam_chat_user");
                StorageManager.removeItem("adam_chat_user_uid");
                StorageManager.removeItem(`adam_chat_profile_completed_${parsed.uid}`);
                setUser(null);
              }
            } catch (err) {
              // In case of network check failure, keep cached
            }
          };
          checkDb();
        }
      } catch (e) {
        console.warn("Failed to parse local user profile:", e);
      }
    }

    // 2. Listen for Firebase Auth if user previously signed in or has an active session
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        if (!hasSyncedProfile.current) {
          hasSyncedProfile.current = true;
          try {
            const userRef = doc(db, "users", currentUser.uid);
            const userDoc = await getDoc(userRef);

            let pUrl =
              currentUser.photoURL ||
              `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.displayName || "User")}&background=6366f1&color=fff&size=256&bold=true`;
            let dName = currentUser.displayName || "مستخدم";
            let isProfileCompleted = false;
            let phoneNum: string | null = null;

            if (userDoc.exists()) {
              const data = userDoc.data();
              if (data.photoURL) pUrl = data.photoURL;
              if (data.displayName) dName = data.displayName;
              if (data.phoneNumber) phoneNum = data.phoneNumber;
              if (data.profileCompleted === true) {
                isProfileCompleted = true;
              }
            }

            const localFlag =
              StorageManager.getItem(`adam_chat_profile_completed_${currentUser.uid}`) === "true";

            if (isProfileCompleted || localFlag) {
              const activeUser: AppUser = {
                uid: currentUser.uid,
                displayName: dName,
                photoURL: pUrl,
                email: currentUser.email || `${dName.toLowerCase().replace(/\s+/g, "")}@adamchat.app`,
                phoneNumber: phoneNum,
              };
              setUser(activeUser);
              StorageManager.setItem("adam_chat_user", JSON.stringify(activeUser));
            }
          } catch (error) {
            console.error("Error syncing profile:", error);
          }
        }
      }
      
      if (!isInitialAuthResolved) {
        setLoading(false);
        isInitialAuthResolved = true;
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleCompleteWelcome = async ({
    firstName,
    lastName,
    phoneNumber,
    photoURL,
  }: {
    firstName: string;
    lastName: string;
    phoneNumber: string;
    photoURL: string;
  }) => {
    const cleanFirst = firstName.trim();
    const cleanLast = lastName.trim();
    const fullName = `${cleanFirst} ${cleanLast}`.trim();
    const cleanPhone = phoneNumber.trim();
    const finalPhoto =
      photoURL ||
      `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=6366f1&color=fff&size=256&bold=true`;

    // Retrieve or generate a persistent local user UID
    let uid = StorageManager.getItem("adam_chat_user_uid");
    if (!uid) {
      uid = "usr_" + Math.random().toString(36).substring(2, 10) + "_" + Date.now().toString(36);
      StorageManager.setItem("adam_chat_user_uid", uid);
    }

    const email = `${cleanFirst.toLowerCase().replace(/[^a-z0-9]/g, "") || "user"}@adamchat.app`;

    const appUser: AppUser = {
      uid,
      displayName: fullName,
      photoURL: finalPhoto,
      email,
      phoneNumber: cleanPhone,
    };

    // If Firebase Auth currentUser is present, update non-fatally
    if (auth.currentUser) {
      try {
        await updateProfile(auth.currentUser, {
          displayName: fullName,
          photoURL: finalPhoto.startsWith("data:") ? undefined : finalPhoto,
        });
      } catch (e) {
        console.warn("updateProfile optional:", e);
      }
    }

    // Save user profile directly into Firestore
    await setDoc(
      doc(db, "users", uid),
      {
        uid,
        displayName: fullName,
        firstName: cleanFirst,
        lastName: cleanLast,
        email,
        phoneNumber: cleanPhone,
        photoURL: finalPhoto,
        profileCompleted: true,
        updatedAt: serverTimestamp(),
      },
      { merge: true },
    );

    StorageManager.setItem("adam_chat_user", JSON.stringify(appUser));
    StorageManager.setItem(`adam_chat_profile_completed_${uid}`, "true");
    setUser(appUser);
    hasSyncedProfile.current = true;
  };

  if (loading) {
    const isLoadingRtl = ["ar", "fa", "ur", "he", "ku", "ps"].includes(selectedLanguageCode);
    return (
      <div className="flex flex-col h-screen h-[100dvh] items-center justify-center bg-[#09090b] text-white">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="flex flex-col items-center gap-6"
        >
          <div className="relative">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center shadow-2xl shadow-indigo-500/20">
              <MessageCircle className="w-12 h-12 text-white" />
            </div>
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
              className="absolute -inset-1 rounded-3xl border-2 border-indigo-500/30 border-t-indigo-400"
            />
          </div>
          <div className="flex flex-col items-center gap-2">
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
              {isLoadingRtl ? "آدم تشات" : "Adam Chat"}
            </h1>
            <p className="text-sm text-zinc-500">
              {isLoadingRtl ? "جاري الاتصال والتحقق..." : "Connecting..."}
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <WelcomeAuthFlow
        onComplete={handleCompleteWelcome}
        onLanguageSelected={(lang) => {
          setSelectedLanguageCode(lang.code);
          StorageManager.setItem("adam_chat_language", lang.code);
          document.documentElement.lang = lang.code;
          const isRtl =
            lang.dir === "rtl" ||
            lang.code === "ar" ||
            lang.code === "fa" ||
            lang.code === "ur" ||
            lang.code === "he" ||
            lang.code === "ku" ||
            lang.code === "ps";
          document.documentElement.dir = isRtl ? "rtl" : "ltr";
        }}
      />
    );
  }

  return (
    <>
      <ChatDashboard
        user={user}
        setUser={setUser}
        isOnline={isOnline}
        selectedLanguageCode={selectedLanguageCode}
        onLanguageChange={(code) => {
          setSelectedLanguageCode(code);
          StorageManager.setItem("adam_chat_language", code);
          document.documentElement.lang = code;
          const langObj = WORLD_LANGUAGES.find((l) => l.code === code);
          const isRtl =
            langObj?.dir === "rtl" ||
            code === "ar" ||
            code === "fa" ||
            code === "ur" ||
            code === "he" ||
            code === "ku" ||
            code === "ps";
          document.documentElement.dir = isRtl ? "rtl" : "ltr";
        }}
      />
    </>
  );
}

function ChatDashboard({
  user,
  setUser,
  isOnline,
  selectedLanguageCode,
  onLanguageChange,
}: {
  user: AppUser;
  setUser: React.Dispatch<React.SetStateAction<AppUser | null>>;
  isOnline: boolean;
  selectedLanguageCode: string;
  onLanguageChange: (code: string) => void;
}) {
  const t = React.useMemo(() => getTranslations(selectedLanguageCode), [selectedLanguageCode]);
  const isRtl = React.useMemo(() => {
    const langObj = WORLD_LANGUAGES.find((l) => l.code === selectedLanguageCode);
    return (
      langObj?.dir === "rtl" ||
      selectedLanguageCode === "ar" ||
      selectedLanguageCode === "fa" ||
      selectedLanguageCode === "ur" ||
      selectedLanguageCode === "he" ||
      selectedLanguageCode === "ku" ||
      selectedLanguageCode === "ps"
    );
  }, [selectedLanguageCode]);

  const [chats, setChats] = useState<ChatSession[]>([]);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [searching, setSearching] = useState(false);
  const [activeTab, setActiveTab] = useState<"chats" | "groups">("chats");
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [selectedUsersForGroup, setSelectedUsersForGroup] = useState<string[]>([]);
  const [showGroupSettings, setShowGroupSettings] = useState(false);
  const [tempGroupName, setTempGroupName] = useState("");
  const [tempGroupImage, setTempGroupImage] = useState("");
  const [tempAllowRename, setTempAllowRename] = useState(false);
  const [showGroupContextMenu, setShowGroupContextMenu] = useState(false);
  const [contextMenuGroupId, setContextMenuGroupId] = useState<string | null>(null);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [showBackgroundSettings, setShowBackgroundSettings] = useState(false);
  const [tempBackground, setTempBackground] = useState("");
  const [isUploadingBg, setIsUploadingBg] = useState(false);

  const handleBgFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingBg(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        // Max dimension of 800px to keep base64 string size well under 1MB Firestore limit
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          // Compress as JPEG with 0.6 quality to guarantee a very small file size
          const dataUrl = canvas.toDataURL("image/jpeg", 0.6);
          setTempBackground(dataUrl);
        }
        setIsUploadingBg(false);
      };
      img.onerror = () => {
        console.error("Error loading image file for scaling");
        setIsUploadingBg(false);
      };
      img.src = event.target?.result as string;
    };
    reader.onerror = () => {
      console.error("Error reading file");
      setIsUploadingBg(false);
    };
    reader.readAsDataURL(file);
  };

  const currentUserProfile = allUsers.find((u) => u.uid === user.uid) || {
    displayName: user.displayName,
    photoURL: user.photoURL,
    phoneNumber: user.phoneNumber || "",
  };

  const [showSettings, setShowSettings] = useState(false);
  const [editDisplayName, setEditDisplayName] = useState("");
  const [editPhotoURL, setEditPhotoURL] = useState("");
  const [editPhoneNumber, setEditPhoneNumber] = useState("");
  const [phoneChangeAdminPassword, setPhoneChangeAdminPassword] = useState("");
  const [settingsError, setSettingsError] = useState<string | null>(null);
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  // Add Friend By Phone modal state
  const [showAddFriendModal, setShowAddFriendModal] = useState(false);
  const [friendPhoneInput, setFriendPhoneInput] = useState("");
  const [friendSearchResult, setFriendSearchResult] = useState<UserProfile | null>(null);
  const [hasSearchedFriend, setHasSearchedFriend] = useState(false);
  const [isSearchingFriend, setIsSearchingFriend] = useState(false);
  const [searchFriendError, setSearchFriendError] = useState<string | null>(null);

  const handleSearchFriendByPhone = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = friendPhoneInput.trim();
    if (!clean) return;

    setIsSearchingFriend(true);
    setSearchFriendError(null);
    setHasSearchedFriend(false);
    setFriendSearchResult(null);

    try {
      // 1. Exact match query
      const q = query(
        collection(db, "users"),
        where("phoneNumber", "==", clean)
      );
      const querySnapshot = await getDocs(q);

      let matchedUser: UserProfile | null = null;

      if (!querySnapshot.empty) {
        querySnapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (data.uid !== user.uid) {
            matchedUser = data as UserProfile;
          }
        });
      }

      // 2. Fallback search among allUsers or digits matching
      if (!matchedUser) {
        const digitsOnly = clean.replace(/\D/g, "");
        if (digitsOnly.length >= 3) {
          const found = allUsers.find((u) => {
            if (u.uid === user.uid || !u.phoneNumber) return false;
            const uDigits = String(u.phoneNumber).replace(/\D/g, "");
            return (
              uDigits === digitsOnly ||
              (uDigits.length >= 5 &&
                (uDigits.endsWith(digitsOnly) || digitsOnly.endsWith(uDigits)))
            );
          });
          if (found) {
            matchedUser = found;
          }
        }
      }

      if (matchedUser) {
        setFriendSearchResult(matchedUser);
      } else {
        setFriendSearchResult(null);
      }
      setHasSearchedFriend(true);
    } catch (err: any) {
      console.error("Error searching friend by phone:", err);
      setSearchFriendError(err.message || (isRtl ? "حدث خطأ أثناء البحث عن الرقم" : "Error searching phone number"));
      setHasSearchedFriend(true);
    } finally {
      setIsSearchingFriend(false);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new window.Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          const MAX_SIZE = 256;
          let width = img.width;
          let height = img.height;
          if (width > height) {
            if (width > MAX_SIZE) {
              height *= MAX_SIZE / width;
              width = MAX_SIZE;
            }
          } else {
            if (height > MAX_SIZE) {
              width *= MAX_SIZE / height;
              height = MAX_SIZE;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx?.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.6);
          setEditPhotoURL(dataUrl);
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const saveSettings = async () => {
    if (!user) return;
    setSettingsError(null);

    const cleanPhone = editPhoneNumber.replace(/\D/g, "");
    if (cleanPhone.length !== 10) {
      setSettingsError(
        isRtl
          ? "يجب أن يتكون رقم الهاتف من 10 أرقام فقط (لا أكثر ولا أقل)"
          : "Phone number must consist of exactly 10 digits"
      );
      return;
    }

    const originalPhone = (currentUserProfile.phoneNumber || user.phoneNumber || "").replace(/\D/g, "");
    if (originalPhone && cleanPhone !== originalPhone) {
      if (phoneChangeAdminPassword !== "1111Q897560") {
        setSettingsError(
          isRtl
            ? "كلمة سر تصريح المسؤول غير صحيحة. لا يمكن تغيير رقم الهاتف المسجل مسبقاً إلا بكلمة سر المسؤول."
            : "Invalid admin authorization password. Changing registered phone number requires admin password."
        );
        return;
      }
    }

    // Check if duplicate phone number exists in users collection
    try {
      const q = query(collection(db, "users"), where("phoneNumber", "==", cleanPhone));
      const snap = await getDocs(q);
      let duplicate = false;
      snap.forEach((d) => {
        if (d.id !== user.uid) duplicate = true;
      });
      if (duplicate) {
        setSettingsError(
          isRtl
            ? "هذا الرقم مسجل بالفعل لمستخدم آخر"
            : "This phone number is already registered to another user"
        );
        return;
      }
    } catch (e) {
      console.warn("Phone duplicate check:", e);
    }

    setIsSavingSettings(true);
    try {
      if (auth.currentUser) {
        const profileUpdates: any = { displayName: editDisplayName };
        if (editPhotoURL && editPhotoURL.length < 2000) {
          profileUpdates.photoURL = editPhotoURL;
        }
        try {
          await updateProfile(auth.currentUser, profileUpdates);
        } catch (e) {
          console.warn("Optional updateProfile:", e);
        }
      }

      await setDoc(
        doc(db, "users", user.uid),
        {
          displayName: editDisplayName,
          photoURL: editPhotoURL,
          phoneNumber: cleanPhone,
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );

      const updatedUser: AppUser = {
        ...user,
        displayName: editDisplayName,
        photoURL: editPhotoURL || user.photoURL,
        phoneNumber: cleanPhone,
      };
      setUser(updatedUser);
      StorageManager.setItem("adam_chat_user", JSON.stringify(updatedUser));

      setShowSettings(false);
    } catch (error) {
      console.error("Error updating profile:", error);
      setSettingsError(isRtl ? "حدث خطأ أثناء حفظ الإعدادات" : "Failed to save settings");
    } finally {
      setIsSavingSettings(false);
    }
  };

  // User Self-Account Deletion (Confirmation only, no password needed)
  const [showSelfDeleteConfirm, setShowSelfDeleteConfirm] = useState(false);
  const [isDeletingSelf, setIsDeletingSelf] = useState(false);

  const handleConfirmSelfDelete = async () => {
    if (!user) return;
    setIsDeletingSelf(true);
    try {
      // 1. Delete user from Firestore
      await deleteDoc(doc(db, "users", user.uid));

      // 2. Clean up any chats involving this user
      try {
        const chatsSnap = await getDocs(collection(db, "chats"));
        for (const chatDoc of chatsSnap.docs) {
          const data = chatDoc.data();
          const participants: string[] = data.participants || [];
          if (participants.includes(user.uid) || chatDoc.id.includes(user.uid)) {
            const msgsSnap = await getDocs(collection(db, "chats", chatDoc.id, "messages"));
            for (const mDoc of msgsSnap.docs) {
              await deleteDoc(doc(db, "chats", chatDoc.id, "messages", mDoc.id));
            }
            await deleteDoc(doc(db, "chats", chatDoc.id));
          }
        }
      } catch (chatErr) {
        console.warn("Non-fatal chat cleanup:", chatErr);
      }

      setShowSettings(false);
      setShowSelfDeleteConfirm(false);
      StorageManager.removeItem(`adam_chat_profile_completed_${user.uid}`);
      StorageManager.removeItem("adam_chat_user");
      StorageManager.removeItem("adam_chat_user_uid");
      signOut(auth).catch(() => {});
      setUser(null);
    } catch (error) {
      console.error("Failed to delete self account:", error);
    } finally {
      setIsDeletingSelf(false);
    }
  };

  // Admin Authorization & Account Deletion for Other Users (Secret: 1111Q897560)
  const ADMIN_SECRET_KEY = "1111Q897560";
  const [adminAuthModal, setAdminAuthModal] = useState<{
    isOpen: boolean;
    targetUser: { uid: string; displayName: string } | null;
  }>({
    isOpen: false,
    targetUser: null,
  });
  const [adminPasswordInput, setAdminPasswordInput] = useState("");
  const [adminPasswordError, setAdminPasswordError] = useState("");
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);

  const openAdminDeleteModal = (targetUser: { uid: string; displayName: string }) => {
    setAdminAuthModal({
      isOpen: true,
      targetUser,
    });
    setAdminPasswordInput("");
    setAdminPasswordError("");
    setShowAdminPassword(false);
  };

  const handleConfirmAdminDelete = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (adminPasswordInput.trim() !== ADMIN_SECRET_KEY) {
      setAdminPasswordError(
        isRtl
          ? "كلمة مرور المسؤول غير صحيحة! يرجى إدخال كلمة المرور الصحيحة لحذف حساب المستخدم."
          : "Invalid administrator password! Please enter the correct password to delete this user account."
      );
      return;
    }

    if (!adminAuthModal.targetUser) return;
    setIsDeletingAccount(true);
    try {
      const target = adminAuthModal.targetUser;
      // 1. Delete user from Firestore
      await deleteDoc(doc(db, "users", target.uid));

      // 2. Clean up any chats involving this user
      try {
        const chatsSnap = await getDocs(collection(db, "chats"));
        for (const chatDoc of chatsSnap.docs) {
          const data = chatDoc.data();
          const participants: string[] = data.participants || [];
          if (participants.includes(target.uid) || chatDoc.id.includes(target.uid)) {
            const msgsSnap = await getDocs(collection(db, "chats", chatDoc.id, "messages"));
            for (const mDoc of msgsSnap.docs) {
              await deleteDoc(doc(db, "chats", chatDoc.id, "messages", mDoc.id));
            }
            await deleteDoc(doc(db, "chats", chatDoc.id));
          }
        }
      } catch (chatErr) {
        console.warn("Non-fatal chat cleanup:", chatErr);
      }

      setAdminAuthModal({ isOpen: false, targetUser: null });
      setAdminPasswordInput("");
      setAdminPasswordError("");
    } catch (error) {
      console.error("Failed to delete user account:", error);
      setAdminPasswordError(
        isRtl
          ? "حدث خطأ أثناء محاولة الحذف، يرجى إعادة المحاولة."
          : "An error occurred while deleting, please try again."
      );
    } finally {
      setIsDeletingAccount(false);
    }
  };

  // Call status state
  const [activeCall, setActiveCall] = useState<any>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isSwappedVideo, setIsSwappedVideo] = useState(false);
  const [isAudioBlocked, setIsAudioBlocked] = useState(false);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const processedCandidates = useRef<Set<string>>(new Set());
  const pendingCandidatesRef = useRef<any[]>([]);
  const isSettingRemoteDescriptionRef = useRef(false);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const activeCallRef = useRef<any>(null);
  activeCallRef.current = activeCall;
  const isAcceptingCallRef = useRef(false);

  // Dedicated audio playback refs for guaranteed sound transmission
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const remoteCandidatesSubUnsubRef = useRef<(() => void) | null>(null);

  const RTC_CONFIG: RTCConfiguration = {
    iceServers: [
      { urls: "stun:stun.l.google.com:19302" },
      { urls: "stun:stun1.l.google.com:19302" },
      { urls: "stun:stun2.l.google.com:19302" },
      { urls: "stun:stun3.l.google.com:19302" },
      { urls: "stun:stun4.l.google.com:19302" },
      { urls: "stun:stun.cloudflare.com:3478" },
      { urls: "stun:global.stun.twilio.com:3478" },
      {
        urls: [
          "turn:openrelay.metered.ca:80",
          "turn:openrelay.metered.ca:443",
          "turn:openrelay.metered.ca:443?transport=tcp",
        ],
        username: "openrelayproject",
        credential: "openrelayproject",
      },
    ],
    iceCandidatePoolSize: 10,
  };

  const unlockAudio = useCallback(() => {
    const stream = remoteStreamRef.current;
    if (remoteAudioRef.current) {
      const audioEl = remoteAudioRef.current;
      if (stream && audioEl.srcObject !== stream) {
        audioEl.srcObject = stream;
      }
      audioEl.muted = false;
      audioEl.volume = 1.0;
      audioEl
        .play()
        .then(() => {
          setIsAudioBlocked(false);
        })
        .catch(() => {});
    }
  }, []);

  const playRemoteAudio = useCallback((stream: MediaStream) => {
    if (!stream) return;

    // Ensure all audio tracks are active
    const audioTracks = stream.getAudioTracks();
    audioTracks.forEach((track) => {
      track.enabled = true;
    });

    // Single dedicated HTMLAudioElement pipeline - avoids duplicate audio playback & echo
    if (remoteAudioRef.current) {
      const audioEl = remoteAudioRef.current;
      if (audioEl.srcObject !== stream) {
        audioEl.srcObject = stream;
      }
      audioEl.muted = false;
      audioEl.volume = 1.0;
      const playPromise = audioEl.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsAudioBlocked(false);
          })
          .catch((err) => {
            console.warn("Audio autoplay blocked by browser policy:", err);
            setIsAudioBlocked(true);
          });
      }
    }
  }, []);

  const applyRemoteCandidate = async (pc: RTCPeerConnection, cand: any) => {
    if (!cand || !cand.candidate) return;
    const candStr = typeof cand === "string" ? cand : JSON.stringify(cand);
    if (processedCandidates.current.has(candStr)) return;
    processedCandidates.current.add(candStr);

    if (pc.remoteDescription && pc.remoteDescription.type) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(cand));
      } catch (err) {
        console.warn("Could not apply ICE candidate immediately:", err);
        pendingCandidatesRef.current.push(cand);
        processedCandidates.current.delete(candStr);
      }
    } else {
      pendingCandidatesRef.current.push(cand);
    }
  };

  const drainCandidates = async (
    pc: RTCPeerConnection,
    candidates?: any[],
  ) => {
    if (!pc.remoteDescription || !pc.remoteDescription.type) return;
    const toProcess = [
      ...(candidates || []),
      ...pendingCandidatesRef.current,
    ];
    pendingCandidatesRef.current = [];
    for (const cand of toProcess) {
      if (cand && cand.candidate) {
        const candStr = typeof cand === "string" ? cand : JSON.stringify(cand);
        try {
          await pc.addIceCandidate(new RTCIceCandidate(cand));
          processedCandidates.current.add(candStr);
        } catch (err) {
          console.warn("Failed draining candidate:", err);
        }
      }
    }
  };

  const cleanupCall = useCallback(() => {
    isAcceptingCallRef.current = false;
    if (remoteCandidatesSubUnsubRef.current) {
      remoteCandidatesSubUnsubRef.current();
      remoteCandidatesSubUnsubRef.current = null;
    }
    if (audioSourceNodeRef.current) {
      try {
        audioSourceNodeRef.current.disconnect();
      } catch (e) {}
      audioSourceNodeRef.current = null;
    }
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close();
      } catch (e) {}
      audioContextRef.current = null;
    }
    if (remoteAudioRef.current) {
      try {
        remoteAudioRef.current.pause();
        remoteAudioRef.current.srcObject = null;
      } catch (e) {}
    }
    if (pcRef.current) {
      try {
        pcRef.current.close();
      } catch (e) {
        console.error("Error closing peer connection:", e);
      }
      pcRef.current = null;
    }
    if (localStreamRef.current) {
      try {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
      } catch (e) {
        console.error("Error stopping tracks on localStreamRef:", e);
      }
      localStreamRef.current = null;
    }
    if (remoteStreamRef.current) {
      try {
        remoteStreamRef.current.getTracks().forEach((track) => track.stop());
      } catch (e) {}
      remoteStreamRef.current = null;
    }
    setLocalStream(null);
    setRemoteStream(null);
    setActiveCall(null);
    setCallDuration(0);
    setIsMuted(false);
    setIsVideoOff(false);
    setIsSwappedVideo(false);
    setIsAudioBlocked(false);
    processedCandidates.current.clear();
    pendingCandidatesRef.current = [];
    isSettingRemoteDescriptionRef.current = false;
  }, []);

  const toggleBrowserFullscreen = () => {
    try {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(() => {});
      } else {
        document.exitFullscreen?.().catch(() => {});
      }
    } catch (e) {
      console.error("Error toggling fullscreen:", e);
    }
  };

  // End call immediately if window/tab is closed
  useEffect(() => {
    const handleBeforeUnload = () => {
      const currentCall = activeCallRef.current;
      if (currentCall?.id) {
        try {
          setDoc(
            doc(db, "calls", currentCall.id),
            { status: "ended", endedAt: serverTimestamp() },
            { merge: true },
          );
        } catch (e) {}
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, []);

  // A. Listen for incoming calls
  useEffect(() => {
    if (!user) return;

    // Listen for incoming calls for the current user
    const q = query(
      collection(db, "calls"),
      where("receiverId", "==", user.uid),
      where("status", "==", "ringing"),
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const callDoc = snapshot.docs[0];
        const current = activeCallRef.current;
        if (!current || current.id === callDoc.id) {
          setActiveCall({ id: callDoc.id, ...callDoc.data() });
        }
      } else {
        // If caller cancelled or ended call while ringing, dismiss ONLY if receiver is not answering
        const current = activeCallRef.current;
        if (
          current &&
          current.status === "ringing" &&
          current.receiverId === user.uid &&
          !isAcceptingCallRef.current
        ) {
          cleanupCall();
        }
      }
    });

    return unsubscribe;
  }, [user, cleanupCall]);

  // B. Unified listener for call status changes & subcollection candidate delivery
  useEffect(() => {
    if (!activeCall?.id) return;

    const callDocId = activeCall.id;
    const isCaller = activeCall.callerId === user.uid;
    const targetSub = isCaller ? "receiverCandidates" : "callerCandidates";

    // 1. Listen for main call document updates
    const unsubscribeDoc = onSnapshot(
      doc(db, "calls", callDocId),
      async (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();

          // Handle ended or rejected transitions
          if (
            data.status === "ended" ||
            data.status === "rejected" ||
            data.status === "cancelled"
          ) {
            cleanupCall();
            return;
          }

          // Handle answer transition for caller
          if (data.callerId === user.uid && data.answer) {
            const pc = pcRef.current;
            if (
              pc &&
              pc.signalingState === "have-local-offer" &&
              !isSettingRemoteDescriptionRef.current
            ) {
              isSettingRemoteDescriptionRef.current = true;
              try {
                await pc.setRemoteDescription(
                  new RTCSessionDescription(data.answer),
                );
                await drainCandidates(pc, data.receiverCandidates);
                try {
                  const snap = await getDocs(
                    collection(db, "calls", callDocId, "receiverCandidates"),
                  );
                  for (const d of snap.docs) {
                    await applyRemoteCandidate(pc, d.data());
                  }
                } catch (e) {}
                unlockAudio();
              } catch (err) {
                console.error(
                  "Error setting remote description on caller:",
                  err,
                );
                isSettingRemoteDescriptionRef.current = false;
              }
            }
          }

          // Process array-based ICE candidates if present
          const remoteCandidates =
            data.callerId === user.uid
              ? data.receiverCandidates
              : data.callerCandidates;
          if (remoteCandidates && Array.isArray(remoteCandidates)) {
            const pc = pcRef.current;
            if (pc && pc.remoteDescription && pc.remoteDescription.type) {
              for (const cand of remoteCandidates) {
                await applyRemoteCandidate(pc, cand);
              }
            } else {
              for (const cand of remoteCandidates) {
                if (cand && cand.candidate) {
                  pendingCandidatesRef.current.push(cand);
                }
              }
            }
          }

          setActiveCall({ id: docSnap.id, ...data });
        } else {
          // Doc deleted
          cleanupCall();
        }
      },
      (err) => console.warn("Error in call doc listener:", err)
    );

    // 2. Real-time subcollection candidate listener for instant ICE connectivity
    const unsubscribeSub = onSnapshot(
      collection(db, "calls", callDocId, targetSub),
      (snapshot) => {
        snapshot.docChanges().forEach(async (change) => {
          if (change.type === "added") {
            const cand = change.doc.data();
            const pc = pcRef.current;
            if (pc && pc.remoteDescription && pc.remoteDescription.type) {
              await applyRemoteCandidate(pc, cand);
            } else if (cand && cand.candidate) {
              pendingCandidatesRef.current.push(cand);
            }
          }
        });
      },
      (err) => console.warn("Error in candidates subcollection listener:", err)
    );

    remoteCandidatesSubUnsubRef.current = unsubscribeSub;

    return () => {
      unsubscribeDoc();
      unsubscribeSub();
      if (remoteCandidatesSubUnsubRef.current === unsubscribeSub) {
        remoteCandidatesSubUnsubRef.current = null;
      }
    };
  }, [activeCall?.id, user.uid, cleanupCall, unlockAudio]);

  // C. Call Timer
  useEffect(() => {
    let timer: any;
    if (activeCall && activeCall.status === "connected") {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(timer);
  }, [activeCall?.status]);

  // Clean up media tracks when localStream changes
  useEffect(() => {
    return () => {
      if (localStream) {
        localStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [localStream]);

  const formatDuration = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const logCallInChat = async (
    call: any,
    callResult: "missed" | "completed",
  ) => {
    const p1 = call.callerId;
    const p2 = call.receiverId;
    const chatId = p1 < p2 ? `${p1}_${p2}` : `${p2}_${p1}`;

    let logText = "";
    if (call.type === "video") {
      logText =
        callResult === "missed"
          ? "📹 مكالمة فيديو فائتة"
          : `📹 مكالمة فيديو (${formatDuration(callDuration)})`;
    } else {
      logText =
        callResult === "missed"
          ? "📞 مكالمة صوتية فائتة"
          : `📞 مكالمة صوتية (${formatDuration(callDuration)})`;
    }

    try {
      await addDoc(collection(db, "chats", chatId, "messages"), {
        text: logText,
        uid: call.callerId,
        displayName: call.callerName,
        photoURL: call.callerPhoto,
        createdAt: serverTimestamp(),
        isCallLog: true,
      });

      await setDoc(
        doc(db, "chats", chatId),
        {
          participants: [p1, p2],
          lastMessage: logText,
          lastMessageAt: serverTimestamp(),
          lastMessageSender: call.callerId,
          participantDetails: {
            [p1]: {
              displayName: call.callerName || "مستخدم",
              photoURL: call.callerPhoto || "",
            },
            [p2]: {
              displayName: call.receiverName || "مستخدم",
              photoURL: call.receiverPhoto || "",
            },
          },
        },
        { merge: true },
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `chats/${chatId}`);
    }
  };

  // D. Actions
  const initiateCall = async (type: "audio" | "video") => {
    if (!chatPartnerUid || !chatPartner) return;

    const callId = `call_${user.uid}_${Date.now()}`;
    const callData: any = {
      callerId: user.uid,
      callerName: currentUserProfile.displayName || "مستخدم",
      callerPhoto:
        currentUserProfile.photoURL ||
        `https://ui-avatars.com/api/?name=${currentUserProfile.displayName || "User"}`,
      receiverId: chatPartnerUid,
      receiverName: chatPartner.displayName,
      receiverPhoto: chatPartner.photoURL,
      type,
      status: "ringing",
      createdAt: serverTimestamp(),
    };

    try {
      const isVideo = type === "video";
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: { ideal: true },
            noiseSuppression: { ideal: true },
            autoGainControl: { ideal: true },
            channelCount: { ideal: 1 },
          },
          video: isVideo
            ? {
                width: { ideal: 1280, max: 1920 },
                height: { ideal: 720, max: 1080 },
                facingMode: "user",
              }
            : false,
        });
      } catch (err) {
        console.warn("Falling back to basic constraints in initiateCall:", err);
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: isVideo,
        });
      }

      // Ensure local audio is unmuted and enabled
      stream.getAudioTracks().forEach((t) => {
        t.enabled = true;
      });

      localStreamRef.current = stream;
      setLocalStream(stream);

      const pc = new RTCPeerConnection(RTC_CONFIG);
      pcRef.current = pc;

      pc.onconnectionstatechange = () => {
        console.log("WebRTC caller connection state:", pc.connectionState);
      };
      pc.oniceconnectionstatechange = () => {
        console.log("WebRTC caller ICE state:", pc.iceConnectionState);
      };

      stream.getTracks().forEach((track) => {
        pc.addTrack(track, stream);
      });

      pc.ontrack = (event) => {
        console.log("WebRTC ontrack received (caller):", event.track.kind, event.track.id);
        event.track.enabled = true;

        const remoteMediaStream =
          event.streams && event.streams[0]
            ? event.streams[0]
            : (remoteStreamRef.current || new MediaStream([event.track]));

        remoteStreamRef.current = remoteMediaStream;
        remoteMediaStream.getAudioTracks().forEach((t) => {
          t.enabled = true;
        });

        setRemoteStream(remoteMediaStream);
        playRemoteAudio(remoteMediaStream);
      };

      let candidateQueue: any[] = [];
      let updateTimeout: any = null;

      const flushCandidates = async () => {
        if (candidateQueue.length === 0) return;
        const candidatesToSend = [...candidateQueue];
        candidateQueue = [];
        try {
          await setDoc(
            doc(db, "calls", callId),
            {
              callerCandidates: arrayUnion(...candidatesToSend),
            },
            { merge: true },
          );
        } catch (e) {
          console.error("Error sending ICE candidates batch:", e);
          candidateQueue = [...candidatesToSend, ...candidateQueue];
        }
      };

      pc.onicecandidate = (event) => {
        if (event.candidate && event.candidate.candidate) {
          const candJSON = event.candidate.toJSON();
          // Write to subcollection immediately for guaranteed real-time arrival
          addDoc(collection(db, "calls", callId, "callerCandidates"), candJSON).catch(() => {});
          // Also batch to main document array
          candidateQueue.push(candJSON);
          if (!updateTimeout) {
            updateTimeout = setTimeout(() => {
              updateTimeout = null;
              flushCandidates();
            }, 100);
          }
        } else if (!event.candidate) {
          if (updateTimeout) {
            clearTimeout(updateTimeout);
            updateTimeout = null;
          }
          flushCandidates();
        }
      };

      const offerDescription = await pc.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: isVideo,
      });
      await pc.setLocalDescription(offerDescription);

      callData.offer = {
        type: offerDescription.type,
        sdp: offerDescription.sdp,
      };

      await setDoc(doc(db, "calls", callId), callData, { merge: true });
      setActiveCall({ id: callId, ...callData });
    } catch (err) {
      console.error("Error initiating call:", err);
    }
  };

  const acceptCall = async () => {
    const currentCall = activeCallRef.current || activeCall;
    if (!currentCall?.id) return;
    try {
      isAcceptingCallRef.current = true;
      setActiveCall((prev: any) => ({ ...prev, status: "connected" }));
      // Direct user gesture unlocks audio permissions immediately
      unlockAudio();

      const isVideo = currentCall.type === "video";
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: { ideal: true },
            noiseSuppression: { ideal: true },
            autoGainControl: { ideal: true },
            channelCount: { ideal: 1 },
          },
          video: isVideo
            ? {
                width: { ideal: 1280, max: 1920 },
                height: { ideal: 720, max: 1080 },
                facingMode: "user",
              }
            : false,
        });
      } catch (err) {
        console.warn("Falling back to basic constraints in acceptCall:", err);
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: isVideo,
        });
      }

      // Ensure local audio is unmuted and enabled
      stream.getAudioTracks().forEach((t) => {
        t.enabled = true;
      });

      localStreamRef.current = stream;
      setLocalStream(stream);

      const pc = new RTCPeerConnection(RTC_CONFIG);
      pcRef.current = pc;

      pc.onconnectionstatechange = () => {
        console.log("WebRTC receiver connection state:", pc.connectionState);
      };
      pc.oniceconnectionstatechange = () => {
        console.log("WebRTC receiver ICE state:", pc.iceConnectionState);
      };

      stream.getTracks().forEach((track) => {
        pc.addTrack(track, stream);
      });

      pc.ontrack = (event) => {
        console.log("WebRTC ontrack received (receiver):", event.track.kind, event.track.id);
        event.track.enabled = true;

        const remoteMediaStream =
          event.streams && event.streams[0]
            ? event.streams[0]
            : (remoteStreamRef.current || new MediaStream([event.track]));

        remoteStreamRef.current = remoteMediaStream;
        remoteMediaStream.getAudioTracks().forEach((t) => {
          t.enabled = true;
        });

        setRemoteStream(remoteMediaStream);
        playRemoteAudio(remoteMediaStream);
      };

      let candidateQueue: any[] = [];
      let updateTimeout: any = null;

      const flushCandidates = async () => {
        if (candidateQueue.length === 0) return;
        const candidatesToSend = [...candidateQueue];
        candidateQueue = [];
        try {
          await setDoc(
            doc(db, "calls", currentCall.id),
            {
              receiverCandidates: arrayUnion(...candidatesToSend),
            },
            { merge: true },
          );
        } catch (e) {
          console.error("Error sending ICE candidates batch:", e);
          candidateQueue = [...candidatesToSend, ...candidateQueue];
        }
      };

      pc.onicecandidate = (event) => {
        if (event.candidate && event.candidate.candidate) {
          const candJSON = event.candidate.toJSON();
          // Write to subcollection immediately
          addDoc(collection(db, "calls", currentCall.id, "receiverCandidates"), candJSON).catch(() => {});
          candidateQueue.push(candJSON);
          if (!updateTimeout) {
            updateTimeout = setTimeout(() => {
              updateTimeout = null;
              flushCandidates();
            }, 100);
          }
        } else if (!event.candidate) {
          if (updateTimeout) {
            clearTimeout(updateTimeout);
            updateTimeout = null;
          }
          flushCandidates();
        }
      };

      let offerDescription = currentCall.offer;
      if (!offerDescription) {
        const snap = await getDoc(doc(db, "calls", currentCall.id));
        if (snap.exists()) {
          offerDescription = snap.data()?.offer;
        }
      }
      if (!offerDescription) {
        console.error("No offer found for call:", currentCall.id);
        return;
      }

      await pc.setRemoteDescription(
        new RTCSessionDescription(offerDescription),
      );
      await drainCandidates(pc, currentCall.callerCandidates);
      try {
        const callerCandDocs = await getDocs(
          collection(db, "calls", currentCall.id, "callerCandidates"),
        );
        for (const d of callerCandDocs.docs) {
          await applyRemoteCandidate(pc, d.data());
        }
      } catch (e) {}

      const answerDescription = await pc.createAnswer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: isVideo,
      });
      await pc.setLocalDescription(answerDescription);

      await setDoc(
        doc(db, "calls", currentCall.id),
        {
          answer: {
            type: answerDescription.type,
            sdp: answerDescription.sdp,
          },
          status: "connected",
          connectedAt: serverTimestamp(),
        },
        { merge: true },
      );
    } catch (err) {
      console.error("Error accepting call:", err);
    }
  };

  const rejectCall = async () => {
    const currentCall = activeCallRef.current || activeCall;
    if (!currentCall?.id) {
      cleanupCall();
      return;
    }
    try {
      await setDoc(
        doc(db, "calls", currentCall.id),
        {
          status: "rejected",
          endedAt: serverTimestamp(),
        },
        { merge: true },
      );
      await logCallInChat(currentCall, "missed");
    } catch (err) {
      console.error("Error rejecting call:", err);
    } finally {
      cleanupCall();
    }
  };

  const endCall = async () => {
    const currentCall = activeCallRef.current || activeCall;
    if (!currentCall?.id) {
      cleanupCall();
      return;
    }
    try {
      await setDoc(
        doc(db, "calls", currentCall.id),
        {
          status: "ended",
          endedAt: serverTimestamp(),
        },
        { merge: true },
      );
      await logCallInChat(
        currentCall,
        currentCall.status === "connected" ? "completed" : "missed",
      );
    } catch (err) {
      console.error("Error ending call:", err);
    } finally {
      cleanupCall();
    }
  };

  const toggleMute = () => {
    const stream = localStreamRef.current || localStream;
    if (stream) {
      const audioTrack = stream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    }
  };

  const toggleVideo = () => {
    const stream = localStreamRef.current || localStream;
    if (stream) {
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOff(!videoTrack.enabled);
      }
    }
  };

  // 1. Fetch user list for suggestion
  useEffect(() => {
    const q = query(collection(db, "users"), limit(50));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const usersList: UserProfile[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (
          data.uid !== "adam_ai" &&
          !data.uid?.includes("adam_ai") &&
          data.uid !== user.uid
        ) {
          usersList.push(data as UserProfile);
        }
      });
      setAllUsers(usersList);
    });
    return unsubscribe;
  }, [user.uid]);

  // 2. Fetch user's active chats
  useEffect(() => {
    const q = query(
      collection(db, "chats"),
      where("participants", "array-contains", user.uid),
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const activeChats: ChatSession[] = [];
        
        snapshot.forEach((doc) => {
          const data = doc.data();
          if (
            !data.isGroup &&
            (doc.id.includes("adam_ai") || data.participants?.includes("adam_ai"))
          ) {
            return;
          }
          activeChats.push({ id: doc.id, ...data } as ChatSession);
        });

        // Sort by last message time descending
        activeChats.sort((a, b) => {
          const tA = a.lastMessageAt?.seconds || 0;
          const tB = b.lastMessageAt?.seconds || 0;
          return tB - tA;
        });
        setChats(activeChats);
      },
      (err) => {
        console.error("Error fetching chats:", err);
      },
    );

    return unsubscribe;
  }, [user.uid]);

  // 3. Search Handler
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const filtered = allUsers.filter(
      (u) =>
        u.uid !== user.uid &&
        (u.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.email.toLowerCase().includes(searchQuery.toLowerCase())),
    );
    setSearchResults(filtered);
  }, [searchQuery, allUsers, user.uid]);

  // Start or open a chat
  const startChat = async (partner: UserProfile) => {
    const chatId =
      user.uid < partner.uid
        ? `${user.uid}_${partner.uid}`
        : `${partner.uid}_${user.uid}`;

    // Check if chat exists first
    const existing = chats.find((c) => c.id === chatId);
    if (!existing) {
      // Create new chat doc
      try {
        await setDoc(doc(db, "chats", chatId), {
          participants: [user.uid, partner.uid],
          lastMessage: "بدء الدردشة الآن",
          lastMessageAt: serverTimestamp(),
          lastMessageSender: user.uid,
          participantDetails: {
            [user.uid]: {
              displayName: currentUserProfile.displayName || "مستخدم",
              photoURL: currentUserProfile.photoURL || "",
            },
            [partner.uid]: {
              displayName: partner.displayName,
              photoURL: partner.photoURL,
            },
          },
        });
      } catch (err) {
        console.error("Error creating chat session:", err);
      }
    }
    setSelectedChatId(chatId);
    setSearchQuery("");
    setShowSearchDropdown(false);
  };

  const createGroup = async (groupName: string, selectedUids: string[]) => {
    if (!groupName.trim() || selectedUids.length === 0) return;
    const groupId = `group_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const participants = [user.uid, ...selectedUids];
    
    let participantDetails: any = {
      [user.uid]: {
        displayName: currentUserProfile.displayName || "مستخدم",
        photoURL: currentUserProfile.photoURL || "",
      }
    };
    
    selectedUids.forEach(uid => {
      const p = allUsers.find(u => u.uid === uid);
      if (p) {
        participantDetails[uid] = {
          displayName: p.displayName,
          photoURL: p.photoURL,
        };
      }
    });

    try {
      await setDoc(doc(db, "chats", groupId), {
        participants,
        lastMessage: "تم إنشاء المجموعة",
        lastMessageAt: serverTimestamp(),
        lastMessageSender: user.uid,
        participantDetails,
        isGroup: true,
        groupName: groupName.trim(),
        groupAdmin: user.uid,
        allowMembersToRename: false
      });
      setShowCreateGroup(false);
      setSelectedChatId(groupId);
      setActiveTab("groups");
    } catch (err) {
      console.error("Error creating group:", err);
    }
  };

  const saveGroupSettings = async () => {
    if (!currentChat || !selectedChatId) return;
    try {
      await updateDoc(doc(db, "chats", selectedChatId), {
        groupName: tempGroupName.trim(),
        groupImage: tempGroupImage.trim(),
        allowMembersToRename: tempAllowRename
      });
      setShowGroupSettings(false);
    } catch (err) {
      console.error("Error updating group settings", err);
    }
  };

  const leaveGroup = async (groupId: string) => {
    const group = chats.find(c => c.id === groupId);
    if (!group) return;
    try {
      const newParticipants = group.participants.filter(uid => uid !== user.uid);
      await updateDoc(doc(db, "chats", groupId), {
        participants: newParticipants
      });
      setShowGroupContextMenu(false);
      setContextMenuGroupId(null);
      if (selectedChatId === groupId) {
        setSelectedChatId(null);
      }
    } catch (err) {
      console.error("Error leaving group:", err);
    }
  };

  const deleteGroup = async (groupId: string) => {
    try {
      await deleteDoc(doc(db, "chats", groupId));
      setShowGroupContextMenu(false);
      setContextMenuGroupId(null);
      if (selectedChatId === groupId) {
        setSelectedChatId(null);
      }
    } catch (err) {
      console.error("Error deleting group:", err);
    }
  };

  const currentChat = chats.find((c) => c.id === selectedChatId);
  const partnerUidForLookup = currentChat?.participants?.find(
    (uid: string) => uid !== user.uid,
  );
  let chatPartner =
    currentChat && currentChat.participantDetails
      ? (Object.entries(currentChat.participantDetails).find(
          ([uid]) => uid !== user.uid,
        )?.[1] as
          { displayName: string; photoURL: string; uid?: string } | undefined)
      : null;

  const liveChatPartner = allUsers.find((u) => u.uid === partnerUidForLookup);
  if (chatPartner && liveChatPartner) {
    chatPartner = {
      ...chatPartner,
      displayName: liveChatPartner.displayName,
      photoURL: liveChatPartner.photoURL,
    };
  }
  const chatPartnerUid = currentChat
    ? currentChat.participants.find((uid) => uid !== user.uid)
    : null;

  return (
    <div
      className="flex h-screen h-[100dvh] w-full bg-[#09090b] text-slate-200 overflow-hidden font-sans relative"
      dir={isRtl ? "rtl" : "ltr"}
    >
      {/* Floating Offline Notification */}
      {!isOnline && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] flex items-center gap-2 px-4 py-2.5 rounded-full bg-amber-500/10 backdrop-blur-md border border-amber-500/20 text-amber-400 text-xs font-medium shadow-2xl animate-in fade-in slide-in-from-top-4 duration-300">
          <WifiOff className="h-4 w-4 shrink-0 animate-pulse" />
          <span>
            {isRtl
              ? "الاتصال غير مستقر. يعمل التطبيق الآن في وضع عدم الاتصال بالإنترنت."
              : "Connection unstable. The app is running in offline mode."}
          </span>
        </div>
      )}

      {/* SIDEBAR */}
      <aside
        className={cn(
          "w-full md:w-80 bg-[#121215] flex flex-col shrink-0 transition-all duration-300",
          isRtl ? "border-l border-white/5" : "border-r border-white/5",
          selectedChatId ? "hidden md:flex" : "flex",
        )}
      >
        {/* User profile header */}
        <div className="p-3.5 border-b border-white/5 flex items-center justify-between bg-[#121215]/90">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={
                  currentUserProfile.photoURL ||
                  `https://ui-avatars.com/api/?name=${currentUserProfile.displayName || "User"}`
                }
                alt=""
                className="w-10 h-10 rounded-full border border-white/10 object-cover"
                referrerPolicy="no-referrer"
              />
              <span
                className={`absolute bottom-0 left-0 w-3 h-3 rounded-full border-2 border-[#121215] ${
                  isOnline ? "bg-emerald-500" : "bg-amber-500"
                }`}
              />
            </div>
            <div>
              <p className="text-sm font-semibold leading-none text-slate-100 flex items-center gap-1.5">
                {currentUserProfile.displayName}
              </p>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="text-[10px] text-slate-400 truncate max-w-[120px]">
                  {currentUserProfile.email || "Account"}
                </span>
                <span className="text-[9px] text-slate-500">•</span>
                <span className="text-[10px] text-slate-500">
                  {isOnline
                    ? (isRtl ? "متصل" : "Online")
                    : (isRtl ? "غير متصل" : "Offline")}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 shadow-sm">
            <span className="text-xs font-bold tracking-wider text-indigo-400 font-sans select-none">
              Adam Chat
            </span>
          </div>
        </div>

        {/* Small square (+) button next to long search bar for chats */}
        <div className="p-3 border-b border-white/5 bg-[#121216]">
          <div className="flex items-center gap-2">
            {/* Small square plus button */}
            <button
              type="button"
              onClick={() => {
                setShowAddFriendModal(true);
                setFriendPhoneInput("");
                setFriendSearchResult(null);
                setHasSearchedFriend(false);
                setSearchFriendError(null);
              }}
              title={isRtl ? "إضافة صديق برقم الهاتف" : "Add Friend by Phone"}
              className="w-11 h-11 shrink-0 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white rounded-xl flex items-center justify-center shadow-md shadow-indigo-600/30 border border-indigo-400/20 transition-all cursor-pointer"
            >
              <Plus className="w-5 h-5" strokeWidth={2.5} />
            </button>

            {/* Long search bar for chats/people */}
            <div className="relative flex-1">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isRtl ? "البحث في الأشخاص الذين دردشت معهم..." : "Search people you chatted with..."}
                className={`w-full h-11 bg-[#1a1a24] text-slate-100 border border-white/10 rounded-xl text-xs placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all shadow-inner ${
                  isRtl ? "pr-9 pl-8 text-right" : "pl-9 pr-8 text-left"
                }`}
              />
              <Search className={`absolute top-3.5 text-slate-400 h-4 w-4 pointer-events-none ${isRtl ? "right-3" : "left-3"}`} />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  className={`absolute top-3 text-slate-400 hover:text-white p-0.5 ${isRtl ? "left-2.5" : "right-2.5"}`}
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Chats or Groups List */}
        <div className="flex-1 overflow-y-auto space-y-1 px-2 pb-4">
          <div className="flex items-center justify-between px-3 py-2">
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {activeTab === "chats" ? t.chats : t.groups}
            </h2>
            {activeTab === "groups" && (
              <button
                onClick={() => setShowCreateGroup(true)}
                className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 text-xs"
              >
                <Plus className="h-4 w-4" />
                <span>{isRtl ? "إنشاء" : "Create"}</span>
              </button>
            )}
          </div>
          
          {(() => {
            const filteredChats = chats.filter((c) => {
              const matchesTab = activeTab === "chats" ? !c.isGroup : c.isGroup;
              if (!matchesTab) return false;
              if (!searchQuery.trim()) return true;

              const q = searchQuery.toLowerCase().trim();
              if (c.isGroup) {
                return c.groupName?.toLowerCase().includes(q);
              } else {
                const otherUid = c.participants.find((id) => id !== user.uid);
                const otherProfile = otherUid
                  ? c.participantDetails?.[otherUid] || allUsers.find((u) => u.uid === otherUid)
                  : null;
                return (
                  otherProfile?.displayName?.toLowerCase().includes(q) ||
                  otherProfile?.phoneNumber?.includes(q)
                );
              }
            });

            if (filteredChats.length === 0) {
              return (
                <div className="p-6 text-center text-xs text-slate-500">
                  <p>
                    {searchQuery.trim()
                      ? (isRtl ? "لا توجد نتائج مطابقة في المحادثات السابقة." : "No matching chats found.")
                      : (activeTab === "chats" 
                          ? (isRtl ? "لا توجد محادثات نشطة بعد." : "No active chats yet.") 
                          : (isRtl ? "لا توجد مجموعات بعد." : "No groups yet."))}
                  </p>
                  {activeTab === "chats" && !searchQuery.trim() && (
                    <p className="mt-2 text-indigo-400 font-medium">
                      {isRtl
                        ? "اضغط على مربع (+) للبحث عن رقم صديق والبدء معه"
                        : "Click (+) square to add a friend by phone"}
                    </p>
                  )}
                </div>
              );
            }

            return filteredChats.map((c) => {
              if (c.isGroup) {
                const formattedTime = c.lastMessageAt
                  ? new Date(c.lastMessageAt.toMillis()).toLocaleTimeString("ar-EG", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })
                  : "";

                return (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    key={c.id}
                    onClick={() => setSelectedChatId(c.id)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      setContextMenuGroupId(c.id);
                      setShowGroupContextMenu(true);
                    }}
                    className={cn(
                      "flex items-center gap-3 p-2 rounded-xl cursor-pointer transition-all",
                      selectedChatId === c.id
                        ? "bg-indigo-500/20 shadow-sm"
                        : "hover:bg-white/5",
                    )}
                  >
                    {c.groupImage ? (
                      <img
                        src={c.groupImage}
                        alt=""
                        className="w-12 h-12 rounded-full border border-white/5 shrink-0 object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 border border-white/5">
                        <Users className="h-6 w-6" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <h3 className="text-sm font-bold text-slate-200 truncate">
                          {c.groupName || "مجموعة بدون اسم"}
                        </h3>
                        <span className="text-[10px] text-slate-500 whitespace-nowrap ml-2">
                          {formattedTime}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 truncate mt-0.5">
                        {c.lastMessageSender === user.uid ? "أنت: " : ""}
                        {c.lastMessage}
                      </p>
                    </div>
                  </motion.div>
                );
              }

              const partnerUid = c.participants?.find(
                (uid: string) => uid !== user.uid,
              );
              const livePartnerInfo = allUsers.find(
                (u) => u.uid === partnerUid,
              );

              let partnerInfo = Object.entries(c.participantDetails || {}).find(
                ([uid]) => uid !== user.uid,
              )?.[1] as { displayName: string; photoURL: string } | undefined;

              if (livePartnerInfo) {
                partnerInfo = {
                  displayName: livePartnerInfo.displayName,
                  photoURL: livePartnerInfo.photoURL,
                };
              }

              const isSelected = c.id === selectedChatId;
              const formattedTime = c.lastMessageAt?.seconds
                ? new Date(c.lastMessageAt.seconds * 1000).toLocaleTimeString(
                    "ar-EG",
                    { hour: "2-digit", minute: "2-digit" },
                  )
                : "";

              return (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ type: "spring", stiffness: 300, damping: 25 }}
                  key={c.id}
                  onClick={() => setSelectedChatId(c.id)}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all",
                    isSelected
                      ? "bg-indigo-500/10 border-r-2 border-indigo-500"
                      : "hover:bg-white/5",
                  )}
                >
                  <div className="relative shrink-0">
                    <img
                      src={
                        partnerInfo?.photoURL ||
                        `https://ui-avatars.com/api/?name=${partnerInfo?.displayName || "Chat"}`
                      }
                      alt=""
                      className="w-12 h-12 rounded-full border border-white/5"
                      referrerPolicy="no-referrer"
                    />
                    <span className="absolute bottom-0 left-0 w-3 h-3 bg-emerald-500 border-2 border-[#121215] rounded-full"></span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-sm font-medium text-slate-200 truncate">
                        {partnerInfo?.displayName || "محادثة"}
                      </h3>
                      <span className="text-[10px] text-slate-500">
                        {formattedTime}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {c.lastMessageSender === user.uid ? "أنت: " : ""}
                      {c.lastMessage}
                    </p>
                  </div>
                </motion.div>
              );
            });
          })()}
        </div>
        
        {/* Bottom Navigation */}
        <div className="h-16 border-t border-white/5 flex items-center justify-around bg-[#121215]">
          <button
            onClick={() => setActiveTab("chats")}
            className={cn(
              "flex flex-col items-center justify-center w-full h-full gap-1 transition-colors",
              activeTab === "chats" ? "text-indigo-400" : "text-slate-500 hover:text-slate-300"
            )}
          >
            <MessageCircle className="h-5 w-5" />
            <span className="text-[10px] font-medium">{t.chats}</span>
          </button>
          <button
            onClick={() => setActiveTab("groups")}
            className={cn(
              "flex flex-col items-center justify-center w-full h-full gap-1 transition-colors",
              activeTab === "groups" ? "text-indigo-400" : "text-slate-500 hover:text-slate-300"
            )}
          >
            <Users className="h-5 w-5" />
            <span className="text-[10px] font-medium">{t.groups}</span>
          </button>
          <button
            onClick={() => {
              setEditDisplayName(currentUserProfile.displayName || "");
              setEditPhotoURL(currentUserProfile.photoURL || "");
              setEditPhoneNumber(currentUserProfile.phoneNumber || user.phoneNumber || "");
              setPhoneChangeAdminPassword("");
              setSettingsError(null);
              setShowSettings(true);
            }}
            className={cn(
              "flex flex-col items-center justify-center w-full h-full gap-1 transition-colors",
              showSettings ? "text-indigo-400" : "text-slate-500 hover:text-slate-300"
            )}
            title={t.settings_title}
          >
            <Settings className="h-5 w-5" />
            <span className="text-[10px] font-medium">{t.settings_title}</span>
          </button>
        </div>
      </aside>

      {/* CHAT WINDOW */}
      <main
        className={cn(
          "flex-1 flex flex-col bg-[#0d0d0f] relative",
          !selectedChatId
            ? "hidden md:flex items-center justify-center text-center p-8"
            : "flex",
        )}
      >
        {selectedChatId && currentChat ? (
          <>
            {/* Active chat header */}
            <header className="h-16 shrink-0 border-b border-white/5 flex items-center px-6 justify-between bg-[#121215]/50 backdrop-blur-md z-10">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  onClick={() => setSelectedChatId(null)}
                  className="md:hidden p-2 hover:bg-white/5 rounded-lg text-slate-400"
                >
                  <ChevronLeft className="h-5 w-5 rtl:-scale-x-100" />
                </button>
                {currentChat.isGroup ? (
                  currentChat.groupImage ? (
                    <img
                      src={currentChat.groupImage}
                      alt=""
                      className="w-10 h-10 rounded-full border border-white/5 shrink-0 object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 border border-white/5">
                      <Users className="h-5 w-5" />
                    </div>
                  )
                ) : (
                  <img
                    src={
                      chatPartner?.photoURL ||
                      `https://ui-avatars.com/api/?name=${chatPartner?.displayName || "User"}`
                    }
                    alt=""
                    className="w-10 h-10 rounded-full border border-white/5 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                )}
                <div className="min-w-0">
                  <h2 className="text-sm font-bold text-slate-200 truncate flex items-center gap-2">
                    {currentChat.isGroup ? currentChat.groupName : chatPartner?.displayName}
                    {currentChat.isGroup && currentChat.groupAdmin === user.uid && (
                      <span className="text-[10px] bg-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded-full">أنت المسؤول</span>
                    )}
                  </h2>
                  <p className="text-[10px] text-emerald-400 font-medium truncate">
                    {currentChat.typingUsers?.some((uid) => uid !== user.uid) ? (
                      <span className="animate-pulse">يكتب الآن...</span>
                    ) : currentChat.isGroup ? (
                      `${currentChat.participants.length} عضو`
                    ) : (
                      "نشط الآن"
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-400">
                <button
                  onClick={() => {
                    setTempBackground(currentChat?.background || "default");
                    setShowBackgroundSettings(true);
                  }}
                  className="p-2 hover:bg-[#1c1c21] hover:text-indigo-400 rounded-lg transition-colors cursor-pointer"
                  title="تغيير الخلفية"
                >
                  <Palette className="h-4.5 w-4.5" />
                </button>
                <button
                  onClick={() => initiateCall("audio")}
                  className="p-2 hover:bg-[#1c1c21] hover:text-indigo-400 rounded-lg transition-colors cursor-pointer"
                  title="اتصال صوتي"
                >
                  <Phone className="h-4.5 w-4.5" />
                </button>
                <button
                  onClick={() => initiateCall("video")}
                  className="p-2 hover:bg-[#1c1c21] hover:text-indigo-400 rounded-lg transition-colors cursor-pointer"
                  title="اتصال مرئي"
                >
                  <Video className="h-4.5 w-4.5" />
                </button>
                {!currentChat.isGroup && chatPartner && chatPartnerUid && (
                  <button
                    onClick={() => {
                      openAdminDeleteModal({
                        uid: chatPartnerUid,
                        displayName: chatPartner.displayName || "مستخدم",
                      });
                    }}
                    className="p-2 hover:bg-red-500/10 hover:text-red-400 text-slate-500 rounded-lg transition-colors cursor-pointer"
                    title={
                      isRtl
                        ? "حذف حساب هذا المستخدم (يتطلب كلمة مرور المسؤول)"
                        : "Delete this user's account (Admin password required)"
                    }
                  >
                    <UserX className="h-4.5 w-4.5" />
                  </button>
                )}
                {currentChat.isGroup && (
                  <button
                    onClick={() => {
                      setTempGroupName(currentChat.groupName || "");
                      setTempGroupImage(currentChat.groupImage || "");
                      setTempAllowRename(!!currentChat.allowMembersToRename);
                      setShowGroupSettings(true);
                    }}
                    className="p-2 hover:bg-[#1c1c21] hover:text-indigo-400 rounded-lg transition-colors cursor-pointer"
                    title="إعدادات المجموعة"
                  >
                    <MoreVertical className="h-4.5 w-4.5" />
                  </button>
                )}
              </div>
            </header>

            {/* Message list area */}
            <ChatFeed
              chatId={selectedChatId}
              user={user}
              currentUserProfile={currentUserProfile}
              allUsers={allUsers}
              background={currentChat?.background}
              currentChat={currentChat}
            />
          </>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="flex flex-col items-center justify-center p-8 max-w-sm"
          >
            <div className="w-20 h-20 rounded-2xl overflow-hidden mb-4 shadow-xl shadow-indigo-500/10 border border-white/10 flex items-center justify-center bg-indigo-500/10">
              <img
                src="/logo.jpg"
                alt="شعار التطبيق"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <h2 className="text-lg font-bold text-slate-200 mb-1">
              {t.empty_title}
            </h2>
            <p className="text-xs text-slate-500 leading-relaxed">
              {t.empty_desc}
            </p>
          </motion.div>
        )}
      </main>

      {/* GROUP CONTEXT MENU OVERLAY */}
      {showGroupContextMenu && contextMenuGroupId && (
        <div 
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => {
            setShowGroupContextMenu(false);
            setContextMenuGroupId(null);
          }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#1c1c21] border border-white/5 rounded-2xl w-full max-w-xs shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-2 flex flex-col gap-1">
              <button
                onClick={() => leaveGroup(contextMenuGroupId)}
                className="w-full text-right px-4 py-3 text-sm text-slate-200 hover:bg-white/5 rounded-xl transition-colors"
              >
                مغادرة المجموعة
              </button>
              {chats.find(c => c.id === contextMenuGroupId)?.groupAdmin === user.uid && (
                <button
                  onClick={() => deleteGroup(contextMenuGroupId)}
                  className="w-full text-right px-4 py-3 text-sm text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
                >
                  حذف المجموعة
                </button>
              )}
            </div>
          </motion.div>
        </div>
      )}

      {/* GROUP SETTINGS OVERLAY */}
      {showGroupSettings && currentChat?.isGroup && (
        <div className="fixed inset-0 z-50 bg-[#09090b]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1c1c21] border border-white/5 rounded-2xl w-full max-w-sm flex flex-col shadow-2xl relative overflow-hidden">
            <div className="p-4 border-b border-white/5 flex items-center justify-between shrink-0">
              <h3 className="font-bold text-slate-200">إعدادات المجموعة</h3>
              <button
                onClick={() => setShowGroupSettings(false)}
                className="p-2 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-4 flex-1 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">صورة المجموعة (رابط)</label>
                <input
                  type="text"
                  value={tempGroupImage}
                  onChange={(e) => setTempGroupImage(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#121215] text-slate-200 border-none rounded-xl py-3 px-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none mb-4"
                  disabled={currentChat.groupAdmin !== user.uid && !currentChat.allowMembersToRename}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">اسم المجموعة</label>
                <input
                  type="text"
                  value={tempGroupName}
                  onChange={(e) => setTempGroupName(e.target.value)}
                  placeholder="أدخل اسم المجموعة"
                  className="w-full bg-[#121215] text-slate-200 border-none rounded-xl py-3 px-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  disabled={currentChat.groupAdmin !== user.uid && !currentChat.allowMembersToRename}
                />
              </div>

              {currentChat.groupAdmin === user.uid && (
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-400">السماح للأعضاء بتعديل الاسم</label>
                  <button
                    onClick={() => setTempAllowRename(!tempAllowRename)}
                    className={cn(
                      "w-10 h-5 rounded-full relative transition-colors",
                      tempAllowRename ? "bg-indigo-500" : "bg-slate-700"
                    )}
                  >
                    <div className={cn(
                      "w-4 h-4 bg-white rounded-full absolute top-0.5 transition-transform",
                      tempAllowRename ? "left-0.5" : "right-0.5"
                    )} />
                  </button>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-white/5 shrink-0 bg-[#1c1c21]">
              <button
                onClick={saveGroupSettings}
                disabled={!tempGroupName.trim() || (currentChat.groupAdmin !== user.uid && !currentChat.allowMembersToRename)}
                className="w-full bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl py-3 px-4 font-bold transition-all text-sm shadow-lg shadow-indigo-500/25"
              >
                حفظ التغييرات
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE GROUP OVERLAY */}
      {showCreateGroup && (
        <div className="fixed inset-0 z-50 bg-[#09090b]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1c1c21] border border-white/5 rounded-2xl w-full max-w-sm flex flex-col max-h-[80vh] shadow-2xl relative overflow-hidden">
            <div className="p-4 border-b border-white/5 flex items-center justify-between shrink-0">
              <h3 className="font-bold text-slate-200">إنشاء مجموعة جديدة</h3>
              <button
                onClick={() => {
                  setShowCreateGroup(false);
                  setNewGroupName("");
                  setSelectedUsersForGroup([]);
                }}
                className="p-2 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto flex-1 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">اسم المجموعة</label>
                <input
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="أدخل اسم المجموعة"
                  className="w-full bg-[#121215] text-slate-200 border-none rounded-xl py-3 px-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">اختيار الأعضاء</label>
                <div className="space-y-2">
                  {allUsers.filter(u => u.uid !== user.uid).map(u => {
                    const isSelected = selectedUsersForGroup.includes(u.uid);
                    return (
                      <div
                        key={u.uid}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedUsersForGroup(prev => prev.filter(id => id !== u.uid));
                          } else {
                            setSelectedUsersForGroup(prev => [...prev, u.uid]);
                          }
                        }}
                        className={cn(
                          "flex items-center gap-3 p-2 rounded-xl cursor-pointer transition-colors border border-transparent",
                          isSelected ? "bg-indigo-500/10 border-indigo-500/30" : "hover:bg-white/5"
                        )}
                      >
                        <img
                          src={u.photoURL}
                          alt=""
                          className="w-8 h-8 rounded-full border border-white/5"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-slate-200 truncate">{u.displayName}</p>
                        </div>
                        <div className={cn(
                          "w-5 h-5 rounded-full flex items-center justify-center border transition-colors",
                          isSelected ? "bg-indigo-500 border-indigo-500 text-white" : "border-slate-600"
                        )}>
                          {isSelected && <Check className="h-3 w-3" />}
                        </div>
                      </div>
                    );
                  })}
                  {allUsers.length <= 1 && (
                    <p className="text-xs text-slate-500 text-center py-4">لا يوجد مستخدمين آخرين لإضافتهم.</p>
                  )}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-white/5 shrink-0 bg-[#1c1c21]">
              <button
                onClick={() => {
                  createGroup(newGroupName, selectedUsersForGroup);
                  setNewGroupName("");
                  setSelectedUsersForGroup([]);
                }}
                disabled={!newGroupName.trim() || selectedUsersForGroup.length === 0}
                className="w-full bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl py-3 px-4 font-bold transition-all text-sm shadow-lg shadow-indigo-500/25"
              >
                إنشاء المجموعة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FULL SCREEN SETTINGS VIEW */}
      {showSettings && (
        <div
          className="fixed inset-0 z-50 bg-[#09090b] flex flex-col min-h-screen text-slate-200 overflow-y-auto"
          dir={isRtl ? "rtl" : "ltr"}
        >
          {/* Top Header */}
          <div className="sticky top-0 z-20 bg-[#121215]/95 backdrop-blur-md border-b border-white/5 px-4 sm:px-8 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowSettings(false)}
                className="p-2 -m-1 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-colors flex items-center gap-1.5 text-sm font-medium"
                title={isRtl ? "رجوع" : "Back"}
              >
                <ChevronLeft className={cn("w-5 h-5", isRtl ? "rotate-180" : "")} />
                <span className="hidden sm:inline">{isRtl ? "رجوع" : "Back"}</span>
              </button>
              <div className="h-5 w-px bg-white/10 hidden sm:block" />
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <h1 className="text-base sm:text-lg font-bold text-slate-100 leading-tight">
                    {t.settings_title}
                  </h1>
                  <p className="text-[11px] text-slate-500">Adam Chat Settings</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={saveSettings}
                disabled={isSavingSettings}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-semibold transition-all shadow-lg shadow-indigo-600/20 disabled:opacity-50 flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{isSavingSettings ? t.saving : t.save}</span>
              </button>
            </div>
          </div>

          {/* Main Body */}
          <div className="flex-1 w-full max-w-2xl mx-auto p-4 sm:p-8 space-y-6 pb-20">
            {/* Profile Information */}
            <div className="bg-[#141418] border border-white/5 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
              <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                <div className="w-2 h-2 rounded-full bg-indigo-500" />
                <h2 className="text-sm font-semibold text-slate-200">
                  {t.profile_setup_title || "Profile Information"}
                </h2>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div className="relative group">
                  {editPhotoURL ? (
                    <img
                      src={editPhotoURL}
                      alt="Profile"
                      className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-2 border-indigo-500/30 shadow-lg"
                    />
                  ) : (
                    <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-[#1c1c21] border-2 border-dashed border-white/10 flex flex-col items-center justify-center text-slate-500">
                      <Camera className="w-8 h-8 mb-1 text-slate-400" />
                      <span className="text-[10px]">Photo</span>
                    </div>
                  )}
                  <label className="absolute -bottom-2 -right-2 p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg cursor-pointer transition-transform group-hover:scale-105">
                    <Camera className="w-4 h-4" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageSelect}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="flex-1 w-full space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">
                      {t.name_label}
                    </label>
                    <input
                      type="text"
                      value={editDisplayName}
                      onChange={(e) => setEditDisplayName(e.target.value)}
                      placeholder={t.name_placeholder || "Your display name"}
                      className="w-full bg-[#0d0d0f] border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">
                      {isRtl ? "رقم الهاتف الخاص بك (للبحث والخصوصية)" : "Your Phone Number"}
                    </label>
                    <div className="relative flex items-center">
                      <input
                        type="tel"
                        value={editPhoneNumber}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, "").slice(0, 10);
                          setEditPhoneNumber(val);
                          if (settingsError) setSettingsError(null);
                        }}
                        maxLength={10}
                        placeholder={isRtl ? "اكتب 10 أرقام (مثال: 0501234567)" : "e.g. 0501234567"}
                        className={`w-full bg-[#0d0d0f] border border-white/10 rounded-xl py-3 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all ${
                          isRtl ? "pr-10 pl-4" : "pl-10 pr-4"
                        }`}
                      />
                      <Phone className={`w-4 h-4 text-indigo-400 absolute ${isRtl ? "right-3.5" : "left-3.5"} pointer-events-none`} />
                    </div>
                  </div>

                  {/* Admin Password Prompt if phone number differs from original */}
                  {Boolean(
                    (currentUserProfile.phoneNumber || user.phoneNumber || "").replace(/\D/g, "") &&
                    editPhoneNumber.replace(/\D/g, "") !== (currentUserProfile.phoneNumber || user.phoneNumber || "").replace(/\D/g, "")
                  ) && (
                    <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-1.5">
                      <label className="block text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 shrink-0" />
                        {isRtl ? "كلمة سر تصريح المسؤول لتغيير رقم الهاتف" : "Admin Password to Change Phone"}
                      </label>
                      <div className="relative flex items-center">
                        <input
                          type="password"
                          value={phoneChangeAdminPassword}
                          onChange={(e) => {
                            setPhoneChangeAdminPassword(e.target.value);
                            setSettingsError(null);
                          }}
                          placeholder={isRtl ? "أدخل كلمة سر تصريح المسؤول" : "Enter admin authorization password"}
                          className={`w-full bg-[#0d0d0f] border border-amber-500/30 rounded-xl py-2.5 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all ${
                            isRtl ? "pr-10 pl-4" : "pl-10 pr-4"
                          }`}
                        />
                        <KeyRound className={`w-4 h-4 text-amber-400 absolute ${isRtl ? "right-3.5" : "left-3.5"} pointer-events-none`} />
                      </div>
                    </div>
                  )}

                  {settingsError && (
                    <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                      <span>{settingsError}</span>
                    </div>
                  )}

                  <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#0d0d0f] border border-white/5 text-xs text-slate-400">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="truncate">{user.email}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* App Language */}
            <div className="bg-[#141418] border border-white/5 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-indigo-400" />
                  <h2 className="text-sm font-semibold text-slate-200">
                    {t.app_language}
                  </h2>
                </div>
                <span className="text-xs text-indigo-400 font-mono">
                  {selectedLanguageCode.toUpperCase()}
                </span>
              </div>

              <div>
                <select
                  value={selectedLanguageCode}
                  onChange={(e) => onLanguageChange(e.target.value)}
                  className="w-full bg-[#0d0d0f] border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 cursor-pointer transition-all"
                >
                  {WORLD_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code} className="bg-[#1c1c21] text-slate-200 py-1">
                      {l.flag} {l.name} ({l.englishName})
                    </option>
                  ))}
                </select>
                <p className="mt-2 text-xs text-slate-500">
                  {isRtl
                    ? "سيتم تطبيق لغة التطبيق والاتجاه فوراً على جميع الشاشات والرسائل."
                    : "The interface language and text direction will update immediately."}
                </p>
              </div>
            </div>

            {/* FCM Notifications Section */}
            <div className="bg-[#141418] border border-white/5 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-indigo-400" />
                  <h2 className="text-sm font-semibold text-slate-200">
                    {isRtl ? "إشعارات الهاتف وتطبيق الـ APK" : "Phone & APK Push Notifications"}
                  </h2>
                </div>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                  FCM
                </span>
              </div>

              <div className="space-y-3">
                <p className="text-xs text-slate-400 leading-relaxed">
                  {isRtl
                    ? "تضمن خدمة Firebase Cloud Messaging وصول إشعارات الرسائل الجديدة لهاتفك حتى عندما يكون التطبيق أو الـ APK مغلقاً تماماً أو في الخلفية."
                    : "Firebase Cloud Messaging ensures you receive alerts even when the APK is closed or in the background."}
                </p>

                <button
                  type="button"
                  onClick={async () => {
                    const res = await requestNotificationPermissionAndGetToken(user.uid);
                    if (res.success && res.token) {
                      alert(
                        isRtl
                          ? `✅ تم تفعيل الإشعارات بنجاح!\nالرمز: ${res.token.substring(0, 15)}...`
                          : `✅ Push notifications enabled!\nToken: ${res.token.substring(0, 15)}...`
                      );
                    } else if (res.permission.includes("unsupported")) {
                      alert(
                        isRtl
                          ? `✅ تنبيه WebView: تم حفظ الإعدادات، سيتم الاعتماد على المزامنة الخلفية أو بيئة التطبيق الأصلي للإشعارات.`
                          : `✅ WebView Notice: Settings saved, falling back to native app environment or background sync for notifications.`
                      );
                    } else {
                      alert(
                        isRtl
                          ? `⚠️ لم يتم تفعيل الإشعارات بالكامل.\nالسبب: ${res.error || "غير معروف"}\nحالة الإذن: ${res.permission}\nمدعوم: ${res.isFCMSupported ? "نعم" : "لا"}`
                          : `⚠️ Notifications not fully enabled.\nReason: ${res.error || "Unknown"}\nPermission: ${res.permission}\nSupported: ${res.isFCMSupported ? "Yes" : "No"}`
                      );
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold transition-colors active:scale-[0.99]"
                >
                  <BellRing className="w-4 h-4" />
                  <span>{isRtl ? "تفعيل / تحديث إذن الإشعارات لهذا الجهاز" : "Enable / Refresh Notifications"}</span>
                </button>
              </div>
            </div>

            {/* Account & Session */}
            <div className="bg-[#141418] border border-white/5 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <h2 className="text-sm font-semibold text-slate-200">
                  {isRtl ? "إدارة الحساب والجلسة" : "Account & Session"}
                </h2>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-1">
                <div>
                  <p className="text-sm font-medium text-slate-300">
                    {isRtl ? "تسجيل الخروج من الحساب" : "Sign out of your account"}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {isRtl
                      ? "يمكنك الدخول مرة أخرى باسمك في أي وقت."
                      : "You can sign back in with your name anytime."}
                  </p>
                </div>

                <button
                  onClick={() => {
                    setShowSettings(false);
                    try {
                      StorageManager.removeItem("adam_chat_user");
                      if (user?.uid) {
                        StorageManager.removeItem(`adam_chat_profile_completed_${user.uid}`);
                      }
                      signOut(auth).catch(() => {});
                    } catch (e) {
                      console.warn("Storage cleanup:", e);
                    }
                    setUser(null);
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2 shrink-0 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{t.sign_out}</span>
                </button>
              </div>

              {/* Delete Account Permanently */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3 border-t border-white/5">
                <div>
                  <p className="text-sm font-medium text-red-400">
                    {isRtl ? "حذف الحساب نهائياً" : "Delete Account Permanently"}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {isRtl
                      ? "سيتم حذف ملفك الشخصي ومحادثاتك من التطبيق وقاعدة البيانات بشكل نهائي."
                      : "Permanently removes your profile and data from the database."}
                  </p>
                </div>

                <button
                  onClick={() => {
                    setShowSelfDeleteConfirm(true);
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2 shrink-0 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{isRtl ? "حذف الحساب نهائياً" : "Delete Account"}</span>
                </button>
              </div>
            </div>

            {/* App Footer Info */}
            <div className="text-center py-4 text-xs text-slate-600">
              <span className="font-semibold text-slate-500">Adam Chat</span> • Real-time Messenger
            </div>
          </div>
        </div>
      )}

      {/* SELF ACCOUNT DELETION CONFIRMATION MODAL (NO PASSWORD NEEDED - CONFIRM OR CANCEL) */}
      {showSelfDeleteConfirm && (
        <div className="fixed inset-0 z-[70] bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div
            className="bg-[#18181b] border border-red-500/30 rounded-2xl w-full max-w-md p-6 shadow-2xl relative overflow-hidden"
            dir={isRtl ? "rtl" : "ltr"}
          >
            {/* Top accent glow */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-rose-500 to-red-500 opacity-90" />

            <button
              disabled={isDeletingSelf}
              onClick={() => setShowSelfDeleteConfirm(false)}
              className="absolute top-4 left-4 rtl:left-4 rtl:right-auto ltr:right-4 ltr:left-auto p-1.5 text-slate-400 hover:text-slate-200 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3.5 mb-4">
              <div className="w-11 h-11 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-100">
                  {isRtl ? "تأكيد حذف حسابك نهائياً" : "Confirm Permanent Account Deletion"}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isRtl ? "يرجى تأكيد رغبتك في حذف حسابك" : "Please confirm you want to delete your account"}
                </p>
              </div>
            </div>

            <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4 mb-6">
              <p className="text-sm font-semibold text-slate-200 mb-1.5">
                {isRtl ? "هل أنت متأكد من رغبتك في حذف حسابك نهائياً؟" : "Are you sure you want to permanently delete your account?"}
              </p>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isRtl
                  ? "سيتم مسح ملفك الشخصي ومحادثاتك ورسائلك من قاعدة البيانات فوراً وبشكل نهائي. لن تحتاج لكلمة مرور، ولكن هذا الإجراء لا يمكن التراجع عنه."
                  : "Your profile, messages, and chats will be immediately and permanently removed from the database. No password needed, but this action cannot be undone."}
              </p>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                disabled={isDeletingSelf}
                onClick={() => setShowSelfDeleteConfirm(false)}
                className="px-5 py-2.5 text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                {isRtl ? "إلغاء" : "Cancel"}
              </button>
              <button
                type="button"
                disabled={isDeletingSelf}
                onClick={handleConfirmSelfDelete}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 shadow-lg shadow-red-600/20 cursor-pointer"
              >
                {isDeletingSelf ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>{isRtl ? "جاري الحذف..." : "Deleting..."}</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isRtl ? "نعم، تأكيد الحذف" : "Yes, Confirm Deletion"}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADMIN AUTHORIZATION MODAL FOR ACCOUNT DELETION */}
      {adminAuthModal.isOpen && adminAuthModal.targetUser && (
        <div className="fixed inset-0 z-[70] bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div
            className="bg-[#18181b] border border-red-500/30 rounded-2xl w-full max-w-md p-6 shadow-2xl relative overflow-hidden"
            dir={isRtl ? "rtl" : "ltr"}
          >
            {/* Top accent glow */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-amber-500 to-red-500 opacity-80" />

            <button
              onClick={() => {
                if (!isDeletingAccount) {
                  setAdminAuthModal({ isOpen: false, targetUser: null });
                  setAdminPasswordInput("");
                  setAdminPasswordError("");
                }
              }}
              className="absolute top-4 left-4 rtl:left-4 rtl:right-auto ltr:right-4 ltr:left-auto p-1.5 text-slate-400 hover:text-slate-200 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-11 h-11 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 shrink-0">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-100">
                  {isRtl ? "تصريح المسؤول مطلوب" : "Admin Authorization Required"}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isRtl
                    ? "عملية حذف الحساب محمية بكلمة مرور المسؤول"
                    : "Account deletion is protected by administrator password"}
                </p>
              </div>
            </div>

            <div className="bg-red-500/5 border border-red-500/15 rounded-xl p-3.5 mb-5">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <span className="text-slate-500">{isRtl ? "الحساب المستهدف:" : "Target Account:"}</span>
                <span className="font-semibold text-red-300 truncate">
                  {adminAuthModal.targetUser.displayName}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {isRtl
                  ? "سيتم حذف هذا الحساب نهائياً من قاعدة البيانات وجميع محادثاته المرتبطة به."
                  : "This account and all its chats will be permanently deleted from the database."}
              </p>
            </div>

            <form onSubmit={handleConfirmAdminDelete} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {isRtl ? "أدخل كلمة مرور المسؤول:" : "Enter Administrator Password:"}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 ltr:left-0 rtl:right-0 flex items-center px-3 pointer-events-none text-slate-500">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type={showAdminPassword ? "text" : "password"}
                    autoFocus
                    value={adminPasswordInput}
                    onChange={(e) => {
                      setAdminPasswordInput(e.target.value);
                      if (adminPasswordError) setAdminPasswordError("");
                    }}
                    placeholder={isRtl ? "كلمة مرور المسؤول..." : "Admin password..."}
                    className="w-full bg-[#101013] border border-white/10 focus:border-red-500/50 focus:ring-1 focus:ring-red-500/30 rounded-xl py-2.5 ltr:pl-9.5 ltr:pr-10 rtl:pr-9.5 rtl:pl-10 text-sm text-slate-100 placeholder-slate-600 outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminPassword(!showAdminPassword)}
                    className="absolute inset-y-0 ltr:right-0 rtl:left-0 flex items-center px-3 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                  >
                    {showAdminPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
                {adminPasswordError && (
                  <p className="text-xs text-red-400 mt-2 flex items-center gap-1.5 animate-fadeIn">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400 shrink-0" />
                    {adminPasswordError}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  disabled={isDeletingAccount}
                  onClick={() => {
                    setAdminAuthModal({ isOpen: false, targetUser: null });
                    setAdminPasswordInput("");
                    setAdminPasswordError("");
                  }}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
                >
                  {isRtl ? "إلغاء" : "Cancel"}
                </button>
                <button
                  type="submit"
                  disabled={isDeletingAccount || !adminPasswordInput.trim()}
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 shadow-lg shadow-red-600/20 cursor-pointer"
                >
                  {isDeletingAccount ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>{isRtl ? "جاري الحذف..." : "Deleting..."}</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isRtl ? "تأكيد الحذف نهائياً" : "Confirm Permanent Deletion"}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD FRIEND BY PHONE NUMBER MODAL */}
      {showAddFriendModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div
            className="w-full max-w-md rounded-3xl bg-[#141418] border border-white/10 shadow-2xl overflow-hidden relative"
            dir={isRtl ? "rtl" : "ltr"}
          >
            {/* Header */}
            <div className="p-5 bg-[#18181f] border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {isRtl ? "إضافة صديق برقم الهاتف" : "Add Friend by Phone Number"}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isRtl
                      ? "أدخل رقم الهاتف الذي أنشأه صديقك للبدء في المحادثة معه"
                      : "Enter your friend's phone number to start chatting"}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddFriendModal(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="p-6 flex flex-col gap-5">
              {/* Search Form Input */}
              <form onSubmit={handleSearchFriendByPhone} className="flex flex-col gap-3">
                <label className="text-xs font-semibold text-slate-300">
                  {isRtl ? "رقم هاتف صديقك:" : "Friend's Phone Number:"}
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1 flex items-center">
                    <input
                      type="tel"
                      value={friendPhoneInput}
                      onChange={(e) => {
                        setFriendPhoneInput(e.target.value);
                        setHasSearchedFriend(false);
                        setSearchFriendError(null);
                      }}
                      placeholder={isRtl ? "مثال: 0501234567" : "e.g. +966501234567"}
                      className={`w-full bg-[#0b0b0e] border border-white/10 rounded-2xl py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all ${
                        isRtl ? "pr-10 pl-4 text-right" : "pl-10 pr-4 text-left"
                      }`}
                      autoFocus
                    />
                    <Phone className={`w-4 h-4 text-slate-400 absolute ${isRtl ? "right-3.5" : "left-3.5"} pointer-events-none`} />
                  </div>

                  <button
                    type="submit"
                    disabled={isSearchingFriend || !friendPhoneInput.trim()}
                    className="px-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 shrink-0 shadow-lg shadow-indigo-600/20 cursor-pointer"
                  >
                    {isSearchingFriend ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Search className="w-4 h-4" />
                        <span>{isRtl ? "بحث" : "Search"}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* SEARCH RESULTS DISPLAY */}
              {hasSearchedFriend && (
                <div className="pt-2">
                  {friendSearchResult ? (
                    /* MATCH FOUND! */
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex flex-col gap-4 animate-in zoom-in-95 duration-200">
                      <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
                        <Check className="w-4 h-4 bg-emerald-500/20 rounded-full p-0.5" />
                        <span>{isRtl ? "تم العثور على حساب صديقك!" : "Friend's account found!"}</span>
                      </div>

                      <div className="flex items-center justify-between bg-[#0b0b0e]/60 p-3 rounded-xl border border-white/5">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              friendSearchResult.photoURL ||
                              `https://ui-avatars.com/api/?name=${encodeURIComponent(
                                friendSearchResult.displayName || "User"
                              )}`
                            }
                            alt=""
                            className="w-12 h-12 rounded-full border-2 border-indigo-500/40 object-cover shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <h4 className="text-sm font-bold text-slate-100 truncate">
                              {friendSearchResult.displayName}
                            </h4>
                            <p className="text-xs text-indigo-400 font-mono mt-0.5 text-right dir-ltr">
                              {friendSearchResult.phoneNumber || friendPhoneInput}
                            </p>
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          startChat(friendSearchResult!);
                          setShowAddFriendModal(false);
                        }}
                        className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>{isRtl ? "بدء الدردشة الآن" : "Start Chat Now"}</span>
                      </button>
                    </div>
                  ) : (
                    /* NUMBER NOT FOUND! */
                    <div className="p-5 bg-red-500/10 border border-red-500/30 rounded-2xl flex flex-col items-center text-center gap-3 animate-in zoom-in-95 duration-200">
                      <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center border border-red-500/30">
                        <UserX className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="inline-block px-3 py-1 rounded-full bg-red-500/20 text-red-300 font-bold text-xs mb-2 border border-red-500/30">
                          {isRtl ? "علامة: الرقم غير موجود" : "Number Not Found"}
                        </span>
                        <p className="text-xs text-slate-300 leading-relaxed font-medium">
                          {isRtl
                            ? "هذا الرقم ليس هو الرقم الذي أنشأه صديقك بالفعل، ولا توجد حسابات مسجلة به. لا يمكنك الدردشة مع هذا الرقم."
                            : "This number was not created by a friend and is not registered in Adam Chat."}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {searchFriendError && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-300 text-xs rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{searchFriendError}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* BACKGROUND SETTINGS OVERLAY */}
      {showBackgroundSettings && selectedChatId && (
        <div className="fixed inset-0 z-50 bg-[#09090b]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1c1c21] border border-white/10 rounded-2xl w-full max-w-md p-6 shadow-2xl relative">
            <button
              onClick={() => setShowBackgroundSettings(false)}
              className="absolute top-4 left-4 p-2 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <h2
              className="text-xl font-semibold text-slate-100 mb-2 flex items-center gap-2"
              dir="rtl"
            >
              <Palette className="w-5 h-5 text-indigo-400" />
              تغيير خلفية المحادثة
            </h2>
            <p
              className="text-slate-400 text-xs mb-6 leading-relaxed text-right"
              dir="rtl"
            >
              قم بتحميل صورة من جهازك لتعيينها كخلفية لهذه المحادثة لكلا
              الطرفين.
            </p>

            <div className="space-y-6">
              {/* Upload image from device */}
              <div className="space-y-2">
                <label
                  className="block text-xs font-semibold text-slate-400 text-right"
                  dir="rtl"
                >
                  تحميل صورة من جهازك
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleBgFileChange}
                  id="bg-file-input"
                  className="hidden"
                  disabled={isUploadingBg}
                />
                <label
                  htmlFor="bg-file-input"
                  className={cn(
                    "flex flex-col items-center justify-center border border-dashed border-white/10 rounded-xl p-5 bg-[#121215] hover:bg-white/5 hover:border-indigo-500/50 transition-all cursor-pointer text-center",
                    isUploadingBg && "opacity-50 pointer-events-none",
                  )}
                  dir="rtl"
                >
                  {isUploadingBg ? (
                    <div className="flex flex-col items-center gap-2">
                      <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                      <span className="text-xs text-slate-400">
                        جاري معالجة وضغط الصورة...
                      </span>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-6 h-6 text-indigo-400 mb-2" />
                      <span className="text-xs text-slate-200 font-medium">
                        اختر صورة من المعرض
                      </span>
                      <span className="text-[10px] text-slate-500 mt-1">
                        يتم تحسين وضغط الصورة لتناسب المحادثة فوراً
                      </span>
                    </>
                  )}
                </label>
              </div>

              {/* Image Live Preview within modal */}
              {tempBackground &&
                (tempBackground.startsWith("http") ||
                  tempBackground.startsWith("data:")) && (
                  <div className="mt-3 relative h-20 rounded-xl overflow-hidden border border-white/10">
                    <img
                      src={tempBackground}
                      alt="Preview"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = "none";
                      }}
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <span className="text-[10px] text-white/90 bg-[#1c1c21]/80 px-2.5 py-1 rounded-full">
                        معاينة الخلفية المحددة
                      </span>
                    </div>
                  </div>
                )}
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-3 pt-2" dir="rtl">
              <button
                onClick={async () => {
                  try {
                    await updateDoc(doc(db, "chats", selectedChatId), {
                      background: tempBackground || "default",
                    });
                    setShowBackgroundSettings(false);
                  } catch (error) {
                    console.error("Error setting chat background:", error);
                  }
                }}
                className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl py-2.5 text-sm font-medium transition-colors cursor-pointer"
              >
                حفظ الخلفية
              </button>
              <button
                onClick={async () => {
                  try {
                    await updateDoc(doc(db, "chats", selectedChatId), {
                      background: "default",
                    });
                    setTempBackground("default");
                    setShowBackgroundSettings(false);
                  } catch (error) {
                    console.error("Error resetting chat background:", error);
                  }
                }}
                className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-xl px-4 py-2.5 text-xs font-medium transition-colors cursor-pointer"
              >
                استعادة الافتراضي
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CALL OVERLAYS */}
      {activeCall && (
        <div
          className="fixed inset-0 z-50 bg-black text-slate-100 font-sans w-screen h-screen overflow-hidden select-none"
          dir="rtl"
          onClick={unlockAudio}
          onTouchStart={unlockAudio}
        >
          {/* Always-mounted dedicated remote audio element for real-time WebRTC audio playback */}
          <audio
            ref={remoteAudioRef}
            autoPlay
            playsInline
            className="fixed -top-96 -left-96 w-1 h-1 opacity-0 pointer-events-none"
            onPlay={() => setIsAudioBlocked(false)}
            onError={(e) => console.warn("Dedicated call audio element error:", e)}
          />

          {/* Autoplay blocked notification button */}
          {isAudioBlocked && (
            <div className="absolute top-14 sm:top-18 inset-x-0 z-50 flex justify-center px-4 pointer-events-auto">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  unlockAudio();
                }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs sm:text-sm shadow-2xl animate-bounce transition-all cursor-pointer border-2 border-amber-300"
              >
                <Volume2 className="w-5 h-5 shrink-0" />
                <span>المتصفح حجب تشغيل الصوت تلقائياً — انقر هنا لتفعيل الصوت فوراً</span>
              </button>
            </div>
          )}

          {activeCall.type === "video" ? (
            /* ========================================================================= */
            /* FULL-SCREEN VIDEO CALL LAYOUT */
            /* ========================================================================= */
            <div className="relative w-full h-full flex flex-col justify-between overflow-hidden">
              {/* Fullscreen Video Background */}
              {activeCall.status === "connected" ? (
                <div className="absolute inset-0 w-full h-full bg-zinc-950">
                  <CallVideoPreview
                    stream={isSwappedVideo ? localStream : remoteStream}
                    className="w-full h-full object-cover"
                    muted={true}
                    mirrored={isSwappedVideo}
                    fallback={
                      <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-950 p-6 text-center">
                        <img
                          src={
                            activeCall.callerId === user.uid
                              ? activeCall.receiverPhoto
                              : activeCall.callerPhoto
                          }
                          alt=""
                          className="w-28 h-28 rounded-full object-cover border-4 border-white/10 shadow-2xl mb-4"
                          referrerPolicy="no-referrer"
                        />
                        <h3 className="text-xl font-bold text-white mb-1">
                          {activeCall.callerId === user.uid
                            ? activeCall.receiverName
                            : activeCall.callerName}
                        </h3>
                        <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-1">
                          <VideoOff className="w-4 h-4 text-amber-400" />
                          كاميرا الطرف الآخر غير متاحة حالياً
                        </p>
                      </div>
                    }
                  />

                  {/* Floating Picture-in-Picture (PiP) Window */}
                  <div
                    onClick={() => setIsSwappedVideo((prev) => !prev)}
                    className="absolute top-4 left-4 sm:top-6 sm:left-6 w-28 sm:w-40 md:w-48 aspect-[3/4] rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl border-2 border-white/20 bg-zinc-900/90 backdrop-blur-md z-30 cursor-pointer transition-all duration-300 hover:scale-105 active:scale-95 group"
                    title="انقر لتبديل الشاشة الرئيسية والمصغرة"
                  >
                    <CallVideoPreview
                      stream={isSwappedVideo ? remoteStream : localStream}
                      className="w-full h-full object-cover"
                      muted={true}
                      mirrored={!isSwappedVideo}
                      fallback={
                        <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-950 p-2 text-center">
                          <VideoOff className="w-6 h-6 text-slate-500" />
                          <span className="text-[10px] text-slate-400 mt-1">
                            الكاميرا مغلقة
                          </span>
                        </div>
                      }
                    />
                    <div className="absolute bottom-2 inset-x-2 flex items-center justify-between px-2.5 py-1 rounded-xl bg-black/65 backdrop-blur-md text-[10px] text-white/95 font-medium shadow-md">
                      <span>
                        {isSwappedVideo
                          ? activeCall.callerId === user.uid
                            ? activeCall.receiverName
                            : activeCall.callerName
                          : "أنت (معاينة)"}
                      </span>
                      <RefreshCw className="w-3 h-3 text-white/80 group-hover:rotate-180 transition-transform duration-500" />
                    </div>
                  </div>
                </div>
              ) : (
                /* Fullscreen Preview during ringing */
                <div className="absolute inset-0 w-full h-full bg-zinc-950">
                  {localStream ? (
                    <CallVideoPreview
                      stream={localStream}
                      className="w-full h-full object-cover filter brightness-[0.7]"
                      muted={true}
                      mirrored={true}
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-b from-zinc-900 via-black to-zinc-950" />
                  )}
                  {/* Overlay Dimmer */}
                  <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
                </div>
              )}

              {/* Floating Top Bar */}
              <div className="relative z-30 p-4 sm:p-6 flex items-center justify-between pointer-events-none">
                {/* Partner Pill Info */}
                <div className="pointer-events-auto flex items-center gap-3 bg-black/50 hover:bg-black/65 backdrop-blur-2xl border border-white/15 px-3.5 py-2 rounded-full shadow-2xl transition-all">
                  <img
                    src={
                      activeCall.callerId === user.uid
                        ? activeCall.receiverPhoto
                        : activeCall.callerPhoto
                    }
                    alt=""
                    className="w-9 h-9 rounded-full object-cover border border-white/20"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0 pr-1">
                    <h3 className="text-xs sm:text-sm font-bold text-white truncate max-w-[130px] sm:max-w-[200px]">
                      {activeCall.callerId === user.uid
                        ? activeCall.receiverName
                        : activeCall.callerName}
                    </h3>
                    <p className="text-[10px] sm:text-xs text-emerald-400 font-medium flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      {activeCall.status === "connected"
                        ? `متصل • ${formatDuration(callDuration)}`
                        : activeCall.callerId === user.uid
                          ? "جارٍ الاتصال..."
                          : "مكالمة فيديو واردة..."}
                    </p>
                  </div>
                </div>

                {/* Top Action Controls */}
                <div className="pointer-events-auto flex items-center gap-2 sm:gap-3">
                  {activeCall.status === "connected" && (
                    <button
                      onClick={() => setIsSwappedVideo((prev) => !prev)}
                      className="w-10 h-10 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-2xl border border-white/15 text-white flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-lg"
                      title="تبديل الكاميرا الرئيسية"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={toggleBrowserFullscreen}
                    className="w-10 h-10 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-2xl border border-white/15 text-white flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-lg"
                    title="ملء الشاشة"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Center Ringing Details (shown when ringing) */}
              {activeCall.status === "ringing" && (
                <div className="relative z-30 flex-1 flex flex-col items-center justify-center text-center p-4">
                  <div className="relative mb-6">
                    <img
                      src={
                        activeCall.callerId === user.uid
                          ? activeCall.receiverPhoto
                          : activeCall.callerPhoto
                      }
                      alt=""
                      className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-white/20 shadow-2xl animate-pulse"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 rounded-full border-2 border-emerald-400 animate-ping opacity-40"></div>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2 drop-shadow-md">
                    {activeCall.callerId === user.uid
                      ? activeCall.receiverName
                      : activeCall.callerName}
                  </h2>
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-xs sm:text-sm text-slate-200 shadow-lg">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    {activeCall.callerId === user.uid
                      ? "جارٍ الاتصال بمكالمة فيديو HD..."
                      : "يدعوك لبدء مكالمة فيديو HD"}
                  </div>
                </div>
              )}

              {/* Floating Bottom Control Bar */}
              <div className="relative z-30 p-6 sm:p-10 flex items-center justify-center pointer-events-none">
                {activeCall.status === "ringing" &&
                activeCall.receiverId === user.uid ? (
                  /* Incoming Video Call Actions */
                  <div className="pointer-events-auto flex items-center gap-8 sm:gap-12 bg-black/60 backdrop-blur-2xl border border-white/20 px-8 py-4 rounded-full shadow-2xl">
                    <button
                      onClick={rejectCall}
                      className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-xl shadow-red-600/30 active:scale-95 transition-all cursor-pointer"
                      title="رفض"
                    >
                      <PhoneOff className="w-7 h-7" />
                    </button>
                    <button
                      onClick={acceptCall}
                      className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-xl shadow-emerald-500/30 active:scale-95 transition-all cursor-pointer animate-bounce"
                      title="قبول مكالمة الفيديو"
                    >
                      <Video className="w-7 h-7" />
                    </button>
                  </div>
                ) : (
                  /* Connected or Outgoing Video Controls */
                  <div className="pointer-events-auto flex items-center gap-4 sm:gap-6 bg-black/60 backdrop-blur-2xl border border-white/20 px-6 py-3.5 rounded-full shadow-2xl">
                    {activeCall.status === "connected" && (
                      <button
                        onClick={toggleMute}
                        className={cn(
                          "w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-lg",
                          isMuted
                            ? "bg-red-500 text-white shadow-red-500/30"
                            : "bg-white/15 hover:bg-white/25 text-white border border-white/15",
                        )}
                        title={isMuted ? "إلغاء كتم الصوت" : "كتم الصوت"}
                      >
                        {isMuted ? (
                          <MicOff className="w-5 h-5 sm:w-6 sm:h-6" />
                        ) : (
                          <Mic className="w-5 h-5 sm:w-6 sm:h-6" />
                        )}
                      </button>
                    )}

                    {/* End Call Button */}
                    <button
                      onClick={endCall}
                      className="w-16 h-16 sm:w-18 sm:h-18 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-2xl shadow-red-600/40 active:scale-95 transition-all cursor-pointer"
                      title="إنهاء المكالمة"
                    >
                      <PhoneOff className="w-7 h-7 sm:w-8 sm:h-8" />
                    </button>

                    {activeCall.status === "connected" && (
                      <button
                        onClick={toggleVideo}
                        className={cn(
                          "w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-lg",
                          isVideoOff
                            ? "bg-red-500 text-white shadow-red-500/30"
                            : "bg-white/15 hover:bg-white/25 text-white border border-white/15",
                        )}
                        title={isVideoOff ? "تشغيل الكاميرا" : "إيقاف الكاميرا"}
                      >
                        {isVideoOff ? (
                          <VideoOff className="w-5 h-5 sm:w-6 sm:h-6" />
                        ) : (
                          <Video className="w-5 h-5 sm:w-6 sm:h-6" />
                        )}
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* ========================================================================= */
            /* AUDIO CALL LAYOUT */
            /* ========================================================================= */
            <div className="relative w-full h-full flex flex-col justify-between p-6 sm:p-12 overflow-hidden">
              {/* Blurred Background Avatar */}
              <div className="absolute inset-0 -z-10 opacity-20 overflow-hidden">
                <img
                  src={
                    activeCall.callerId === user.uid
                      ? activeCall.receiverPhoto
                      : activeCall.callerPhoto
                  }
                  alt=""
                  className="w-full h-full object-cover blur-3xl scale-125"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Top Details */}
              <div className="flex flex-col items-center mt-6 sm:mt-12 text-center select-none">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/5 border border-white/10 rounded-full text-xs text-slate-300 mb-6 font-medium animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  مكالمة صوتية مشفرة بدقة عالية
                </div>

                <div className="relative mb-6">
                  <img
                    src={
                      activeCall.callerId === user.uid
                        ? activeCall.receiverPhoto
                        : activeCall.callerPhoto
                    }
                    alt=""
                    className={cn(
                      "w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-indigo-500/30 shadow-2xl transition-all duration-500",
                      activeCall.status === "ringing"
                        ? "animate-bounce"
                        : "scale-105",
                    )}
                    referrerPolicy="no-referrer"
                  />
                  {activeCall.status === "connected" && (
                    <div className="absolute inset-0 rounded-full border-2 border-indigo-500 animate-ping opacity-30"></div>
                  )}
                </div>

                <h2 className="text-2xl sm:text-3xl font-bold text-slate-100 mb-2">
                  {activeCall.callerId === user.uid
                    ? activeCall.receiverName
                    : activeCall.callerName}
                </h2>

                <p className="text-sm text-slate-400 font-medium">
                  {activeCall.status === "ringing" &&
                    (activeCall.callerId === user.uid
                      ? "جارٍ الاتصال..."
                      : "مكالمة صوتية واردة...")}
                  {activeCall.status === "connected" &&
                    `متصل • ${formatDuration(callDuration)}`}
                </p>
              </div>

              {/* Middle Soundwaves */}
              <div className="flex-1 flex items-center justify-center my-6">
                {activeCall.status === "connected" && (
                  <div className="flex flex-col items-center gap-6">
                    <div className="flex items-center gap-1.5 h-16">
                      {[1, 2, 3, 4, 5, 4, 3, 2, 1, 2, 3, 4, 5].map((val, idx) => (
                        <span
                          key={idx}
                          className="w-1.5 bg-indigo-500 rounded-full animate-pulse"
                          style={{
                            height: `${val * 20}%`,
                            animationDelay: `${idx * 100}ms`,
                          }}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Controls */}
              <div className="mb-6 sm:mb-12 flex flex-col items-center gap-6">
                {activeCall.status === "ringing" &&
                activeCall.receiverId === user.uid ? (
                  <div className="flex items-center gap-10">
                    <button
                      onClick={rejectCall}
                      className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg hover:shadow-red-500/20 active:scale-95 transition-all cursor-pointer"
                      title="رفض"
                    >
                      <PhoneOff className="w-7 h-7" />
                    </button>
                    <button
                      onClick={acceptCall}
                      className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-lg hover:shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer animate-bounce"
                      title="قبول"
                    >
                      <Phone className="w-7 h-7" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-6 bg-black/40 backdrop-blur-2xl border border-white/10 px-6 py-3 rounded-full shadow-2xl">
                    {activeCall.status === "connected" && (
                      <button
                        onClick={toggleMute}
                        className={cn(
                          "w-12 h-12 rounded-full flex items-center justify-center transition-all active:scale-95 cursor-pointer",
                          isMuted
                            ? "bg-red-500 text-white shadow-red-500/20"
                            : "bg-white/10 hover:bg-white/20 text-slate-200",
                        )}
                        title={isMuted ? "إلغاء كتم الصوت" : "كتم الصوت"}
                      >
                        {isMuted ? (
                          <MicOff className="w-5 h-5" />
                        ) : (
                          <Mic className="w-5 h-5" />
                        )}
                      </button>
                    )}

                    <button
                      onClick={endCall}
                      className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg hover:shadow-red-500/20 active:scale-95 transition-all cursor-pointer"
                      title="إنهاء المكالمة"
                    >
                      <PhoneOff className="w-7 h-7" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const MessageBubble: React.FC<{
  msg: Message;
  isMe: boolean;
  showAvatar: boolean;
  isSelected: boolean;
  isSelectionMode: boolean;
  chatId: string;
  onToggleSelect: () => void;
  onImageZoom?: (url: string) => void;
}> = ({
  msg,
  isMe,
  showAvatar,
  isSelected,
  isSelectionMode,
  chatId,
  onToggleSelect,
  onImageZoom,
}) => {
  const longPressProps = useLongPress(() => {
    if (!isSelectionMode) {
      onToggleSelect();
    }
  }, 500);

  const formattedTime = msg.createdAt?.seconds
    ? new Date(msg.createdAt.seconds * 1000).toLocaleTimeString("ar-EG", {
        hour: "2-digit",
        minute: "2-digit",
      })
    : "الآن";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={cn(
        "flex w-full group transition-all",
        isMe ? "justify-end" : "justify-start",
      )}
    >
      <div
        className={cn(
          "flex max-w-[85%] sm:max-w-[70%] gap-2.5 items-end relative",
          isMe ? "flex-row-reverse" : "flex-row",
        )}
      >
        {/* Avatar */}
        {!isMe && (
          <div className="shrink-0 w-8">
            {showAvatar ? (
              <img
                src={msg.photoURL}
                alt=""
                className="h-8 w-8 rounded-full shadow-sm border border-white/5"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="h-8 w-8" />
            )}
          </div>
        )}

        <div className="flex flex-col">
          {!isMe && showAvatar && (
            <span className="mb-1 px-1 text-[10px] text-slate-500 font-medium">
              {msg.displayName}
            </span>
          )}

          {/* Message content container */}
          <div
            {...longPressProps}
            onClick={() => {
              if (isSelectionMode) {
                onToggleSelect();
              }
            }}
            className={cn(
              "rounded-2xl shadow-sm text-sm leading-relaxed text-slate-100 relative group/bubble cursor-pointer active:scale-[0.98] transition-transform",
              msg.location ? "p-1 sm:p-1.5" : "p-4",
              isMe
                ? "bg-indigo-600 rounded-br-none shadow-indigo-500/10"
                : "bg-[#1c1c21] rounded-bl-none border border-white/5",
              isSelected && isMe ? "bg-indigo-700 ring-2 ring-indigo-400" : "",
              isSelected && !isMe ? "bg-[#27272a] ring-2 ring-indigo-400" : "",
            )}
          >
            {/* Selection Checkbox */}
            {isSelectionMode && (
              <div
                className={cn(
                  "absolute -top-2 z-10 flex items-center justify-center w-5 h-5 rounded transition-colors border shadow-sm",
                  isMe ? "-left-2" : "-right-2",
                  isSelected
                    ? "bg-blue-500 border-blue-500"
                    : "border-slate-400 bg-[#1c1c21]",
                )}
              >
                {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
              </div>
            )}
            {/* Audio message handler / Call Log handler / Location handler */}
            {msg.isCallLog ? (
              <div className="flex items-center gap-3 py-1 text-slate-200 min-w-[150px]">
                <div
                  className={cn(
                    "w-9 h-9 rounded-full flex items-center justify-center shrink-0",
                    msg.text?.includes("فائتة")
                      ? "bg-red-500/10 text-red-400"
                      : "bg-emerald-500/10 text-emerald-400",
                  )}
                >
                  {msg.text?.includes("فيديو") ? (
                    <Video className="w-4.5 h-4.5" />
                  ) : (
                    <Phone className="w-4.5 h-4.5" />
                  )}
                </div>
                <div>
                  <p className="font-semibold text-xs leading-none mb-1.5">
                    {msg.text?.includes("فائتة")
                      ? "مكالمة فائتة"
                      : "مكالمة مكتملة"}
                  </p>
                  <p className="text-[10px] text-slate-400">{msg.text}</p>
                </div>
              </div>
            ) : msg.location ? (
              <LocationMessageCard
                location={msg.location}
                isMe={isMe}
                messageId={msg.id}
                chatId={chatId}
                senderName={msg.displayName}
                senderPhoto={msg.photoURL}
              />
            ) : msg.audioData ? (
              <AudioMessagePlayer
                audioSrc={msg.audioData}
                duration={msg.audioDuration}
                isMe={isMe}
              />
            ) : msg.mediaData ? (
              <div className="space-y-2 max-w-[260px] sm:max-w-xs rounded-xl overflow-hidden">
                {msg.mediaType === "image" ? (
                  <img
                    src={msg.mediaData}
                    alt="صورة مرسلة"
                    className="w-full h-auto object-cover max-h-72 rounded-lg cursor-zoom-in hover:opacity-95 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      onImageZoom?.(msg.mediaData || "");
                    }}
                  />
                ) : (
                  <video
                    src={msg.mediaData}
                    controls
                    preload="metadata"
                    className="w-full rounded-lg max-h-72 bg-black"
                  />
                )}
                {msg.text && (
                  <p className="whitespace-pre-wrap break-words select-text text-sm text-slate-100 px-1">
                    {msg.text}
                  </p>
                )}
              </div>
            ) : (
              <p className="whitespace-pre-wrap break-words select-text">
                {msg.text}
              </p>
            )}

            {/* Info & Status line */}
            <div
              className={cn(
                "flex items-center justify-end gap-1.5 text-[9px] text-slate-400 select-none pointer-events-none",
                msg.location ? "px-2.5 pb-1 mt-1.5" : "mt-2.5",
              )}
            >
              <span>{formattedTime}</span>
              {isMe && (
                <CheckCheck 
                  className={cn(
                    "h-3 w-3", 
                    msg.readBy && msg.readBy.length > 0 ? "text-sky-400" : "text-indigo-300"
                  )} 
                />
              )}
            </div>

            {/* Deletion Overlay button (only when not in selection mode) */}
            {!isSelectionMode && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleSelect();
                }}
                className={cn(
                  "absolute -top-2 -left-2 bg-[#27272a] hover:bg-red-500/20 text-slate-400 hover:text-red-400 p-1.5 rounded-lg opacity-0 group-hover/bubble:opacity-100 transition-all border border-white/10 shadow-lg",
                  !isMe && "-right-2 -left-auto",
                )}
                title="تحديد الرسالة"
              >
                <Trash2 className="h-3.5 w-3.5 pointer-events-none" />
              </button>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// Separate component for Chat messages flow to keep state responsive and clean
function ChatFeed({
  chatId,
  user,
  currentUserProfile,
  allUsers,
  background,
  currentChat,
}: {
  chatId: string;
  user: AppUser;
  currentUserProfile: any;
  allUsers: UserProfile[];
  background?: string;
  currentChat?: ChatSession;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [selectedMessages, setSelectedMessages] = useState<string[]>([]);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Voice Recording States
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<any>(null);

  // Attachment & Camera States
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isRecordingCameraVideo, setIsRecordingCameraVideo] = useState(false);
  const [previewMedia, setPreviewMedia] = useState<{
    data: string;
    type: "image" | "video";
    caption: string;
  } | null>(null);
  const [selectedZoomImage, setSelectedZoomImage] = useState<string | null>(null);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const liveWatchersRef = useRef<{ [msgId: string]: number }>({});

  useEffect(() => {
    return () => {
      // Clean up all active live location watchers when unmounting or leaving chat
      Object.values(liveWatchersRef.current).forEach((wId: number) => {
        if (navigator.geolocation) {
          navigator.geolocation.clearWatch(wId);
        }
      });
      liveWatchersRef.current = {};
    };
  }, []);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const cameraVideoRecorderRef = useRef<MediaRecorder | null>(null);
  const cameraVideoChunksRef = useRef<Blob[]>([]);
  const typingTimeoutRef = useRef<any>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);
    
    // Set typing status to true
    if (!currentChat?.typingUsers?.includes(user.uid)) {
      updateDoc(doc(db, "chats", chatId), {
        typingUsers: arrayUnion(user.uid)
      }).catch(console.error);
    }
    
    // Clear typing status after 2 seconds
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      updateDoc(doc(db, "chats", chatId), {
        typingUsers: arrayRemove(user.uid)
      }).catch(console.error);
    }, 2000);
  };

  // Camera handling functions
  useEffect(() => {
    if (showCameraModal && cameraStream && videoRef.current) {
      videoRef.current.srcObject = cameraStream;
    }
  }, [showCameraModal, cameraStream]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: true
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      try {
        const streamOnlyVideo = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
          audio: false
        });
        setCameraStream(streamOnlyVideo);
        if (videoRef.current) {
          videoRef.current.srcObject = streamOnlyVideo;
        }
      } catch (innerErr) {
        console.error("Error accessing video-only camera:", innerErr);
        alert("تعذر الوصول إلى الكاميرا. يرجى التحقق من إعطاء الصلاحيات.");
      }
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
    setIsRecordingCameraVideo(false);
  };

  const captureCameraPhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const maxDimension = 800;
        if (canvas.width > maxDimension || canvas.height > maxDimension) {
          const scaledCanvas = document.createElement("canvas");
          let w = canvas.width;
          let h = canvas.height;
          if (w > h) {
            h = Math.round((h * maxDimension) / w);
            w = maxDimension;
          } else {
            w = Math.round((w * maxDimension) / h);
            h = maxDimension;
          }
          scaledCanvas.width = w;
          scaledCanvas.height = h;
          const sCtx = scaledCanvas.getContext("2d");
          sCtx?.drawImage(canvas, 0, 0, w, h);
          const dataUrl = scaledCanvas.toDataURL("image/jpeg", 0.6);
          setPreviewMedia({ data: dataUrl, type: "image", caption: "" });
        } else {
          const dataUrl = canvas.toDataURL("image/jpeg", 0.6);
          setPreviewMedia({ data: dataUrl, type: "image", caption: "" });
        }
        setShowCameraModal(false);
        stopCamera();
      }
    }
  };

  const startCameraVideoRecording = () => {
    if (!cameraStream) return;
    setIsRecordingCameraVideo(true);
    cameraVideoChunksRef.current = [];
    const preferredMimeTypes = [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm",
      "video/mp4"
    ];
    let selectedMime = "";
    for (const mime of preferredMimeTypes) {
      if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(mime)) {
        selectedMime = mime;
        break;
      }
    }
    const options = selectedMime ? { mimeType: selectedMime } : undefined;
    const recorder = new MediaRecorder(cameraStream, options);
    cameraVideoRecorderRef.current = recorder;
    
    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        cameraVideoChunksRef.current.push(e.data);
      }
    };
    
    recorder.onstop = () => {
      const videoBlob = new Blob(cameraVideoChunksRef.current, {
        type: selectedMime || "video/webm"
      });

      if (videoBlob.size > 700 * 1024) {
        alert("حجم الفيديو كبير جداً (أكثر من 700 كيلوبايت). يرجى تسجيل فيديو أقصر لضمان سرعة الإرسال.");
        return;
      }

      const reader = new FileReader();
      reader.readAsDataURL(videoBlob);
      reader.onloadend = () => {
        setPreviewMedia({
          data: reader.result as string,
          type: "video",
          caption: ""
        });
        setShowCameraModal(false);
        stopCamera();
      };
    };
    
    recorder.start();
  };

  const stopCameraVideoRecording = () => {
    if (cameraVideoRecorderRef.current && isRecordingCameraVideo) {
      cameraVideoRecorderRef.current.stop();
      setIsRecordingCameraVideo(false);
    }
  };

  const handleGalleryPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.6);
          setPreviewMedia({ data: dataUrl, type: "image", caption: "" });
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
    setShowAttachmentMenu(false);
  };

  const handleGalleryVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 700 * 1024) {
      alert("حجم الفيديو كبير جداً. الرجاء اختيار فيديو أصغر من 700 كيلوبايت لضمان سرعة الإرسال.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setPreviewMedia({
        data: event.target?.result as string,
        type: "video",
        caption: ""
      });
    };
    reader.readAsDataURL(file);
    setShowAttachmentMenu(false);
  };

  useEffect(() => {
    const q = query(
      collection(db, "chats", chatId, "messages"),
      orderBy("createdAt", "desc"),
      limit(100),
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const msgs: Message[] = [];
        const unreadIds: string[] = [];
        snapshot.forEach((doc) => {
          const data = doc.data();
          if (!data.deletedFor?.includes(user.uid)) {
            msgs.push({ id: doc.id, ...data } as Message);
          }
          if (data.uid !== user.uid && (!data.readBy || !data.readBy.includes(user.uid))) {
            unreadIds.push(doc.id);
          }
        });
        
        if (unreadIds.length > 0) {
          const batch = writeBatch(db);
          unreadIds.forEach((id) => {
            batch.update(doc(db, "chats", chatId, "messages", id), {
              readBy: arrayUnion(user.uid)
            });
          });
          batch.commit().catch(console.error);
        }
        
        // Sort messages chronologically by createdAt, treating null/pending timestamps as "now"
        const sorted = [...msgs].sort((a, b) => {
          const tA = a.createdAt
            ? (typeof a.createdAt.toMillis === "function"
                ? a.createdAt.toMillis()
                : a.createdAt.seconds
                ? a.createdAt.seconds * 1000 + (a.createdAt.nanoseconds || 0) / 1000000
                : Date.now())
            : Date.now();
          const tB = b.createdAt
            ? (typeof b.createdAt.toMillis === "function"
                ? b.createdAt.toMillis()
                : b.createdAt.seconds
                ? b.createdAt.seconds * 1000 + (b.createdAt.nanoseconds || 0) / 1000000
                : Date.now())
            : Date.now();
          return tA - tB;
        });

        setMessages(sorted);
      },
      (error) => {
        handleFirestoreError(
          error,
          OperationType.LIST,
          `chats/${chatId}/messages`,
        );
      },
    );

    return unsubscribe;
  }, [chatId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (
    text?: string,
    audioData?: string,
    audioDuration?: number,
    mediaData?: string,
    mediaType?: "image" | "video",
    locationData?: LocationData,
  ) => {
    if (!text && !audioData && !mediaData && !locationData) return;

    try {
      // Update or create main chat session metadata first so parent document always exists
      let lastMessageSnippet = text || "";
      if (audioData) {
        lastMessageSnippet = "🎤 رسالة صوتية";
      } else if (mediaData) {
        lastMessageSnippet = mediaType === "image" ? "🖼️ صورة" : "🎥 فيديو";
      } else if (locationData) {
        lastMessageSnippet = locationData.isLive ? "📍 موقع مباشر" : "📍 موقع جغرافي";
      }

      const chatUpdate: any = {
        lastMessage: lastMessageSnippet,
        lastMessageAt: serverTimestamp(),
        lastMessageSender: user.uid,
        typingUsers: arrayRemove(user.uid),
      };

      await setDoc(doc(db, "chats", chatId), chatUpdate, { merge: true });

      // Add message document to subcollection
      const docRef = await addDoc(collection(db, "chats", chatId, "messages"), {
        ...(text && { text }),
        ...(audioData && { audioData, audioDuration }),
        ...(mediaData && { mediaData, mediaType }),
        ...(locationData && { location: locationData }),
        uid: user.uid,
        displayName: currentUserProfile.displayName || "مستخدم",
        photoURL:
          currentUserProfile.photoURL ||
          `https://ui-avatars.com/api/?name=${currentUserProfile.displayName || "User"}`,
        createdAt: serverTimestamp(),
      });

      // 2. إرسال إشعار فوري وتلقائي لجميع أجهزة المستخدمين عبر Firebase Cloud Messaging (FCM)
      sendFCMNotification({
        title: currentUserProfile.displayName || "مستخدم",
        body: lastMessageSnippet || "أرسل رسالة جديدة",
        senderUid: user.uid,
        chatId: chatId,
        icon: currentUserProfile.photoURL || "/logo.jpg",
      }).catch((e) => console.warn("FCM trigger error:", e));

      // If live location, track device location in real-time
      if (locationData?.isLive && navigator.geolocation) {
        const messageId = docRef.id;
        const watchId = navigator.geolocation.watchPosition(
          (pos) => {
            updateDoc(doc(db, "chats", chatId, "messages", messageId), {
              "location.latitude": pos.coords.latitude,
              "location.longitude": pos.coords.longitude,
              "location.accuracy": Math.round(pos.coords.accuracy),
              "location.updatedAt": Date.now(),
            }).catch(() => {});
          },
          (err) => {
            console.warn("Live geolocation watch info:", err?.code);
          },
          {
            enableHighAccuracy: true,
            maximumAge: 10000,
          }
        );

        liveWatchersRef.current[messageId] = watchId;

        // Auto cleanup watcher after expiration
        if (locationData.expiresAt) {
          const timeoutDelay = Math.max(1000, locationData.expiresAt - Date.now());
          setTimeout(() => {
            if (liveWatchersRef.current[messageId]) {
              navigator.geolocation.clearWatch(liveWatchersRef.current[messageId]);
              delete liveWatchersRef.current[messageId];
            }
          }, timeoutDelay);
        }
      }
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    // Fun confetti effect for special messages
    if (["🎉", "❤️", "مبروك", "عيد", "نجاح"].some(word => newMessage.includes(word))) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }

    handleSendMessage(newMessage.trim());
    setNewMessage("");
    setShowEmojiPicker(false);
  };

  // Start Voice Recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      let mimeType = "";
      const preferredMimeTypes = [
        "audio/webm;codecs=opus",
        "audio/webm",
        "audio/mp4",
        "audio/ogg;codecs=opus",
        "audio/wav",
        "audio/aac",
      ];

      for (const type of preferredMimeTypes) {
        if (
          typeof MediaRecorder !== "undefined" &&
          MediaRecorder.isTypeSupported &&
          MediaRecorder.isTypeSupported(type)
        ) {
          mimeType = type;
          break;
        }
      }

      const options = mimeType ? { mimeType } : undefined;
      const mediaRecorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const actualMimeType =
          mediaRecorder.mimeType || mimeType || "audio/webm";
        const audioBlob = new Blob(audioChunksRef.current, {
          type: actualMimeType,
        });

        if (audioBlob.size > 700 * 1024) {
          alert("المقطع الصوتي كبير جداً (أكثر من 700 كيلوبايت) ولن يتم إرساله بسبب قيود التخزين.");
          stream.getTracks().forEach((track) => track.stop());
          return;
        }

        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = reader.result as string;
          // Send voice message with recorded duration
          await handleSendMessage(undefined, base64Audio, recordingTime);
        };
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      recordTimerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Error accessing microphone:", err);
    }
  };

  // Stop Recording & Send
  const stopRecordingAndSend = () => {
    if (mediaRecorderRef.current && isRecording) {
      clearInterval(recordTimerRef.current);
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Cancel Recording
  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      clearInterval(recordTimerRef.current);
      mediaRecorderRef.current.onstop = null; // prevents sending
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      // Clean up tracks
      const stream = mediaRecorderRef.current.stream;
      stream.getTracks().forEach((track) => track.stop());
    }
  };

  const deleteSelectedMessagesForMe = async () => {
    try {
      const promises = selectedMessages.map(async (id) => {
        const docRef = doc(db, "chats", chatId, "messages", id);
        try {
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            await updateDoc(docRef, {
              deletedFor: arrayUnion(user.uid),
            });
          }
        } catch (err) {
          console.warn(`Error updating message ${id} for me:`, err);
        }
      });
      await Promise.all(promises);

      setSelectedMessages([]);
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error("Error deleting messages for me:", error);
    }
  };

  const deleteSelectedMessagesForEveryone = async () => {
    try {
      const batch = writeBatch(db);
      selectedMessages.forEach((id) => {
        batch.delete(doc(db, "chats", chatId, "messages", id));
      });
      await batch.commit();

      // Update the last message in the chat document
      const q = query(
        collection(db, "chats", chatId, "messages"),
        orderBy("createdAt", "desc"),
        limit(1),
      );
      const snapshot = await getDocs(q);
      let newLastMessage = "لا توجد رسائل";
      let newLastMessageSender = "";

      if (!snapshot.empty) {
        const lastDoc = snapshot.docs[0].data();
        newLastMessage = lastDoc.isCallLog
          ? lastDoc.text?.includes("فائتة")
            ? "مكالمة فائتة"
            : "مكالمة مكتملة"
          : lastDoc.location
            ? lastDoc.location.isLive
              ? "📍 موقع مباشر"
              : "📍 موقع جغرافي"
          : lastDoc.audioData
            ? "🎤 رسالة صوتية"
            : lastDoc.mediaData
              ? lastDoc.mediaType === "image"
                ? "🖼️ صورة"
                : "🎥 فيديو"
              : lastDoc.text || "";
        newLastMessageSender = lastDoc.uid;
      }

      await updateDoc(doc(db, "chats", chatId), {
        lastMessage: newLastMessage,
        lastMessageSender: newLastMessageSender,
      });

      setSelectedMessages([]);
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error("Error deleting messages:", error);
    }
  };

  const toggleSelectMessage = (id: string) => {
    setSelectedMessages((prev) =>
      prev.includes(id) ? prev.filter((msgId) => msgId !== id) : [...prev, id],
    );
  };

  const insertEmoji = (emoji: string) => {
    setNewMessage((prev) => prev + emoji);
  };

  return (
    <>
      {/* Top Selection Bar */}
      {selectedMessages.length > 0 && (
        <div className="absolute top-0 left-0 right-0 z-20 bg-indigo-600/95 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-white/10 shadow-lg">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedMessages([])}
              className="text-white hover:bg-white/20 p-1.5 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <span className="text-white font-medium text-sm">
              {selectedMessages.length} رسالة محددة
            </span>
          </div>
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 text-white bg-red-500/90 hover:bg-red-500 px-3 py-1.5 rounded-lg transition-colors text-sm font-medium shadow-sm"
          >
            <Trash2 className="w-4 h-4" />
            حذف الكل
          </button>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div
        className="flex-1 overflow-y-auto p-4 sm:p-6 scroll-smooth space-y-4"
        style={
          background && background !== "default"
            ? background.startsWith("http") || background.startsWith("data:")
              ? {
                  backgroundImage: `linear-gradient(rgba(9, 9, 11, 0.65), rgba(9, 9, 11, 0.65)), url("${background}")`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  backgroundRepeat: "no-repeat",
                  backgroundAttachment: "local",
                }
              : { background: background }
            : undefined
        }
      >
        <div className="mx-auto max-w-4xl space-y-4">
          <div className="flex justify-center my-4">
            <span className="text-[10px] bg-white/5 text-slate-500 px-3 py-1 rounded-full uppercase tracking-wider">
              المحادثة مشفرة وآمنة تماماً للطرفين
            </span>
          </div>

          {messages.map((msg, index) => {
            const isMe = msg.uid === user.uid;
            const showAvatar =
              index === 0 || messages[index - 1].uid !== msg.uid;

            const senderProfile =
              allUsers.find((u) => u.uid === msg.uid) ||
              (isMe ? currentUserProfile : undefined);
            const dynamicMsg = {
              ...msg,
              displayName: senderProfile?.displayName || msg.displayName,
              photoURL: senderProfile?.photoURL || msg.photoURL,
            };

            return (
              <MessageBubble
                key={dynamicMsg.id}
                msg={dynamicMsg}
                isMe={isMe}
                showAvatar={showAvatar}
                isSelected={selectedMessages.includes(dynamicMsg.id)}
                isSelectionMode={selectedMessages.length > 0}
                chatId={chatId}
                onToggleSelect={() => toggleSelectMessage(dynamicMsg.id)}
                onImageZoom={(url) => setSelectedZoomImage(url)}
              />
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm &&
        (() => {
          const canDeleteForEveryone = selectedMessages.every((id) => {
            const msg = messages.find((m) => m.id === id);
            if (currentChat?.isGroup && currentChat.groupAdmin === user.uid) return true;
            return msg && msg.uid === user.uid;
          });

          return (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
              <div className="bg-[#1c1c21] border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl">
                <h3 className="text-lg font-semibold text-slate-100 mb-2 text-right">
                  حذف الرسائل
                </h3>
                <p className="text-slate-400 text-sm mb-6 text-right leading-relaxed">
                  هل أنت متأكد من حذف {selectedMessages.length} رسالة؟
                  {!canDeleteForEveryone &&
                    " (بعض الرسائل لا تخصك، يمكن حذفها لديك فقط)"}
                </p>
                <div className="flex flex-col gap-3 w-full">
                  {canDeleteForEveryone && (
                    <button
                      onClick={deleteSelectedMessagesForEveryone}
                      className="w-full bg-red-500/10 hover:bg-red-500/20 text-red-400 py-2.5 rounded-xl text-sm font-medium transition-colors border border-red-500/20"
                    >
                      حذف للجميع
                    </button>
                  )}
                  <button
                    onClick={deleteSelectedMessagesForMe}
                    className="w-full bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 py-2.5 rounded-xl text-sm font-medium transition-colors border border-indigo-500/20"
                  >
                    حذف لدي فقط
                  </button>
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="w-full bg-white/5 hover:bg-white/10 text-slate-300 py-2.5 rounded-xl text-sm font-medium transition-colors border border-white/5 mt-2"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            </div>
          );
        })()}

      {/* Message input panel */}
      <footer className="shrink-0 p-4 bg-[#121215]/50 border-t border-white/5 relative z-10">
        <div className="max-w-4xl mx-auto relative">
          {/* Quick Emoji bar */}
          {showEmojiPicker && (
            <div className="absolute bottom-full mb-3 right-0 left-0 bg-[#1c1c21] border border-white/5 rounded-2xl p-3 shadow-2xl flex items-center gap-3 overflow-x-auto">
              <span className="text-xs text-slate-500 font-medium whitespace-nowrap border-l border-white/5 pl-2">
                سريع:
              </span>
              {POPULAR_EMOJIS.map((e) => (
                <button
                  key={e}
                  onClick={() => insertEmoji(e)}
                  className="text-lg hover:scale-125 transition-transform active:scale-95"
                >
                  {e}
                </button>
              ))}
            </div>
          )}

          {/* Media Attachment Menu */}
          {showAttachmentMenu && (
            <div className="absolute bottom-full mb-3 left-10 bg-[#1c1c21] border border-white/10 rounded-2xl p-2 shadow-2xl flex flex-col gap-1 min-w-[170px] z-50 animate-in fade-in slide-in-from-bottom-2 duration-150">
              <span className="text-[10px] text-slate-500 font-semibold pb-1.5 border-b border-white/5 text-right px-3">
                إرفاق وسائط
              </span>
              
              <button
                type="button"
                onClick={() => {
                  document.getElementById("gallery-photo-input")?.click();
                }}
                className="flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-200 hover:bg-white/5 transition-colors text-right cursor-pointer"
              >
                <Image className="h-4 w-4 text-indigo-400" />
                <span>معرض الصور</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  document.getElementById("gallery-video-input")?.click();
                }}
                className="flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-200 hover:bg-white/5 transition-colors text-right cursor-pointer"
              >
                <Video className="h-4 w-4 text-pink-400" />
                <span>معرض الفيديو</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowCameraModal(true);
                  setShowAttachmentMenu(false);
                  startCamera();
                }}
                className="flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-200 hover:bg-white/5 transition-colors text-right cursor-pointer"
              >
                <Camera className="h-4 w-4 text-emerald-400" />
                <span>الكاميرا مباشرة</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowLocationModal(true);
                  setShowAttachmentMenu(false);
                }}
                className="flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-200 hover:bg-white/5 transition-colors text-right cursor-pointer"
              >
                <MapPin className="h-4 w-4 text-emerald-400" />
                <span>موقع جغرافي / مباشر</span>
              </button>
            </div>
          )}

          {isRecording ? (
            /* Active voice recording view */
            <div className="flex items-center justify-between bg-red-500/10 border border-red-500/20 p-3 rounded-2xl animate-pulse">
              <div className="flex items-center gap-3">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>
                <span className="text-sm font-semibold text-red-400">
                  جاري تسجيل رسالة صوتية...
                </span>
                <span className="font-mono text-xs text-red-500 bg-red-500/5 px-2.5 py-1 rounded-lg">
                  {Math.floor(recordingTime / 60)}:
                  {(recordingTime % 60).toString().padStart(2, "0")}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={cancelRecording}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:bg-white/5 hover:text-white transition-colors"
                >
                  <X className="h-4 w-4" />
                  إلغاء
                </button>
                <button
                  onClick={stopRecordingAndSend}
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs bg-red-500 hover:bg-red-400 text-white font-medium transition-colors"
                >
                  <Square className="h-4 w-4" />
                  إرسال
                </button>
              </div>
            </div>
          ) : (
            /* Standard text message form */
            <form
              onSubmit={handleTextSubmit}
              className="flex items-center gap-3 bg-[#1c1c21] p-2 rounded-2xl border border-white/5"
            >
              <button
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className={cn(
                  "p-2 rounded-xl transition-colors",
                  showEmojiPicker
                    ? "text-indigo-400 bg-indigo-500/10"
                    : "text-slate-400 hover:text-white",
                )}
                title="الرموز التعبيرية"
              >
                <Smile className="h-5 w-5" />
              </button>

              <button
                type="button"
                onClick={() => setShowAttachmentMenu(!showAttachmentMenu)}
                className={cn(
                  "p-2 rounded-xl transition-colors",
                  showAttachmentMenu
                    ? "text-indigo-400 bg-indigo-500/10"
                    : "text-slate-400 hover:text-white"
                )}
                title="إرفاق وسائط"
              >
                <Paperclip className="h-5 w-5" />
              </button>

              <input
                type="text"
                value={newMessage}
                onChange={handleInputChange}
                placeholder="اكتب رسالتك هنا..."
                className="flex-1 bg-transparent border-none text-sm focus:ring-0 placeholder:text-slate-600 outline-none px-2 py-2 text-slate-200"
              />

              {/* Voice Message Recorder Trigger */}
              <button
                type="button"
                onClick={startRecording}
                className="p-2 text-slate-400 hover:text-indigo-400 transition-colors"
                title="تسجيل رسالة صوتية"
              >
                <Mic className="h-5 w-5" />
              </button>

              {/* Submit button */}
              <button
                type="submit"
                disabled={!newMessage.trim()}
                className="bg-indigo-500 hover:bg-indigo-400 text-white p-2.5 rounded-xl shadow-lg shadow-indigo-500/20 transition-all active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <Send className="h-5 w-5 rtl:-scale-x-100" />
              </button>
            </form>
          )}
        </div>
      </footer>

      {/* Hidden Inputs for File Selection */}
      <input
        type="file"
        id="gallery-photo-input"
        accept="image/*"
        className="hidden"
        onChange={handleGalleryPhotoChange}
      />
      <input
        type="file"
        id="gallery-video-input"
        accept="video/*"
        className="hidden"
        onChange={handleGalleryVideoChange}
      />

      {/* Media Send Preview Modal */}
      {previewMedia && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-[#1c1c21] border border-white/10 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/5" dir="rtl">
              <h3 className="text-sm font-semibold text-slate-100">معاينة قبل الإرسال</h3>
              <button
                type="button"
                onClick={() => setPreviewMedia(null)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Media Body */}
            <div className="flex-1 bg-black/40 p-6 flex items-center justify-center min-h-[250px] max-h-[400px] overflow-hidden relative">
              {previewMedia.type === "image" ? (
                <img
                  src={previewMedia.data}
                  alt="معاينة الصورة"
                  className="max-w-full max-h-[350px] object-contain rounded-lg shadow-lg"
                />
              ) : (
                <video
                  src={previewMedia.data}
                  controls
                  className="max-w-full max-h-[350px] rounded-lg shadow-lg"
                />
              )}
            </div>

            {/* Caption Input & Action Buttons */}
            <div className="p-4 bg-[#121215] border-t border-white/5" dir="rtl">
              <div className="mb-4">
                <label className="block text-[11px] font-medium text-slate-500 mb-1.5 text-right">
                  إضافة تعليق (اختياري)
                </label>
                <input
                  type="text"
                  value={previewMedia.caption}
                  onChange={(e) => setPreviewMedia({ ...previewMedia, caption: e.target.value })}
                  placeholder="اكتب تعليقاً على الصورة..."
                  className="w-full bg-[#1c1c21] border border-white/5 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-right"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleSendMessage(
                        previewMedia.caption.trim() || undefined,
                        undefined,
                        undefined,
                        previewMedia.data,
                        previewMedia.type
                      );
                      setPreviewMedia(null);
                    }
                  }}
                />
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    handleSendMessage(
                      previewMedia.caption.trim() || undefined,
                      undefined,
                      undefined,
                      previewMedia.data,
                      previewMedia.type
                    );
                    setPreviewMedia(null);
                  }}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl py-2.5 text-sm font-medium transition-colors shadow-lg shadow-indigo-600/10 cursor-pointer"
                >
                  إرسال
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewMedia(null)}
                  className="px-5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/5 rounded-xl py-2.5 text-sm font-medium transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Live Camera Modal */}
      {showCameraModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="bg-[#1c1c21] border border-white/10 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col relative animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/5 z-10 bg-[#1c1c21]" dir="rtl">
              <h3 className="text-sm font-semibold text-slate-100">الكاميرا الحية</h3>
              <button
                type="button"
                onClick={() => {
                  setShowCameraModal(false);
                  stopCamera();
                }}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Video Feed */}
            <div className="relative bg-black flex items-center justify-center overflow-hidden min-h-[300px] max-h-[450px]">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover scale-x-[-1]"
              />
              {isRecordingCameraVideo && (
                <div className="absolute top-4 right-4 bg-red-600/90 text-white text-[11px] font-bold px-3 py-1 rounded-full animate-pulse flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-white"></span>
                  جاري تسجيل فيديو...
                </div>
              )}
            </div>

            {/* Camera Controls */}
            <div className="p-6 bg-[#121215] border-t border-white/5 flex flex-col gap-4 items-center">
              <div className="flex items-center gap-6 justify-center w-full">
                {isRecordingCameraVideo ? (
                  <button
                    type="button"
                    onClick={stopCameraVideoRecording}
                    className="h-16 w-16 rounded-full bg-red-600 border-4 border-white flex items-center justify-center hover:scale-105 active:scale-95 transition-transform cursor-pointer"
                    title="إيقاف التسجيل"
                  >
                    <Square className="h-6 w-6 text-white fill-white" />
                  </button>
                ) : (
                  <>
                    {/* Capture Photo Button */}
                    <button
                      type="button"
                      onClick={captureCameraPhoto}
                      className="h-16 w-16 rounded-full bg-indigo-600 hover:bg-indigo-500 border-4 border-white/10 flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg shadow-indigo-600/20 cursor-pointer"
                      title="التقاط صورة"
                    >
                      <Camera className="h-7 w-7 text-white" />
                    </button>

                    {/* Record Video Button */}
                    <button
                      type="button"
                      onClick={startCameraVideoRecording}
                      className="h-16 w-16 rounded-full bg-red-600/20 hover:bg-red-600/30 border-4 border-red-600 flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg cursor-pointer"
                      title="تسجيل فيديو"
                    >
                      <Video className="h-6 w-6 text-red-500" />
                    </button>
                  </>
                )}
              </div>
              
              <div className="text-center">
                <p className="text-[11px] text-slate-500">
                  {isRecordingCameraVideo 
                    ? "انقر على زر الإيقاف الأحمر لحفظ وإرسال الفيديو" 
                    : "التقط صورة فورية أو ابدأ تسجيل فيديو مباشرة"}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Image Lightbox (Zoomed Image View) */}
      {selectedZoomImage && (
        <div 
          className="fixed inset-0 z-[110] flex items-center justify-center bg-black/95 backdrop-blur-md p-4 animate-in fade-in duration-200"
          onClick={() => setSelectedZoomImage(null)}
        >
          <button
            type="button"
            onClick={() => setSelectedZoomImage(null)}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="h-6 w-6" />
          </button>
          <img
            src={selectedZoomImage}
            alt="صورة مكبرة"
            className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      {/* Location Picker Modal (Current & Live Location) */}
      <LocationPickerModal
        isOpen={showLocationModal}
        onClose={() => setShowLocationModal(false)}
        onSendLocation={(locationData) => {
          handleSendMessage(
            undefined,
            undefined,
            undefined,
            undefined,
            undefined,
            locationData,
          );
        }}
      />
    </>
  );
}

// Built-in audio player for voice messages in the message bubble
function AudioMessagePlayer({
  audioSrc,
  duration = 0,
  isMe,
}: {
  audioSrc: string;
  duration?: number;
  isMe: boolean;
}) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [hasError, setHasError] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    setPlaybackRate(1);
    setHasError(false);
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [audioSrc]);

  const cycleSpeed = () => {
    let nextRate = 1;
    if (playbackRate === 1) {
      nextRate = 1.5;
    } else if (playbackRate === 1.5) {
      nextRate = 2;
    } else {
      nextRate = 1;
    }
    setPlaybackRate(nextRate);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextRate;
    }
  };

  const togglePlay = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio(audioSrc);
      audioRef.current.playbackRate = playbackRate;

      audioRef.current.addEventListener("ended", () => {
        setIsPlaying(false);
        setProgress(0);
        setCurrentTime(0);
      });

      audioRef.current.addEventListener("error", (e) => {
        console.error("Audio playback error event:", e);
        setHasError(true);
        setIsPlaying(false);
      });

      audioRef.current.addEventListener("timeupdate", () => {
        if (audioRef.current) {
          const cur = audioRef.current.currentTime;
          const dur = audioRef.current.duration || duration || 1;
          setCurrentTime(cur);
          setProgress((cur / dur) * 100);
        }
      });
    }

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.playbackRate = playbackRate;
      setHasError(false);
      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch((e) => {
          console.error("Error playing audio:", e);
          setHasError(true);
          setIsPlaying(false);
        });
    }
  };

  const displayTime = isPlaying ? currentTime : duration;

  return (
    <div className="flex items-center gap-3 py-1 px-2 rounded-xl min-w-[220px]">
      <button
        onClick={togglePlay}
        className={cn(
          "w-9 h-9 rounded-full flex items-center justify-center transition-colors shrink-0",
          isMe
            ? "bg-white text-indigo-600 hover:bg-slate-100 disabled:opacity-50"
            : "bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-50",
        )}
      >
        {isPlaying ? (
          <Pause className="h-4.5 w-4.5 fill-current" />
        ) : (
          <Play className="h-4.5 w-4.5 fill-current ml-[-1px] rtl:mr-[-1px] rtl:ml-[0]" />
        )}
      </button>

      <div className="flex-1 flex flex-col gap-1.5 min-w-0">
        {/* Dynamic Wave Simulation bar */}
        <div className="h-1.5 w-full bg-slate-500/20 rounded-full overflow-hidden relative">
          <div
            className={cn(
              "h-full rounded-full transition-all duration-100",
              isMe ? "bg-white" : "bg-indigo-500",
            )}
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Duration / Timer info */}
        <div className="flex justify-between items-center text-[10px] text-slate-400 select-none gap-2">
          <span
            className={cn(
              "font-medium truncate",
              hasError && "text-amber-500 font-semibold",
            )}
          >
            {hasError
              ? "صوت • غير مدعوم بالمتصفح"
              : `صوت ${isPlaying ? "• جاري التشغيل" : "• رسالة صوتية"}`}
          </span>
          <span className="font-mono shrink-0">
            {Math.floor(displayTime / 60)}:
            {(Math.floor(displayTime) % 60).toString().padStart(2, "0")}
          </span>
        </div>
      </div>

      <button
        onClick={cycleSpeed}
        disabled={hasError}
        title="سرعة التشغيل"
        className={cn(
          "h-7 px-2 rounded-lg text-[10px] font-bold transition-colors shrink-0 flex items-center justify-center min-w-[36px]",
          isMe
            ? "bg-white/10 text-white hover:bg-white/20 border border-white/10 disabled:opacity-50"
            : "bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 border border-indigo-500/10 disabled:opacity-50",
        )}
      >
        {playbackRate}x
      </button>
    </div>
  );
}

function CallAudioPlayer({ stream }: { stream: MediaStream | null }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !stream) return;

    // Enable all audio tracks
    stream.getAudioTracks().forEach((track) => {
      track.enabled = true;
    });

    if (audio.srcObject !== stream) {
      audio.srcObject = stream;
    }
    audio.muted = false;
    audio.volume = 1.0;

    const play = () => {
      audio.play().catch((err) => {
        console.warn("CallAudioPlayer autoplay blocked:", err);
      });
    };

    play();

    // Re-verify and play when tracks are added
    const handleTrackAdded = () => {
      stream.getAudioTracks().forEach((t) => {
        t.enabled = true;
      });
      play();
    };

    stream.addEventListener("addtrack", handleTrackAdded);
    return () => {
      stream.removeEventListener("addtrack", handleTrackAdded);
    };
  }, [stream]);

  // Dedicated remote audio is handled exclusively by the root overlay audio element to avoid echo
  return null;
}

function CallVideoPreview({
  stream,
  className,
  muted = true,
  mirrored = false,
  fallback,
}: {
  stream: MediaStream | null;
  className?: string;
  muted?: boolean;
  mirrored?: boolean;
  fallback?: React.ReactNode;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [hasVideoFrame, setHasVideoFrame] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (!stream) {
      video.srcObject = null;
      setHasVideoFrame(false);
      return;
    }

    const checkTrackState = () => {
      const vTracks = stream.getVideoTracks();
      const hasLiveTrack =
        vTracks.length > 0 &&
        vTracks.some((t) => t.readyState === "live" && t.enabled);
      if (!hasLiveTrack) {
        setHasVideoFrame(false);
      }
    };

    checkTrackState();

    video.srcObject = stream;
    // Always strictly muted to prevent sound looping / echo with remote audio player
    video.defaultMuted = true;
    video.muted = true;
    video.volume = 0;

    const playVideo = async () => {
      try {
        await video.play();
      } catch (err) {
        console.warn("Retrying video playback:", err);
        video.muted = true;
        video.volume = 0;
        try {
          await video.play();
        } catch (e) {
          // ignore
        }
      }
    };

    playVideo();

    stream.addEventListener("addtrack", checkTrackState);
    stream.addEventListener("removetrack", checkTrackState);

    return () => {
      stream.removeEventListener("addtrack", checkTrackState);
      stream.removeEventListener("removetrack", checkTrackState);
    };
  }, [stream]);

  if (!stream) {
    if (fallback) return <>{fallback}</>;
    return (
      <div
        className={cn(
          "flex items-center justify-center bg-zinc-950",
          className,
        )}
      >
        <VideoOff className="w-10 h-10 text-slate-500 animate-pulse" />
      </div>
    );
  }

  return (
    <div className={cn("relative overflow-hidden w-full h-full", className)}>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted={true}
        onLoadedMetadata={(e) => {
          const v = e.target as HTMLVideoElement;
          v.play().catch(() => {});
          if (v.videoWidth > 0 && v.videoHeight > 0) {
            setHasVideoFrame(true);
          }
        }}
        onCanPlay={(e) => {
          const v = e.target as HTMLVideoElement;
          v.play().catch(() => {});
          if (v.videoWidth > 0 && v.videoHeight > 0) {
            setHasVideoFrame(true);
          }
        }}
        onPlaying={() => {
          setHasVideoFrame(true);
        }}
        className={cn(
          "w-full h-full object-cover transition-opacity duration-300",
          mirrored && "scale-x-[-1]",
          hasVideoFrame ? "opacity-100" : "opacity-0 absolute inset-0",
        )}
      />
      {!hasVideoFrame && (
        <div className="absolute inset-0 w-full h-full flex items-center justify-center bg-zinc-950 z-10">
          {fallback || (
            <div className="flex flex-col items-center gap-3 text-slate-400 p-4 text-center">
              <VideoOff className="w-8 h-8 text-amber-400/80 animate-pulse" />
              <span className="text-xs">جارٍ تشغيل الكاميرا...</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
