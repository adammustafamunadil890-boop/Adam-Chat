export interface LanguageItem {
  code: string;
  name: string; // Native script
  englishName: string;
  arabicName: string;
  flag: string;
  dir?: "rtl" | "ltr";
}

export const WORLD_LANGUAGES: LanguageItem[] = [
  { code: "ar", name: "العربية", englishName: "Arabic", arabicName: "العربية", flag: "🇸🇦", dir: "rtl" },
  { code: "en", name: "English", englishName: "English", arabicName: "الإنجليزية", flag: "🇺🇸", dir: "ltr" },
  { code: "es", name: "Español", englishName: "Spanish", arabicName: "الإسبانية", flag: "🇪🇸", dir: "ltr" },
  { code: "fr", name: "Français", englishName: "French", arabicName: "الفرنسية", flag: "🇫🇷", dir: "ltr" },
  { code: "de", name: "Deutsch", englishName: "German", arabicName: "الألمانية", flag: "🇩🇪", dir: "ltr" },
  { code: "tr", name: "Türkçe", englishName: "Turkish", arabicName: "التركية", flag: "🇹🇷", dir: "ltr" },
  { code: "fa", name: "فارسی", englishName: "Persian", arabicName: "الفارسية", flag: "🇮🇷", dir: "rtl" },
  { code: "ur", name: "اردو", englishName: "Urdu", arabicName: "الأردية", flag: "🇵🇰", dir: "rtl" },
  { code: "ru", name: "Русский", englishName: "Russian", arabicName: "الروسية", flag: "🇷🇺", dir: "ltr" },
  { code: "zh-CN", name: "简体中文", englishName: "Chinese (Simplified)", arabicName: "الصينية (المبسطة)", flag: "🇨🇳", dir: "ltr" },
  { code: "zh-TW", name: "繁體中文", englishName: "Chinese (Traditional)", arabicName: "الصينية (التقليدية)", flag: "🇹🇼", dir: "ltr" },
  { code: "ja", name: "日本語", englishName: "Japanese", arabicName: "اليابانية", flag: "🇯🇵", dir: "ltr" },
  { code: "ko", name: "한국어", englishName: "Korean", arabicName: "الكورية", flag: "🇰🇷", dir: "ltr" },
  { code: "pt", name: "Português", englishName: "Portuguese", arabicName: "البرتغالية", flag: "🇵🇹", dir: "ltr" },
  { code: "it", name: "Italiano", englishName: "Italian", arabicName: "الإيطالية", flag: "🇮🇹", dir: "ltr" },
  { code: "hi", name: "हिन्दी", englishName: "Hindi", arabicName: "الهندية", flag: "🇮🇳", dir: "ltr" },
  { code: "bn", name: "বাংলা", englishName: "Bengali", arabicName: "البنغالية", flag: "🇧🇩", dir: "ltr" },
  { code: "id", name: "Bahasa Indonesia", englishName: "Indonesian", arabicName: "الإندونيسية", flag: "🇮🇩", dir: "ltr" },
  { code: "ms", name: "Bahasa Melayu", englishName: "Malay", arabicName: "الماليزية", flag: "🇲🇾", dir: "ltr" },
  { code: "nl", name: "Nederlands", englishName: "Dutch", arabicName: "الهولندية", flag: "🇳🇱", dir: "ltr" },
  { code: "pl", name: "Polski", englishName: "Polish", arabicName: "البولندية", flag: "🇵🇱", dir: "ltr" },
  { code: "sv", name: "Svenska", englishName: "Swedish", arabicName: "السويدية", flag: "🇸🇪", dir: "ltr" },
  { code: "el", name: "Ελληνικά", englishName: "Greek", arabicName: "اليونانية", flag: "🇬🇷", dir: "ltr" },
  { code: "vi", name: "Tiếng Việt", englishName: "Vietnamese", arabicName: "الفيتنامية", flag: "🇻🇳", dir: "ltr" },
  { code: "th", name: "ไทย", englishName: "Thai", arabicName: "التايلاندية", flag: "🇹🇭", dir: "ltr" },
  { code: "uk", name: "Українська", englishName: "Ukrainian", arabicName: "الأوكرانية", flag: "🇺🇦", dir: "ltr" },
  { code: "ro", name: "Română", englishName: "Romanian", arabicName: "الرومانية", flag: "🇷🇴", dir: "ltr" },
  { code: "cs", name: "Čeština", englishName: "Czech", arabicName: "التشيكية", flag: "🇨🇿", dir: "ltr" },
  { code: "hu", name: "Magyar", englishName: "Hungarian", arabicName: "المجرية", flag: "🇭🇺", dir: "ltr" },
  { code: "da", name: "Dansk", englishName: "Danish", arabicName: "الدانماركية", flag: "🇩🇰", dir: "ltr" },
  { code: "fi", name: "Suomi", englishName: "Finnish", arabicName: "الفنلندية", flag: "🇫🇮", dir: "ltr" },
  { code: "no", name: "Norsk", englishName: "Norwegian", arabicName: "النرويجية", flag: "🇳🇴", dir: "ltr" },
  { code: "he", name: "עברית", englishName: "Hebrew", arabicName: "العبرية", flag: "🇮🇱", dir: "rtl" },
  { code: "tl", name: "Filipino (Tagalog)", englishName: "Tagalog", arabicName: "الفلبينية", flag: "🇵🇭", dir: "ltr" },
  { code: "sw", name: "Kiswahili", englishName: "Swahili", arabicName: "السواحلية", flag: "🇰🇪", dir: "ltr" },
  { code: "ku", name: "Kurdî (کوردی)", englishName: "Kurdish", arabicName: "الكردية", flag: "☀️", dir: "rtl" },
  { code: "ps", name: "پښتو", englishName: "Pashto", arabicName: "البشتوية", flag: "🇦🇫", dir: "rtl" },
  { code: "am", name: "አማርኛ", englishName: "Amharic", arabicName: "الأمهرية", flag: "🇪🇹", dir: "ltr" },
  { code: "so", name: "Soomaali", englishName: "Somali", arabicName: "الصومالية", flag: "🇸🇴", dir: "ltr" },
  { code: "ha", name: "Hausa", englishName: "Hausa", arabicName: "الهوسا", flag: "🇳🇬", dir: "ltr" },
  { code: "yo", name: "Yorùbá", englishName: "Yoruba", arabicName: "اليوروبية", flag: "🇳🇬", dir: "ltr" },
  { code: "zu", name: "isiZulu", englishName: "Zulu", arabicName: "الزولو", flag: "🇿🇦", dir: "ltr" },
  { code: "ta", name: "தமிழ்", englishName: "Tamil", arabicName: "التاميلية", flag: "🇮🇳", dir: "ltr" },
  { code: "te", name: "తెలుగు", englishName: "Telugu", arabicName: "التيلوغوية", flag: "🇮🇳", dir: "ltr" },
  { code: "mr", name: "मराठी", englishName: "Marathi", arabicName: "المراثية", flag: "🇮🇳", dir: "ltr" },
  { code: "gu", name: "ગુજરાતી", englishName: "Gujarati", arabicName: "الغوجاراتية", flag: "🇮🇳", dir: "ltr" },
  { code: "pa", name: "ਪੰਜਾਬੀ", englishName: "Punjabi", arabicName: "البنجابية", flag: "🇮🇳", dir: "ltr" },
  { code: "ml", name: "മലയാളം", englishName: "Malayalam", arabicName: "المالايالامية", flag: "🇮🇳", dir: "ltr" },
  { code: "kn", name: "ಕನ್ನಡ", englishName: "Kannada", arabicName: "الكانادية", flag: "🇮🇳", dir: "ltr" },
  { code: "my", name: "မြန်မာစာ", englishName: "Burmese", arabicName: "البورمية", flag: "🇲🇲", dir: "ltr" },
  { code: "ne", name: "नेपाली", englishName: "Nepali", arabicName: "النيبالية", flag: "🇳🇵", dir: "ltr" },
  { code: "si", name: "සිංහල", englishName: "Sinhala", arabicName: "السنهالية", flag: "🇱🇰", dir: "ltr" },
  { code: "az", name: "Azərbaycan", englishName: "Azerbaijani", arabicName: "الأذربيجانية", flag: "🇦🇿", dir: "ltr" },
  { code: "uz", name: "Oʻzbekcha", englishName: "Uzbek", arabicName: "الأوزبكية", flag: "🇺🇿", dir: "ltr" },
  { code: "kk", name: "Қазақша", englishName: "Kazakh", arabicName: "الكازاخية", flag: "🇰🇿", dir: "ltr" },
  { code: "ka", name: "ქართული", englishName: "Georgian", arabicName: "الجورجية", flag: "🇬🇪", dir: "ltr" },
  { code: "hy", name: "Հայերեն", englishName: "Armenian", arabicName: "الأرمينية", flag: "🇦🇲", dir: "ltr" },
  { code: "bg", name: "Български", englishName: "Bulgarian", arabicName: "البلغارية", flag: "🇧🇬", dir: "ltr" },
  { code: "sr", name: "Српски", englishName: "Serbian", arabicName: "الصربية", flag: "🇷🇸", dir: "ltr" },
  { code: "hr", name: "Hrvatski", englishName: "Croatian", arabicName: "الكرواتية", flag: "🇭🇷", dir: "ltr" },
  { code: "bs", name: "Bosanski", englishName: "Bosnian", arabicName: "البوسنية", flag: "🇧🇦", dir: "ltr" },
  { code: "sk", name: "Slovenčina", englishName: "Slovak", arabicName: "السلوفاكية", flag: "🇸🇰", dir: "ltr" },
  { code: "sl", name: "Slovenščina", englishName: "Slovenian", arabicName: "السلوفينية", flag: "🇸🇮", dir: "ltr" },
  { code: "lt", name: "Lietuvių", englishName: "Lithuanian", arabicName: "الليتوانية", flag: "🇱🇹", dir: "ltr" },
  { code: "lv", name: "Latviešu", englishName: "Latvian", arabicName: "اللاتفية", flag: "🇱🇻", dir: "ltr" },
  { code: "et", name: "Eesti", englishName: "Estonian", arabicName: "الإستونية", flag: "🇪🇪", dir: "ltr" },
  { code: "sq", name: "Shqip", englishName: "Albanian", arabicName: "الألبانية", flag: "🇦🇱", dir: "ltr" },
  { code: "mk", name: "Македонски", englishName: "Macedonian", arabicName: "المقدونية", flag: "🇲🇰", dir: "ltr" },
  { code: "is", name: "Íslenska", englishName: "Icelandic", arabicName: "الأيسلندية", flag: "🇮🇸", dir: "ltr" },
  { code: "ga", name: "Gaeilge", englishName: "Irish", arabicName: "الأيرلندية", flag: "🇮🇪", dir: "ltr" },
  { code: "eu", name: "Euskara", englishName: "Basque", arabicName: "الباسكية", flag: "🇪🇸", dir: "ltr" },
  { code: "ca", name: "Català", englishName: "Catalan", arabicName: "الكتالونية", flag: "🇪🇸", dir: "ltr" },
  { code: "gl", name: "Galego", englishName: "Galician", arabicName: "الجاليكية", flag: "🇪🇸", dir: "ltr" },
  { code: "af", name: "Afrikaans", englishName: "Afrikaans", arabicName: "الأفريكانية", flag: "🇿🇦", dir: "ltr" },
  { code: "mn", name: "Монгол", englishName: "Mongolian", arabicName: "المنغولية", flag: "🇲🇳", dir: "ltr" },
  { code: "km", name: "ភាសាខ្មែរ", englishName: "Khmer", arabicName: "الخميرية", flag: "🇰🇭", dir: "ltr" },
  { code: "lo", name: "ພາສາລາວ", englishName: "Lao", arabicName: "اللاوية", flag: "🇱🇦", dir: "ltr" },
];

export function searchLanguages(query: string): LanguageItem[] {
  const q = query.trim().toLowerCase();
  if (!q) return WORLD_LANGUAGES;

  return WORLD_LANGUAGES.filter((item) => {
    return (
      item.code.toLowerCase().includes(q) ||
      item.name.toLowerCase().includes(q) ||
      item.englishName.toLowerCase().includes(q) ||
      item.arabicName.toLowerCase().includes(q)
    );
  });
}
