importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js');

const firebaseConfig = {
  apiKey: "AIzaSyAJnUVOq7NwAM01PJMFApllxt_9z3T-9Gw",
  authDomain: "gen-lang-client-0905183084.firebaseapp.com",
  projectId: "gen-lang-client-0905183084",
  storageBucket: "gen-lang-client-0905183084.firebasestorage.app",
  messagingSenderId: "184793985410",
  appId: "1:184793985410:web:ca9fca18d6a34f448f1f9b"
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  
  const notificationTitle = payload.notification?.title || payload.data?.title || 'رسالة جديدة';
  const notificationOptions = {
    body: payload.notification?.body || payload.data?.body || 'لديك إشعار جديد.',
    icon: payload.notification?.icon || payload.data?.icon || '/logo.jpg',
    badge: '/logo.jpg',
    data: payload.data,
    requireInteraction: true,
    vibrate: [200, 100, 200]
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
